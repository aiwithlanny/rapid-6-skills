# Style presets

## Selection table

| Preset | Best for | Typical pages | Visual grammar | Text strategy |
|---|---|---:|---|---|
| Cinematic knowledge journey | education, concepts, tool introductions | 5–8 | cinematic city/work scenes, dimensional lighting, editorial storytelling | headline over image or structured lower panel |
| High-impact magazine poster | bold opinions, tool lists, personal-brand hooks | 5–7 | dramatic portrait, brush typography, black/yellow/orange, stickers and arrows | add typography during layout; never rely on generated Chinese text |
| Hand-drawn roadmap | step-by-step plans, beginner routes, workflows | 6 | ivory paper, orange/black, winding road, storybook scenes | top illustration + lower text panel |

## Preset 1 — Cinematic knowledge journey

Use when the content benefits from emotional atmosphere and a sense of discovery.

- 4:5 editorial composition.
- One cinematic environment per page.
- Strong foreground subject and contextual background.
- Warm/cool contrast, controlled highlights, detailed but readable scenes.
- Maintain one recurring person, object, or route across pages when helpful.
- Limit overlay copy; preserve negative space for titles added during layout.
- Suitable sequence: hook → problem → tools/ideas → proof → action.

## Preset 2 — High-impact magazine poster

Use when scroll-stopping impact matters more than quiet explanation.

- Large portrait or hero object.
- High-contrast black, warm yellow, orange/red accent.
- Brush-like display typography, skewed underlines, arrows, torn-paper or ink textures.
- Use 3–5 visual weights, not a flat list of equal text.
- Add all Traditional Chinese headlines during layout. Use a bold brush-style or condensed CJK display font available in the environment.
- If a portrait is supplied, preserve identity, glasses, hairstyle, and face proportions unless the user asks for a transformation.
- Avoid generic corporate sans-serif styling.

## Preset 3 — Hand-drawn roadmap

Use for a multi-day plan, sequence, beginner guide, or workflow.

- Warm ivory paper texture.
- Burnt orange, charcoal, muted sage, dusty blue.
- Ink outlines, colored pencil, gouache, sophisticated storybook/notebook character.
- One continuous road, river, path, or journey motif.
- Cover: overview of milestones.
- Interior: top 50–58% illustration; lower section title, bullets, and takeaway.
- Final page: destination, integrated workflow, or result; CTA can sit inside the final takeaway.
- Generate scenes without labels. Add day numbers, tool names, and copy during PNG layout; recreate them as editable Canva elements only when the user later requests a Canva version.

## Extracting a new preset from a reference

Record:

1. format and page count
2. cover hook hierarchy
3. page roles and narrative sequence
4. visual subject and environment
5. image-to-text ratio
6. palette and texture
7. typography personality
8. recurring motif
9. CTA location and conversion mechanism
10. which elements should be recreated as editable layers if Canva is later requested

Do not reproduce copyrighted artwork or exact page compositions. Convert observed patterns into a new visual system for the user's content.
