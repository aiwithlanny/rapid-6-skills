# Copy and production

## Copy structure

Write one job per page:

- Cover: earn the swipe with a specific promise or tension.
- Context/problem: make the reader recognize their situation.
- Value pages: one tool, step, mistake, or idea per page.
- Proof: connect the advice to authentic experience or data.
- Close: synthesize and give one clear action.

For a list of three tools, avoid merely describing features. Tie each tool to a repeated job, an action, and a result.

## Copy limits

- Cover: usually 8–18 Chinese characters in the main hook, with an optional short qualifier.
- Interior title: one or two lines.
- Interior body: 35–90 Chinese characters, depending on visual density.
- Bullets: three or four short items.
- CTA: one primary action plus one keyword. Avoid stacking five actions.

Use specificity without exaggeration. Preserve user-provided metrics exactly and qualify subjective results as personal experience.

## Caption pattern

1. Restate the reader's repeated problem.
2. Share the user's discovery or workflow.
3. Summarize the carousel's value.
4. Add the approved CTA and delivery mechanism.

Add a focused hashtag set after the caption. Prefer relevant topic, audience, problem, and niche tags over generic high-volume tags. Avoid duplicates, unrelated tags, and claims not supported by the approved brief. Follow any user-specified hashtag count or language; otherwise use a concise set appropriate to the post.

## Image-generation prompt skeleton

```text
Use case: illustration-story / ads-marketing / photorealistic-natural
Asset type: top-half or full-page IG carousel visual, crop-safe for 4:5
Primary request: [page-specific scene]
Style/medium: [stable preset specification]
Composition/framing: [subject placement and negative space]
Lighting/mood: [stable lighting system]
Color palette: [stable palette]
Constraints: no text, no letters, no numbers, no logos, no watermark, no fake UI; keep important elements away from edges
```

Issue one generation call per distinct asset. Inspect outputs for text artifacts, identity drift, wrong subject count, style drift, and unusable cropping.

## PNG layout standards

- Canvas: 1080 × 1350.
- Safe margin: normally 56–80 px.
- Cover title: large enough to read at feed-thumbnail size.
- Interior title: normally 42 px or larger.
- Body copy: normally 20–28 px depending on font and density.
- Page numbers: consistent but visually secondary.
- Use a single composition, not a dashboard of small cards.
- Repeat a stable header, footer, or panel rhythm across interior pages.
- Add text and basic shapes as layout elements before rendering the final PNGs; do not depend on text generated inside images.

## Production sequence

1. Save generated assets to a dedicated project folder.
2. Compose every approved page at 1080 × 1350.
3. Render all pages to full-resolution PNG.
4. Create a contact sheet.
5. Run overflow/layout checks.
6. Inspect the cover and every interior page at full size.
7. Correct all visual defects.
8. Deliver the complete PNG set, contact sheet, page-by-page text, caption, and hashtags.
9. Wait for the user's approval of the PNG package.
10. Only after approval, ask whether an editable Canva version is needed.
11. If requested, recreate the approved pages directly in Canva and verify the URL, page count, and editable elements.

Do not create or deliver a PPTX at any stage.

## Optional Canva production and fallback

Do not begin Canva production until the user approves the PNG package and explicitly requests Canva. Recreate the approved design directly in Canva; do not import or generate a PPTX.

If the Canva connector fails after one retry:

1. Open authenticated Canva home in the browser.
2. Create a new design with the approved dimensions.
3. Use the verified PNGs as visual references and upload the original generated assets where needed.
4. Recreate text, labels, CTA, page numbers, and simple shapes as editable Canva elements.
5. Verify the design URL, page count, page order, and editable elements.
6. Keep the design page open only when the user requested Canva access.

If direct editable recreation is unavailable, report the limitation. Never substitute a PPTX or report success from a placeholder upload ID or incomplete state.

## Final QA checklist

- [ ] Every page uses approved copy.
- [ ] All Chinese text is correct and legible in the PNGs.
- [ ] No unwanted handle, logo, watermark, or gibberish.
- [ ] Personal claims and metrics match the user's words.
- [ ] Images are consistent and crop-safe.
- [ ] Text is readable on a phone.
- [ ] No overflow, clipping, collision, or accidental wrapping.
- [ ] CTA action, keyword, and auto-DM promise are correct.
- [ ] Caption and hashtags are included and match the approved content.
- [ ] Every full-resolution PNG and the contact sheet exist.
- [ ] Canva was not started before PNG approval and an explicit user request.
- [ ] If Canva was requested, the link opens the finished design with the correct page count and expected editable elements.
