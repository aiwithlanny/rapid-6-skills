# Intake and confirmation

## Minimum intake form

Use this form selectively. Never ask for fields already known.

```text
【本篇主題】我想分享：
【目標讀者】這篇主要寫給：
【讀者的問題】他們最常遇到：
【希望結果】看完後，希望他們：
【核心內容】我想介紹的項目／步驟：
【經驗或證據】我的感受、結果、故事或數據：
【行動引導】收藏／追蹤／留言／私訊／個人檔案連結：
【免費資源或產品】我想提供：
【留言關鍵字】請讀者留言：
【語言與語氣】例如繁體中文、朋友分享、不浮誇：
【帳號顯示】顯示／不顯示帳號：
【視覺素材】本人照片、產品圖、Logo、品牌色：
```

## Missing-information logic

Ask in this order:

1. Missing facts that change the content: topic, audience, points/steps.
2. Missing facts that change credibility: experience, result, evidence.
3. Missing conversion details: CTA, offer, keyword, delivery method.
4. Missing visual constraints: portrait, account handle, brand assets.

If personal proof is blank, ask one focused question such as:

> 你實際使用後，最明顯省下的是哪一段工作？原本花多久，現在大約多久？

Do not fabricate a number. If the user has no personal result, use a neutral educational angle.

## Confirmation gate 1 template

```text
我會做成 [頁數] 頁的 [風格] 輪播：

封面：[hook]
讀者：[audience]
承諾：[outcome]
順序：1 → 2 → 3 → …
CTA：[action + keyword + delivery]
不放：[handle/logo/etc.]

如果這個方向沒問題，我再寫完整逐頁文案與插畫規劃。
```

## Confirmation gate 2 template

Show for every page:

- page role
- exact headline
- exact body copy
- takeaway or CTA
- illustration/photo scene
- layout text vs. generated visual

End with a single confirmation request. Do not ask the user to re-confirm facts already approved.

This confirmation authorizes PNG production only. After the finished PNG package is delivered, wait for the user's approval before asking whether an editable Canva version is needed.

## Default assumptions allowed

- Platform: Instagram feed carousel.
- Size: 1080 × 1350.
- Language: Traditional Chinese when the conversation is Traditional Chinese.
- Tone: friendly, concrete, non-hyped.
- CTA page: include only when it improves the selected structure; some roadmap styles keep CTA in the final step or caption.

Flag assumptions that change the creative direction, number of pages, identity use, or conversion path.
