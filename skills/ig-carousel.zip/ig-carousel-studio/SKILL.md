---
name: ig-carousel-studio
description: Create complete Instagram carousel posts from a topic, rough notes, user experience, image, or reference Instagram link. Use when Codex needs to research or reverse-engineer an IG carousel style; gather missing topic, audience, pain point, proof, CTA, offer, keyword, portrait, or brand constraints; write Traditional Chinese carousel copy, caption, and hashtags; generate consistent illustrations or photos; build and verify 1080x1350 PNG pages; and optionally recreate an approved carousel as an editable Canva design. Supports educational city scenes, high-impact magazine posters, hand-drawn roadmap carousels, and new styles derived from references.
---

# IG Carousel Studio

Create a publishable IG carousel as finished PNG pages with complete posting copy. Offer an editable Canva version only after the user approves the PNG package.

## Core rules

- Use Traditional Chinese unless the user requests another language.
- Treat a supplied post as a style/structure reference, not content to copy.
- Never invent personal results, product details, follower handles, testimonials, or performance data.
- Ask only for information that is genuinely missing. Reuse facts already supplied in the conversation.
- Ask at most three short questions at a time.
- Keep the account handle off the design when the user requests it.
- Generate visual scenes without long embedded text. Add important Chinese copy during layout so the delivered PNG contains the approved final text.
- Preserve the user's original source files and Canva designs.
- Do not start image generation until the two confirmation gates below are complete.
- Deliver the complete PNG package, caption, and hashtags before discussing Canva.
- Do not create or deliver PPTX files.
- Do not start Canva production unless the user first approves the PNG package and then explicitly requests an editable Canva version.

## Load references

- Read [references/intake-and-confirmation.md](references/intake-and-confirmation.md) when gathering requirements or deciding what to ask.
- Read [references/style-presets.md](references/style-presets.md) after the style is chosen or a reference link must be classified.
- Read [references/copy-and-production.md](references/copy-and-production.md) before writing final page copy, generating assets, laying out pages, delivering PNGs, or creating an optional Canva version.

## Workflow

### 1. Establish the input route

Choose one:

1. **Topic route** — the user supplies a topic or content form.
2. **Reference route** — the user supplies an IG link or screenshot and wants a similar type.
3. **Hybrid route** — the user supplies both a reference and their own topic/content.

For a reference link, inspect every carousel page when access permits. Extract only reusable properties: hook pattern, page count, narrative rhythm, image-to-text ratio, typography character, palette, recurring motifs, CTA placement, and conversion path.

### 2. Gather the minimum brief

Use the intake reference. Required information is:

- topic
- target reader
- reader problem
- desired reader outcome
- core points or steps
- authentic experience/evidence, or explicit permission to write without personal proof
- CTA
- offer/free resource, if mentioned
- comment keyword, if used
- language/tone constraints
- account-handle preference

Do not repeat questions already answered. When the user says “use the information above,” search the conversation first and list only unresolved fields.

### 3. Confirmation gate 1 — strategy

Show a compact proposal containing:

- chosen angle and cover hook
- target reader and promised outcome
- selected style preset or extracted style direction
- page count and one-line page sequence
- CTA and conversion path
- any assumptions

Ask for confirmation. Do not generate images yet.

### 4. Write the carousel package

Produce:

- exact copy for every page
- short visual brief for every page
- image-generation brief for each required raster asset
- IG caption with CTA
- a focused set of relevant hashtags

Keep one primary message per page. Use short lines, concrete claims, and the voice of a smart friend sharing something that worked.

### 5. Confirmation gate 2 — page copy and visual plan

Present the complete page package for approval. If the user changes a fact, propagate the change through every affected page and caption. Generate images only after approval.

### 6. Generate visual assets

Use the image-generation capability for photos, illustrations, textures, or scenes. For multi-page sets:

- use one stable style specification across all prompts;
- change only the page-specific scene;
- keep important subjects crop-safe;
- avoid logos unless requested and permitted;
- avoid embedded copy, letters, numbers, watermarks, and fake UI;
- inspect every result before layout;
- save all selected assets inside the current project workspace.

For a supplied portrait, label it as an identity reference and preserve facial identity. Do not create a new person when the user expects their own likeness.

### 7. Build the finished PNG carousel

Create 1080 × 1350 pages unless the user requests another format. Compose every approved page as a final PNG inside the current project workspace.

- Use generated images as visual layers and add the approved titles, body copy, labels, CTA, page numbers, and simple shapes during layout.
- Use large mobile-readable typography.
- Keep safe margins and consistent page rhythm.
- Do not shrink copy to rescue an overcrowded page; shorten or split it.
- Do not place an account handle when the brief says not to.
- Keep the layout source used to render the PNGs only when the chosen production capability requires one, but do not create or deliver a PPTX.

### 8. Verify the PNG package

Render and inspect every page individually plus a contact sheet. Check:

- correct page count and 1080 × 1350 dimensions
- no overflow, clipping, unintended overlap, or awkward wrapping
- correct Traditional Chinese characters
- consistent style, palette, margins, hierarchy, and page numbering
- all factual claims match the approved brief
- CTA and keyword are correct
- no unwanted handle, logo, watermark, or generated gibberish

Fix all visible problems before delivery.

### 9. Deliver the PNG package for approval

Lead with the completed first-stage package. Provide:

- every full-resolution PNG page in order
- a contact-sheet preview
- exact page-by-page text in copyable form
- the final IG caption with CTA
- the final hashtag set

Ask the user to review the PNG package. Do not mention or offer Canva until the user approves this package.

### 10. Ask whether an editable Canva version is needed

After the user explicitly approves the PNG package, ask one short question: whether they also want an editable Canva version.

- If the user declines, stop with the approved PNG package as the final deliverable.
- If the user agrees, recreate the approved design directly in Canva as a new design. Use the verified PNGs as visual references and reuse the original generated assets; keep titles, body copy, labels, CTA, page numbers, and simple shapes editable where Canva permits.
- Do not use a PPTX as an intermediate or deliverable.
- Preserve the approved visual appearance and page order. Do not rewrite copy or redesign pages unless the user requests changes.
- Verify the Canva URL, expected page count, and editable elements before reporting success.
- Do not overwrite an existing Canva design.

If the Canva connector fails, retry once. Then use an authenticated browser to recreate the design directly in Canva. If direct editable recreation is unavailable, report the limitation instead of substituting a PPTX.

## Handling new styles

When a reference does not match an existing preset:

1. Classify its visual grammar and narrative structure.
2. Add any new questions required by that structure to the current brief.
3. Explain the added step to the user.
4. Complete the carousel using the same two confirmation gates.
5. Record the reusable style rules in `references/style-presets.md` only when the user asks to update this skill.

## Related production skills

- Hand off requests for ten posts, batch Markdown packages, or Feishu content-bank creation to `$ig-carousel-batch`.
- Hand off explicit Feishu-to-Instagram publishing commands and account onboarding to `$ig-carousel-publisher`.
- Preserve the same `content_id` across all three skills.
