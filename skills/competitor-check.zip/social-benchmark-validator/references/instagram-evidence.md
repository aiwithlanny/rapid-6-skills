# Instagram evidence workflow

Use this reference for an Instagram profile, post, Reel, carousel, or bio link.

## Collection target

Capture only what is visible:

- Profile: handle, display name, verification, post/follower/following counts, bio promise, proof claims, category, CTA, bio links, highlights when visible.
- Posts: URL, date, author/collaborators, pinned status, format, cover/hook, caption, pain/desire, proof, solution, CTA, visible likes/comments/shares/views.
- Comments: demand language, objections, questions, purchase intent, keyword replies, creator responses, and spam/emoji ratio.
- Funnel: landing page, lead magnet, form, community, store, course, template, consultation, membership, price, guarantees, checkout, and upsell signals.

Sample 6–12 items for a first pass, including:

- pinned posts;
- newest direct posts;
- collaboration posts;
- one or two apparent high performers;
- explicit offer or CTA posts.

## 必算的公開指標

如果貼文同時顯示觀看數和留言數，計算：

`留言率 = 留言數 ÷ 觀看數 × 100%`

在給使用者的回答中，用白話解釋：`留言率就是每100個觀看者中，有多少人願意留言。`

- 約 1%：平均表現。
- 1.25%–3%：表現好。
- 超過 3%：檢查是否由抽獎、爭議或「留言關鍵字領資料」推高。

有公開銷量時，銷量優先於留言率。看不到銷量時，才把留言率和留言內容當成接近購買的線索。

## Browser order

1. Use a purpose-built public Instagram connector if it can return the needed profile, posts, and comments.
2. Otherwise use Chrome when the task needs the user's current login state or a visual check. Read the Chrome-control skill first. If navigation is login-blocked, ask the user to sign in; do not bypass authentication.
3. If Chrome cannot expose or reliably load the page, use ego-browser when installed. Read the ego-browser skill first. Its isolated task space can reuse login state without competing with the user's ordinary tabs.
4. If Instagram requires CAPTCHA, account verification, or manual login, hand control to the user and wait. Do not solve or bypass it without the required confirmation.

Never like, follow, comment, message, save, or post during research.

## Extraction discipline

- Read dates from the post's visible date/time element. Do not infer recency from grid order because pinned posts appear first.
- Record collaboration authors explicitly.
- Treat counts next to interaction icons as a snapshot; verify the icon-to-number order before labeling counts.
- Save the direct post URL with every evidence row.
- Captions embedded in image alt text are usable public evidence, but label them as platform-rendered text when appropriate.
- A high volume of identical keywords such as “888”, “想知道”, or “精準” indicates a comment-to-DM or comment-to-resource mechanism. It does not by itself prove sales or audience depth.

## Instagram-specific interpretation

- Reels主要幫助判斷陌生人是否願意停下來看，以及開頭是否吸引人。
- Carousels and educational posts reveal save/share intent, though save counts are usually unavailable publicly.
- Stories, private DMs, backend reach, saves, lead conversion, and revenue are unknown unless the user provides owned analytics.
- 完整判斷需要同時看首頁是否能帶人購買，以及近期貼文是否持續有效。只有銷售頁做得好，不能證明社群內容也做得好。

## Suggested evidence row

| Date | URL | Author/collab | Pinned? | Format | Hook/topic | Visible metrics | Comment signal | CTA | Funnel destination |
|---|---|---|---|---|---|---|---|---|---|
