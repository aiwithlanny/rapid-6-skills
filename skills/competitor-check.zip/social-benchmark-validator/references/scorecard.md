# 對標帳號 100 分評分表

每次都要給出滿分 100 分的結果。只按照看得到的證據給分；看不到的資料寫「沒有看到」，不要替對方猜。

## 第一部分：有沒有人接近購買（45分）

這是最重要的一部分。使用下面其中一條路徑，不要兩條重複加分。

### A路徑：看得到公開銷量

| 項目 | 分數 | 白話判斷方法 |
|---|---:|---|
| 公開銷量或訂單證據 | 30 | 有持續、可核對的銷量最高；只有帳號自己說「賣很多」只能給少量分數 |
| 留言區詢問產品 | 10 | 有人問價格、怎麼買、適不適合、何時開課、如何取得 |
| 留言數／觀看數 | 5 | 用來輔助判斷，不能取代真正銷量 |

### B路徑：看不到公開銷量

| 項目 | 分數 | 白話判斷方法 |
|---|---:|---|
| 留言數／觀看數 | 20 | 約 1% 是平均；1.25%–3% 表現好 |
| 留言區詢問產品 | 20 | 問價格、購買、報名、適用對象的留言，比單純表情或關鍵字更有價值 |
| 下一步是否清楚 | 5 | 看完後知道要留言、點首頁、進社群或購買 |

計算方法：

`留言率 = 留言數 ÷ 觀看數 × 100%`

判斷參考：

- 少於 0.5%：偏弱。
- 0.5%–0.99%：普通偏低。
- 約 1%：平均表現。
- 1.25%–3%：表現好。
- 超過 3%：先不要直接給滿分。檢查是不是抽獎、關鍵字領資料、爭議話題或留言灌水。

如果平台沒有顯示觀看數，就不能計算留言率。改看留言內容是否在問產品，並把分數標成暫定。

## 第二部分：內容有沒有自然帶出產品（25分）

高分內容不是突然插入廣告，而是：

1. 先講觀眾正在遇到的問題；
2. 再讓觀眾看到想要的結果；
3. 產品剛好成為解決方法；
4. 看完會自然產生「我也想要」的感覺。

只說產品多厲害、與前面內容沒有關係，不能拿高分。

## 第三部分：能不能持續做、重複有效（20分）

檢查至少 6–12 篇內容；資料充足時看 20–30 篇。

- 是否持續發布，而不是只靠一篇爆紅內容。
- 相同主題或形式是否重複有效。
- 是否有可以套用的內容模板，例如「問題 → 方法 → 產品 → 下一步」。
- 一般人是否有能力照這個方法持續製作，而不是必須靠名氣、大團隊或昂貴拍攝。
- 置頂、合作、抽獎和廣告內容要分開看，不能混在一起算。

## 第四部分：適不適合成為「你的」對標（10分）

- 對方吸引的人，是不是你想賣產品的人？
- 對方賣的結果，和你提供的結果是否接近？
- 對方的做法，你目前是否有能力執行？

粉絲多但客群不同，不能算好對標。

## 分數結論

- `85–100分`：很適合，可以當主要對標。
- `70–84分`：可以對標，但只學指定部分。
- `55–69分`：只能當靈感參考，不建議整套照著做。
- `0–54分`：不建議當對標帳號。

如果公開資料不完整，仍然要先給 `暫定 __／100分`，並說清楚缺少銷量、觀看數或留言中的哪一項證據。

## Disqualifiers and downgrades

Downgrade or reject when:

- The audience follows for entertainment, controversy, celebrity, giveaways, or unrelated identity rather than the user's buying problem.
- Most visible engagement comes from one viral post, paid amplification, a collaboration, or a keyword giveaway.
- Comments are mostly bots, emojis, creator peers, or repetitive automation keywords with little market language.
- The success depends on celebrity status, a large team, expensive production, or proprietary access the user cannot reproduce.
- The account has no visible offer or conversion path and the user needs a monetization benchmark.
- The content is stale, irregular, or primarily old pinned posts presented as current activity.

## 最重要的判斷原則

- 有公開銷量，先看銷量。
- 沒有公開銷量，再看留言率與留言內容。
- 觀看量高、按讚多，不代表產品賣得好。
- 最後要看的是：觀眾有沒有詢問、點擊、加入、報名或購買。
- 大量「888」「想知道」「+1」只能證明有人願意按照指示留言，不能直接證明成交。
- 不同平台的觀看與留言習慣不同，不要把 Instagram、Threads、Facebook、X 的數字直接放在一起比較。
