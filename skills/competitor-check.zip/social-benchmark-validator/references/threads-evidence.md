# Threads evidence workflow

Use this reference for a Threads profile or post.

## Capture

- Profile promise, audience cue, credentials/proof, link, and relationship to Instagram.
- Recent 15–30 posts when accessible; distinguish original posts, replies, quotes, and reposts.
- Opening line, POV, topic pillar, post length, media use, CTA, visible likes, replies, quotes, and reposts.
- Reply quality: questions, disagreement, experience-sharing, objections, demand, and creator follow-up.
- Conversion route from post to profile, Instagram, newsletter, community, product, or booking page.

## Interpretation

- Prioritize meaningful replies, quote discussions, reposts, and repeated topic performance over likes alone.
- A provocative post may create attention without attracting buyers. Check whether commenters match the user's target audience.
- Replies are part of the content strategy: evaluate whether the creator extends ideas, qualifies leads, and moves users toward a next step.
- Do not treat a screenshot of views or a claim about reach as verified analytics unless it is visibly owned data and the user supplied it.
- Do not compare Threads raw counts directly with Instagram counts. Compare each platform against its own baseline and role in the funnel.

## Cross-platform role check

When the creator uses both Threads and Instagram, determine whether:

- Threads creates conversation and POV;
- Instagram packages proof, education, or visual discovery;
- the same CTA and offer are consistently carried across both;
- one platform merely reposts the other without platform-specific adaptation.

This decides whether the account is a strong cross-platform benchmark or only a single-platform reference.
