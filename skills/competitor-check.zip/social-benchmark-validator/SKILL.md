---
name: social-benchmark-validator
description: Evaluate whether a public social-media account is a useful benchmark for a creator, digital product, course, or service. Use when the user asks whether an Instagram, Threads, Facebook, X, TikTok, or similar account is a good 對標帳號, wants competitor-account screening, or needs content and monetization benchmarking. Distinguishes direct, content, aspirational, and adjacent benchmarks; does not treat follower count alone as proof.
metadata:
  version: "1.1.0"
---

# Social Benchmark Validator

Judge whether an account is worth benchmarking and state exactly **what role it should play**. A useful account may be a strong sales benchmark but a weak content benchmark, or vice versa.

## Beginner-language rule

Assume the reader has never created social-media content or sold a digital product.

- Start with one plain sentence: `這個帳號：__／100分。結論：可以／不建議當你的對標帳號。`
- Give the result before explaining the method.
- Use short sentences and everyday words. Explain necessary terms immediately, for example: `轉換，就是有人看完內容後去詢問或購買。`
- Do not use unexplained terms such as ER, SOV, funnel, lead magnet, CTA, hook, conversion, private traffic, or benchmark set. Replace them with plain Chinese or add a one-line explanation.
- Prefer concrete examples over marketing theory. Say `留言問價格、怎麼買` instead of `高意向互動`.
- Do not make the user read a long process description before seeing the score and decision.

## Evidence boundary

- Use public or user-visible information only. Do not access private analytics, DMs, follower lists, hidden reach, saves, revenue, or customer data.
- Separate `可見資訊` from `推斷`. Treat seller claims, testimonials, revenue claims, and follower totals as claims unless independently verified.
- Never fabricate unavailable metrics. State `未知` and explain what evidence would resolve it.
- Analyze mechanisms and gaps; do not copy wording, creative, products, or protected materials.

## Workflow

1. Establish the user's product, target buyer, price band, promised outcome, language/market, and primary platform. Infer from conversation when clear; ask only for missing information that changes the verdict.
2. Classify the candidate before scoring:
   - `直接商業對標`: similar buyer, outcome, and offer.
   - `內容對標`: useful hooks, formats, or distribution, but different offer.
   - `成熟型對標`: a larger account showing the next business stage.
   - `跨界對標`: different niche with a transferable funnel or content mechanism.
3. Inspect the live source when a link is provided. Read the relevant platform reference below.
4. Sample pinned, recent, collaboration, high-engagement, and explicit offer posts separately. Do not call pinned posts “recent” or attribute a collaboration post to only one account.
5. Score with [references/scorecard.md](references/scorecard.md). Always give a score out of 100. When sales or viewing data is unavailable, say which points could not be earned and label the score `暫定分數`.
6. Map the sales path:
   `內容 -> 使用者心理 -> 留言/私訊/點擊 -> 承接頁/社群/商店 -> 產品 -> 成交或續購`.
7. Finish with the report shape in [references/output-template.md](references/output-template.md).

## Platform routing

- For Instagram, read [references/instagram-evidence.md](references/instagram-evidence.md). Prefer a platform connector when available. Otherwise use a logged-in browser surface. Chrome is useful for visual/login checks; ego-browser is useful for isolated extraction that reuses login state. Read each selected browser skill before operating it.
- For Threads, read [references/threads-evidence.md](references/threads-evidence.md).
- For Facebook or X, use the same evidence contract and scorecard, adapting public interaction signals to the platform. Do not compare raw engagement counts across platforms.

## Minimum useful output

Lead with the score, then one of these decisions:

- `可作主要對標`
- `可作特定用途對標` — name the purpose
- `只適合靈感參考`
- `不建議作對標`
- `證據不足，暫不判定`

Always name what to borrow, what not to copy, the largest evidence gap, and one white-space opportunity the user can own.
