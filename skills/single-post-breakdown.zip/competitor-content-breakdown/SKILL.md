---
name: competitor-content-breakdown
description: Analyze same-platform competitor/social benchmark merchant accounts and market-validated content patterns for a product, niche, or offer. Use when the user asks for 对标拆解, 竞品账号拆解, 小红书/抖音/Threads/X 等目标平台账号拆解, 爆款内容拆解, market-validated content research, conversion-potential account analysis, reusable hooks, low-quality content traps, or account positioning advice based on product name, price, selling points, target users, target platform, competitors, and traffic destination.
---

# Competitor Content Breakdown

## Purpose

Use this skill to judge what content and account patterns have already been validated by the market for a specific product or niche. The goal is not to list random accounts; the goal is to separate real conversion potential from vanity heat, then extract reusable content logic.

Only use accounts from the user's target platform as benchmark accounts. If the target platform is 小红书, benchmark accounts must be 小红书 accounts; if the target platform is X, benchmark accounts must be X accounts. External websites, other platforms, and search results may be used only as background evidence, not as items in the benchmark account list.

## Required Inputs

Collect or infer these fields before analysis:

- Product name
- Product price
- Selling points
- Target users
- Target platform
- Competitors or similar products
- Desired traffic destination

If more than two fields are missing, ask the user for the missing fields. If only one or two fields are missing, make conservative assumptions and label them.

## Research Rules

- Use current platform evidence whenever possible. Search or browse when data can change, especially for follower counts, recent posts, engagement, product pages, links in bio, offers, or platform trends.
- Restrict benchmark accounts to the target platform provided by the user. If the user gives multiple target platforms, group account lists and content breakdowns by platform; do not mix accounts from other platforms into a platform's benchmark list.
- The main benchmark list must contain 10 accounts whenever the platform has enough evidence. Each selected benchmark account must include a clickable account/homepage link from the target platform. Do not count an account toward the 10-account benchmark list if only the account name is known and no clickable profile/homepage link is available. Search-result links may be included as supporting evidence, but they do not replace the required account link.
- If fewer than 10 qualified accounts with profile/homepage links can be verified after reasonable research, state the shortfall clearly, include only verified linked accounts in the benchmark table, and add a "待补充账号" note with the exact keywords or platform paths needed for manual follow-up.
- Define benchmark accounts as merchant or creator accounts on the target platform that resemble the user's account positioning, product, content, or audience. Classify each candidate as one or more of:
  - Product benchmark: similar category, price band, selling point, target user, or purchase scenario.
  - Content benchmark: similar presentation form, content quality, topic style, or production level.
  - Audience benchmark: similar follower size, follower profile, user needs, or comment behavior.
- Search precise keywords first: brand/product words, core effect words, category words, industry words, and competitor words. Then expand to broad keywords: hot-search words, related words, scenario words, pain words, and audience words.
- Find candidates through platform search result account lists, high-performing notes/posts, comment sections, shop result pages, live/shop tabs, or related recommendation flows.
- Apply these hard benchmark-account filters before selecting accounts:
  - Followers must be 1,000+.
  - The account must have posted or updated within the past month.
  - At least 90% of the homepage's visible/recent content must be related to the user's input product, category, or directly adjacent buyer problem.
  - Average likes across the account's recent visible posts must be greater than 100.
  - If any filter cannot be verified because the platform hides data or blocks access, mark that field as "未确认" and use the account only as a secondary candidate unless its other evidence is unusually strong.
- Prefer accounts with visible monetization paths: profile link, lead magnet, consultation, course, paid community, product page, shop, booking page, newsletter, app download, or repeat CTA.
- Do not treat high likes as enough. Check whether the account repeatedly attracts the target user's problem language, purchase intent, questions, saves, shares, comments, DMs, or link-click intent.
- Prefer recently active, growing accounts with good explosive-post interaction, fast topical updates, clear originality, and monetization paths matching the user's goal.
- For ordinary-person reference accounts, prioritize 5k-100k followers. Prioritize 5k-10k or under-10k accounts when the user needs realistic early-stage benchmarks. Avoid accounts below 1k followers unless a post has unusually strong evidence, and avoid accounts above 100k followers when their authority, team, or brand scale makes them hard to imitate.
- When the target platform exposes shops or sales ranking, search core industry keywords, filter accounts with matching fan profile and 5k-100k followers, then sort by sales or shop performance and select the top three strongest accounts as priority benchmarks.
- Avoid accounts whose traffic depends mainly on personal fame, controversy, giveaways, gossip, sexualized attention, platform-native entertainment unrelated to buyer intent, obvious data fraud, low originality, or low-quality repetitive content.
- Compare content against product fit: audience match, pain intensity, buying urgency, price tolerance, trust requirement, and path to conversion.

## Workflow

1. Clarify the offer.
   - Restate the product, price band, target user, core promise, and traffic destination.
   - Identify the likely buying trigger: pain relief, status improvement, income gain, time saving, risk avoidance, identity expression, or convenience.

2. Build benchmark search angles.
   - Search by product category, user pain, desired outcome, competitor names, alternative solutions, and content phrases users would search or comment.
   - Use target-platform searches only when selecting benchmark accounts.
   - For each angle, look for accounts that publish repeatedly about the same buyer problem, not only one viral post.

3. Select benchmark accounts.
   - Choose exactly 10 benchmark accounts when possible.
   - Every selected account must have a clickable target-platform homepage/profile link. If no account link is available, keep researching or exclude it from the 10-account list.
   - First exclude accounts that fail the hard filters: under 1,000 followers, no update in the past month, less than 90% product/category relevance on visible homepage content, or average recent likes at or below 100.
   - Mix product benchmarks, content benchmarks, audience benchmarks, direct competitors, adjacent solution accounts, creator-led educators, and small high-efficiency merchant accounts.
   - For each account, record why it qualifies as a benchmark and what conversion signal is visible.
   - If platform shop or sales data is visible, include the top three sales-ranked candidates for the core keyword when they match the user's target user and price band.

4. Break down benchmark content.
   - Select exactly 5 explosive posts/notes from the 10 benchmark account homepages when possible.
   - Each selected explosive post/note must include a clickable content link from the target platform. If a content link cannot be verified, do not count it as one of the 5.
   - Selection mix:
     - 1 post/note with strong visible data performance, such as unusually high likes, saves, shares, views, or above-account-baseline engagement.
     - 1 post/note with high comment volume or unusually strong comment quality.
     - 1 post/note with the strongest estimated conversion or lead-capture potential.
     - 2 additional posts/notes that satisfy the same quality standard: high data, high comment signal, strong conversion bridge, or strong product fit.
   - Prefer recent posts/notes from each benchmark account's visible homepage content. Inspect recent 10 posts/notes when visible, but prioritize evidence quality over recency when the platform hides dates.
   - Combine content breakdown and structure breakdown into one explosive-content analysis section. Do not separate "what it says" from "why it works"; explain why users stop, read, save/comment, and take action.
   - Capture the content topic, cover hook, page structure, copywriting logic, emotional trigger, proof element, CTA, audience reaction, conversion path, and what the user can replicate.

5. Score signal quality.
   - Market validation: Does repeated content prove the audience cares?
   - Conversion potential: Does the content attract people likely to buy or leave leads?
   - Product fit: Can this pattern sell the user's specific offer at its price?
   - Replicability: Can a new or smaller account reuse the pattern without celebrity status or heavy production?
   - Risk: Is the pattern platform-gimmicky, low-trust, hard to sustain, or misaligned with the user's brand?

6. Synthesize reusable rules.
   - Extract common topic clusters, hook formulas, proof mechanisms, narrative arcs, CTA patterns, and comment triggers.
   - Pull new topic ideas from platform search dropdown terms, search-result related tags/phrases, and high-like comments under benchmark explosive posts.
   - Separate "can copy the structure" from "should not copy the exact style."
   - Convert patterns into templates the user can adapt immediately. When recommending imitation, imitate the title structure, scene angle, layout logic, and high-interaction elements, then replace the benchmark account's proof and offer with the user's differentiated selling point.

## Output Format

Return the answer in Chinese unless the user asks otherwise. Use tables for scan-heavy sections. Default to producing a Markdown document (`.md`) in the workspace when the user asks for a full research output or workbench-ready artifact. The Markdown document should be easy to copy into Feishu, Notion, Yuque, or a content production workbench.

Use this final document structure by default:

1. 产品与用户判断
2. 对标账号表
3. 爆款内容拆解（5 个，内容拆解和结构拆解合并）
4. 可复用的钩子模板
5. 避坑内容
6. 账号定位建议
7. 30 条可直接发布选题（每个选题后附可对标的内容链接）

### 1. 产品与用户判断

Include:

- Product, price, selling points, target user, target platform, competitor category, traffic destination.
- Buying trigger: pain relief, status improvement, income gain, time saving, risk avoidance, identity expression, or convenience.
- Strongest user pain, strongest desire, trust barrier, price sensitivity, and why the user would act now.
- Best-fit content promise and conversion angle.

### 2. 对标账号表

Include columns:

- 账号/链接
- 平台
- 对标类型: 商品对标/内容对标/粉丝对标
- 账号定位
- 粉丝量/体量
- 近一月是否更新
- 主页内容相关度是否 >=90%
- 近 visible 内容平均点赞是否 >100
- 赞藏数/互动体量
- 主要产品或变现路径
- 店铺/直播/专栏/私域/广告情况
- 代表内容方向
- 转化潜力判断
- 为什么值得对标
- 风险或不适合照抄之处

Rules:

- Provide 10 accounts when possible.
- Every row must include a clickable account/homepage link. If no account link is available, do not include the account as one of the 10.
- If a metric is hidden, write "未确认" and explain the evidence that still makes the account useful.
- Search-result links, screenshots, or external proof may be included in notes, but the table's account link must be a profile/homepage link.

### 3. 爆款内容拆解（5 个）

Select 5 posts/notes from the 10 benchmark account homepages. Each selected post/note must include a clickable content link. Required selection mix:

- One with strong visible data performance.
- One with high comments or strong comment quality.
- One with the strongest estimated conversion/lead-capture potential.
- Two additional posts/notes that satisfy the same quality standard.

For each explosive post/note, use this workbench-ready template:

#### 爆款 X：标题或主题

**一、基础信息**

| 字段 | 内容 |
|---|---|
| 账号名称 |  |
| 账号链接 |  |
| 内容链接 |  |
| 平台 | IG / 小红书 / Facebook / Threads / X |
| 内容类型 | 教程型 / 清单型 / 避坑型 / 对比型 / 案例型 / 故事型 / 观点型 / 卖货型 |
| 目标用户 |  |
| 产品/服务 |  |
| 发布时间 |  |
| 数据表现 | 点赞 / 评论 / 收藏 / 转发 / 浏览 / 私信引导 |
| 入选原因 | 数据好 / 评论多 / 转化引流强 / 产品适配强 / 结构可复用 |
| 判断它爆的标准 | 互动率高、收藏高、评论争议强、转化动作明显、内容可复用等 |

**二、一句话判断这篇图文为什么爆**

Use this sentence pattern:

这篇内容爆，不是因为设计好看，而是因为它精准击中了【目标用户】在【具体场景】里的【强痛点/强欲望】，并用【简单结构】给了一个看起来马上能用的解决方案。

**三、拆封面：用户为什么停下来？**

Include:

- 原封面标题
- 标题类型: 痛点型 / 结果型 / 反常识型 / 清单型 / 对比型 / 避坑型 / 挑衅型
- 封面钩子公式: 目标用户 + 当前问题 + 强结果/强冲突
- 画面主体: 人物 / 大字 / 产品 / 截图 / 对比图 / 表格 / 场景图
- 颜色风格: 高级简洁 / 明亮活泼 / 黑白极简 / 强冲突色 / 品牌感
- 信息密度: 高 / 中 / 低
- 第一眼看到什么
- 是否降低理解成本
- 是否强化情绪: 焦虑 / 好奇 / 爽感 / 危机 / 欲望 / 认同
- 封面可复用模板

**四、拆正文结构：用户为什么看完？**

Use a page-by-page table:

| 页面 | 内容 | 作用 | 是否推动用户继续看 | 可复用点 |
|---|---|---|---|---|
| 第1页 |  | 让用户停下 | 是/否 |  |
| 第2页 |  | 放大痛点/制造共鸣/提出观点等 | 是/否 |  |

Also identify the main progression logic:

- 痛点 → 原因 → 方法 → 示例 → 行动
- 误区 → 真相 → 方法 → 模板 → 结果
- 问题 → 对比 → 解决方案 → 操作步骤 → CTA

Do not merely summarize what each page says. Explain what each page does psychologically and structurally.

**五、拆文案：它是怎么让人有感觉的？**

Include:

- 开头是否指出具体问题、制造情绪共鸣、暗示解决方案
- 核心句式
- 是否有反常识
- 是否有痛点共鸣
- 是否有具体方法
- 是否有模板/清单/案例
- 最值得复用的一句话
- 情绪按钮: 焦虑 / 好奇 / 爽感 / 危机 / 认同 / 欲望 / 信任

**六、拆价值：用户为什么收藏？**

Classify the collection value:

- 模板价值: 用户可以直接照抄
- 清单价值: 用户觉得以后用得上
- 步骤价值: 用户知道下一步怎么做
- 认知价值: 用户突然想明白一个问题

If none of these values exist, say the post likely depends on account traffic rather than strong content structure.

**七、拆转化：它怎么让用户行动？**

Include:

- CTA 类型: 收藏、评论关键词、私信领取模板、点击主页链接、关注账号、购买产品、预约咨询、加入社群、下载资料
- CTA 出现位置
- CTA 是否自然
- 前文是否铺垫
- 用户看完是否真的需要下一步
- CTA 可以怎么优化

**八、最终输出：提炼成可复用模板**

Include:

- 爆款结构模板
- 可复用标题公式
- 封面公式
- 页面结构
- 文案公式
- CTA 公式
- 迁移到用户产品的 5 个选题

The explosive breakdown must answer: "Can the user immediately replicate 5 similar posts after reading this?" If not, continue refining.

### 4. 可复用的钩子模板

Provide 10-20 templates. Make them specific to the user's product, target user, platform, traffic destination, and price point. Avoid generic hooks such as "你一定要知道..." unless adapted with concrete buyer pain.

### 5. 避坑内容

List patterns to avoid and explain why:

- Vanity-traffic topics that do not attract buyers
- Overbroad motivational content
- Pure trend-chasing without product bridge
- Fake scarcity or exaggerated income claims
- Too much education with no conversion path
- Personal diary content without transferable buyer insight
- Content that only works for already-famous creators

### 6. 账号定位建议

Recommend 2-4 positioning directions. For each direction include:

- Positioning sentence
- Best audience segment
- Content pillars
- Trust-building method
- Traffic destination fit
- First 10 content ideas
- Main risk

### 7. 30 条可直接发布选题

Provide a table with 30 immediately usable content ideas. Each row must include:

- 选题标题
- 对应用户痛点
- 内容类型
- 封面钩子
- 正文结构
- CTA/转化动作
- 可对标内容链接
- 为什么适合这个产品

Every topic must include a comparable content link from the benchmark accounts or the verified explosive-post pool. If no exact comparable content link is available, use the closest verified benchmark content link and mark the match type as "结构对标" or "痛点对标".

## Quality Bar

- Name concrete evidence for every "值得对标" claim.
- Distinguish "热度高" from "转化潜力强."
- Prefer 10 linked, qualified accounts. If 10 cannot be verified, prefer fewer linked accounts over unlinked or weak accounts, and state the evidence gap.
- Do not output unlinked account names as benchmark accounts.
- Do not output explosive posts/notes without content links as the 5 selected breakdowns.
- Make final recommendations actionable enough for the user to plan posts.
- When evidence is limited, say so and mark the conclusion as tentative.
- The final output should be practical enough that the user can immediately replicate at least 5 similar posts from each explosive breakdown.
