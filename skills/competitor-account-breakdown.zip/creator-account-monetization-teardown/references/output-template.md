# Output Template

Use this structure for Chinese creator-account monetization teardowns. Keep the answer concrete and based on visible evidence.

## Account Case

**账号案例：{account name} / {positioning or offer}**

主页链接：[{account name}]({url})

公开数据：{visible followers/posts/likes/saves/etc.}. 简介/主页可见定位："{bio or CTA}".

**账号主题**  
Explain what the account is really about. Distinguish content topic from commercial offer.

**目标人群**  
Name the audience by identity, pain, desire, budget or purchase readiness.

**内容钩子**  
List the strongest repeatable hooks and explain why they work.

**数据较好的内容**

| 排名 | 内容/笔记 | 公开互动数据 | 主题/做的内容 | 评论区/转化信号 | 链接 |
|---|---|---:|---|---|---|
| 1 | ... | ... | ... | ... | [打开](...) |

If exact top-ten ranking is unavailable, say "以下是当前可见样本中数据较好的内容" and avoid pretending it is a complete platform-wide ranking.

**内容结构**  
1. 先抓一个身份、场景或结果型痛点  
2. 给出具体结果或反差  
3. 展示方法、产品、工具、过程或案例  
4. 用人设、经验、数据、客户反馈或品牌背书建立信任  
5. 用评论、私信、主页链接、店铺、表单或活动页完成承接

**情绪或痛点触发点**  
List anxieties, desires, identity shifts, objections, urgency, and practical needs.

**提供了什么价值**  
Separate surface content value from deeper commercial value.

Example:  
表层价值：教程、清单、经验、审美、选品、工具推荐。  
深层价值：课程、咨询、培训、产品销售、品牌合作、社群、活动报名、联盟推广。

**引流动作**  
Name the visible CTA: comment keyword, DM, shop, link-in-bio, email, booking, free resource, group buy, event registration, or "立即咨询".

**承接路径**  
Write the funnel:

`内容 -> 用户心理 -> 评论/私信/点击 -> 承接页面/店铺/顾问 -> 产品/服务/合作 -> 成交/报名/申请`

**评论区是什么**  
Summarize comment patterns as market signals:

- 索取型：求链接、求资料、想要、怎么拿、价格、报名。
- 疑问型：能不能用、适不适合我、成本、语言、型号、尺码、时间、门槛。
- 情绪型：共鸣、惊叹、羡慕、被种草。
- 信任型：买过、用过、反馈、祝贺、认可人设。

**他/她是怎么变现的**  
Separate visible monetization from inferred monetization:

- 可见信息：bio、店铺、链接、课程页、咨询页、活动页、品牌合作、联盟链接、商务邮箱。
- 推断：基于内容和评论判断的高概率变现方式。
- 弱信号：只作为可能性，不下结论。

**为什么这个账号值得学**  
State the transferable strategic insight.

**可复制模板**  
Write a reusable formula:

`我知道你有一个痛点/身份 -> 但它可以被重新解释成机会 -> 我用一个具体案例/结果证明 -> 给你一个低门槛方法/产品 -> 用评论/私信/链接承接 -> 后端卖课程/咨询/产品/服务/合作`

**可迁移方向**  
List adjacent industries or creator types that can reuse the pattern.

## Single Post/Card

**案例：{format} / {topic}**

内容链接：[{title}]({url})

公开数据：{visible likes/comments/saves/shares/views/date}. 作者：{creator}.

**内容主题**  
Summarize the post's promise.

**目标人群**  
Describe who this post is for and why they care now.

**首屏/开头钩子**  
Quote or paraphrase the opening hook and explain the mechanism.

**内容结构**  
1. 先建立人设、经验、场景或结果  
2. 点出痛点、欲望或反差  
3. 引出方案、产品、工具、资源或服务  
4. 展示步骤、细节、证明或使用效果  
5. 用评论、店铺、主页链接、私信或表单承接

**情绪或痛点触发点**  
Name the engagement and purchase triggers.

**提供了什么价值**  
Explain practical value and perceived value.

**引流动作**  
Describe the exact CTA and any keyword/comment behavior.

**承接路径**  
Map the conversion route.

**评论区是什么**  
Summarize demand, objections, friction, social proof, and creator replies.

**怎么变现**  
Name the visible or likely offer connected to the post.

**为什么这个案例值得学**  
State the core lesson.

**可复制模板**  
Give a reusable post formula.

**可迁移方向**  
Optional, only if clear.
