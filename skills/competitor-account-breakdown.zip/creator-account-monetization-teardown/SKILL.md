---
name: creator-account-monetization-teardown
description: Analyze creator accounts or single social posts into a Chinese monetization teardown using the user's case-card format. Use when the user asks to 拆解/分析/复盘/打包 an Instagram, Xiaohongshu, TikTok, YouTube, Threads, X, or similar creator account/post and wants themes, hooks, best content, comments, funnel, monetization, and reusable templates.
---

# Creator Account Monetization Teardown

## Purpose

Turn a creator account, post, reel, carousel, or link-in-bio into a practical Chinese case teardown for learning positioning, content strategy, audience psychology, and monetization.

Default to the user's Chinese variant. If the user writes Traditional Chinese, answer in Traditional Chinese. If they write Simplified Chinese, answer in Simplified Chinese.

## When To Use

Use this skill when the user asks for any of the following:

- 拆解一个账号、笔记、图文、短视频、Reels、主页或 link-in-bio.
- 按“上面的模板”分析账号或内容.
- 找账号最好的内容、主题、评论区、引流动作、承接路径、变现方式.
- 把一个账号案例整理成可复制打法、内容模板、商业模型或 skill.

## Source Rules

Inspect the live source when the user provides a link. Use browser-capable tools for dynamic platforms. Use web search only when public pages are blocked, source pages cannot load, or cross-checking is needed.

## Browser Plugin Integration

Live-link analysis should use the installed OpenAI browser plugins as a capability stack. Before browser work, read and follow the selected plugin's skill instructions and check whether a purpose-built connector, API, or CLI can handle the source.

Use the smallest sufficient surface:

1. **Chrome** — Prefer when the target depends on the user's existing Chrome state, including logged-in social platforms, already-open tabs, or pages blocked in anonymous sessions.
2. **Browser** — Prefer for public pages that do not need the user's Chrome state. It is also the anonymous fallback when a public source can be inspected without authentication.
3. **Computer Use** — Use only when the selected browser surface cannot expose the visible or interactive state needed for the teardown and the Computer Use plugin is available. Do not switch to it merely because it appears easier.

Treat these as runtime capabilities, not permission to install software or change browser settings. A skill cannot declare Chrome, Browser, or Computer Use as auto-installable dependencies in `agents/openai.yaml`; that dependency field currently supports MCP tools only. If one of the browser plugins is missing:

- use Plugin Management to discover the exact official plugin when that capability is available;
- ask the user to install or connect it before any installation, extension, permission, or account action;
- continue with other public evidence only when it can still support an honest teardown;
- state the missing evidence plainly instead of fabricating metrics, comments, prices, or funnel details.

Collect public/visible data only:

- Account name, handle, profile link, bio, category, verification, follower count, post count, visible total likes/saves if the platform shows them.
- Pinned content, recent content, strongest visible posts, and offer/sales posts.
- Post format, caption/body, first-screen hook, publish date, visible likes/comments/saves/shares/views when available.
- Comments that show purchase intent, demand, objections, usage friction, social proof, keyword replies, or creator replies.
- Bio links, shops, booking pages, forms, newsletters, group buys, courses, templates, tools, consultations, events, communities, affiliate links, emails, and brand collaboration signals.

Do not invent metrics, prices, credentials, comment text, hidden products, or private funnel details. Mark unavailable data plainly.

## Analysis Lens

Separate observed facts from inference:

- Use `可见信息` for facts directly visible on the platform or linked pages.
- Use `推断` for reasoned conclusions, especially monetization and funnel analysis.

Treat the account as commercially useful when at least one offer or conversion path is visible:

- Profile bio names an offer, shop, consultation, course, training, product, email, booking, freebie, group, or CTA.
- Comments ask for price, link, how to buy, how to join, source code, tool name, class schedule, sizing, delivery, compatibility, or materials.
- Creator routes users to DM, comments, shop, link-in-bio, form, event page, or keyword automation.
- Repeated content points to a named product, service, framework, resource, course, camp, credential, event, template, skill, checklist, or paid offer.

If engagement is strong but there is no clear offer, say the account is currently stronger as attention/IP than as a visible conversion machine.

## Workflow

1. Identify whether the URL is an account, one post, a bio link, a shop/product page, or a campaign page.
2. Capture profile positioning and visible business signals.
3. For accounts, sample pinned posts, recent posts, high-engagement posts, and explicit sales/offer posts. For one post, inspect the post, caption, comments, CTA, and any linked offer.
4. Extract the repeatable formula:
   - Hook: title, first slide, first 3 seconds, or opening line.
   - Audience: who immediately feels "this is about me".
   - Pain/desire: anxiety, identity conflict, practical job-to-be-done, aspiration, or purchase trigger.
   - Proof: credentials, experience, numbers, examples, testimonials, before/after, brand names, student/customer results, or lived experience.
   - Solution: product, service, tool, course, resource, event, community, or content promise.
   - CTA: comment keyword, DM, shop, bio link, booking, email, follow, save, share.
5. Read comments as market research:
   - Demand: "想要", "求链接", "怎么拿", "可以分享吗", "价格", "报名", "咨询".
   - Friction: language, cost, login, delivery, setup, sizing, schedule, skill level, tool compatibility.
   - Objections: trust, price, difficulty, authenticity, fit, time, risk.
   - Social proof: bought, used, result feedback, peer validation.
6. Map monetization:
   `内容 -> 用户心理 -> 评论/私信/点击 -> 承接页/店铺/顾问 -> 产品/服务/合作 -> 成交/报名/申请`
7. Output in the user's requested format. If the user references the previous template, read `references/output-template.md` and use it.

## Output Standards

- Lead with the case name, link, and public data.
- Include a table for best-performing content when multiple posts are available. Add post links whenever visible.
- Explain comments as demand signals, not just "评论很多".
- State monetization directly: what is being sold now, what is likely being monetized, and what is only a weak signal.
- End with a reusable template that the user can copy into another niche.

## Reference

Read `references/output-template.md` when the user asks for a template-style teardown, says "按上面的模板", wants a teaching-ready case card, or asks to package the teardown method as a repeatable skill.
