# OOS Intake

Use this interview to create a useful first system, not a complete biography.

## Opening

Explain in your own words:

> OOS is not another todo app. You keep talking naturally; your Agent records, connects, reminds, reviews, and keeps a small local HUD focused on what matters. Once installed, it is ready to use, and we can keep customizing and iterating afterward.

Use “your Agent” when instructions must work across Codex, Claude Code, and other compatible Agent Skills runtimes.

## Required questions

Ask conversationally and combine related questions when appropriate:

1. What should OOS call you, and what timezone should it use?
2. What are the 1-3 Tracks that matter now?
3. For each Track: where are you, what result matters, and is there a real deadline or hard window?
4. What signal shows progress, and what is the smallest next action?
5. What usually blocks movement: forgetting, overwhelm, unclear next step, energy, waiting, avoidance, or perfectionism?
6. When should OOS help: morning planning, live capture, evening review, weekly review, or just-in-time coaching?
7. What should stay private, be summarized gently, or stay out of the HUD?
8. Which theme color would make the HUD feel like yours? Accept a named color or hex value, convert the confirmed choice to a six-digit hex token in the plan, and use neutral charcoal `#111111` when the user has no preference.

Do not ask the user to select domain modules. Today, Plan, and Tracks are the fixed core navigation. Quick Capture/search/Track context provide notes; Today closeout and periodic entry provide review. Model life domains inside Tracks.

Do not ask for visual assets during intake. Wait until the installed system is operational and the user explicitly asks to “加入灵魂” or personalize visuals.

## Personal OOS Plan

```markdown
# Personal OOS Plan

## User
- Name:
- Timezone:
- Use rhythm:
- Theme color:

## Main Tracks
1. Track:
   - navLabel:
   - Type:
   - Current stage:
   - Target:
   - Metric:
   - Metric key / unit / numeric target / direction (when applicable):
   - Inferred operational view:
   - Deadline / hard window:
   - Structured milestones / checkpoints:
   - First-week actions and intended dates:
   - Next action:
   - Risk / question:

## Current Truth
- Next 24-72 hours:
- Long-term notes:

## Privacy
- Hide or summarize:
- Never include:

## First Week
- First 1-3 actions:
- First checkpoint:
- First Flight: offered / skipped / completed
```

Use only 1-3 active Tracks. Put additional areas in Inbox or watch state without adding navigation sections. Derive `navLabel` from the Track name and keep it to 4-8 Chinese characters or 10-18 Latin characters. Ask only when a safe shortening is not obvious.

Infer the operational view from the Track archetype and the user's progress signal. For example, a numeric body-weight Track becomes `trend` with a `trend-line` view, while a workout practice becomes `habit` with a `habit-heatmap`. Show the inferred view in the plan for confirmation, but do not turn intake into a widget picker.

Wait for confirmation before initialization. Preserve supplied `trackType`, explicit `nextActionDue`, `needsQuestion`, `useRhythm`, `privacy`, `watchTracks`, `currentTruth`, `firstWeek`, and `theme`. Convert every explicitly dated hard window into a structured milestone instead of compressing several dates into one prose field. Preserve learning checkpoints, pipeline stages, habit plans, and structured first-week actions. Never convert an unknown deadline into “today.”

For `init_oos.js --plan`, prefer top-level `owner`, `timezone`, `useRhythm`,
`theme`, `tracks`, `privacy`, `currentTruth`, and `firstWeek`. A nested
`user: { name, timezone, useRhythm }` object is also accepted and preserved.
Track views must follow the canonical source contract in `goal-model.md`.

Preferred structured fields inside a Track:

```json
{
  "milestones": [{ "title": "Confirm direction", "date": "2026-08-02" }],
  "checkpoints": [{ "title": "First mock test", "date": "2026-08-09" }],
  "stages": ["lead", "proposal", "delivery", "done"],
  "habitPlan": { "days": ["Mon", "Wed", "Fri"], "targetTime": "23:30", "actionTime": "23:00" },
  "initialTasks": [{ "title": "Prepare the first outline", "scheduleDate": "2026-07-24", "estimatedMinutes": 60 }]
}
```

Only use the fields that match the Track archetype. These are operational commitments, not invented progress logs.

## Defaults

- Mark unclear progress as pending or a low explicit estimate.
- Use checkpoints only when they are clearly labeled as review dates, not invented deadlines.
- Keep Relationship and other sensitive areas as ordinary private Tracks unless the user later requests specialized behavior.
- Initialize with the complete local HUD and intentional typography, route geometry, and abstract line work. Visual personalization is optional and never blocks verification, startup, or everyday use.
