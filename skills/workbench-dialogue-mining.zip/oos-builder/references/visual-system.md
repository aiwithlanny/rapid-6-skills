# OOS Visual System

The HUD is an operational cockpit, not the source of judgment. It must be complete and usable without personalized assets.

## Fixed information architecture

Keep these core pages:

- Today: current block, next actions, overdue items, continuity, system health.
- Plan: canonical schedule blocks and unscheduled work.
- Tracks: progress, stage, risk, next action, and related context.
- Quick Capture/search/Track context: external brain and linked ideas without another primary page.
- Today closeout/periodic entry: reflection derived from tasks, execution evidence, receipts, and real logs.

Do not ask users which author-domain modules to install. Represent work, learning, health, content, business, renovation, relationships, and other areas as Tracks. Add specialized pages only in a later, explicit customization request.

Track navigation labels must remain legible: 4-8 Chinese characters or 10-18 Latin characters. Prefer a clear noun phrase; do not truncate into ambiguity.

## Default visual language

- calm cockpit / workbench composition;
- dark neutral linework on warm light surfaces;
- readable panels and generous negative space;
- one user-selected theme color for emphasis;
- responsive layouts and accessible contrast;
- deterministic local icons or abstract scenes that require no external provider.

Use neutral charcoal `#111111` only when the user declines to choose a theme color. Apply the user's confirmed named color or hex value otherwise, while preserving contrast and semantic warning/success colors.

Avoid shiny generic SaaS styling, decorative density, domain-specific assumptions, copied private assets, and imagery that competes with next actions.

## Complete asset-free HUD

The initialized HUD is a finished operational product, not a preview. It must load every core page, expose real empty states, and support its documented task, schedule, note, and review loops without generated images.

Keep the first screen data-first: a compact hero, Now → Next → Later progression, hard windows, attention, recent evidence, Quick Capture, and Track continuity. First Flight starts from a visible guide card and must not cover the working HUD automatically.

Visual personalization is an optional enhancement. Skipping it must not create a health warning, keep onboarding open, or fail operational verification.

## Core operational components

The asset-free HUD still includes mature interactive instruments:

- a desktop Plan workbench backed by canonical `scheduleBlocks`: four-week overview above the selected-day timeline, with a sticky unscheduled shelf beside both;
- draggable and resizable unlocked blocks with 15-minute snapping;
- cross-date block dragging from the overview while preserving time and duration;
- date-level or precise timeline placement for unscheduled tasks, plus a click fallback;
- locked fixed blocks that cannot be moved;
- overlap previews and conflict warnings without automatic rearrangement;
- keyboard-accessible edit controls for users who cannot drag.

The selected day and its scheduled cards are one projection, not separate panels or data. Do not add a duplicate weekly board or a second agenda to the default workbench. Keep week, month, and agenda as optional inspection modes. Plan has no decorative Hero. Critical calendar text must be at least 11px, body and controls 12-13px, block titles 13px, section titles 16-18px, and controls at least 32px high. Check 1280x720, 1440x900, and 1920x1080 desktop layouts for overlap and horizontal overflow.

Moving or resizing a block is one version-protected mutation. On `409 state_conflict`, reload the current state, retain a description of the attempted change, and ask the user to retry instead of silently overwriting.
When a protected change returns `needs_review`, show a confirmation drawer that explains the impact. Confirming must resubmit only the intended ops with a new mutation id and `confirmedMajor: true`; cancelling must leave state unchanged.

## Track visualization registry

Render the Track's declared compatible `views`, or infer the archetype default from `goal-model.md`. Use the same visual grammar across archetypes—typography, route lines, restrained geometry, and the user's accent—while giving each data shape the correct instrument.

- Trend lines show actual dated measurements, units, and an optional target line.
- Habit grids show explicit check-ins, not activity volume guessed from unrelated notes.
- Project timelines show recorded milestones and hard windows.
- Pipeline boards count real entries by stage.
- Learning coverage shows recorded sessions, coverage, or hours.
- Relationship rhythm uses only explicitly authorized entries and avoids inferred scores.

Every visualization needs a real empty state, long-label handling, narrow-screen fallback, and a textual summary that remains useful without the chart.

## Optional visual soul

Read `persona-assets.md` only after the user asks to “加入灵魂”, add a persona, or personalize scenes. Keep the process provider-neutral and reversible. Preserve the abstract line-and-geometry HUD as the fallback even after custom assets are applied.

## HUD behavior

- Project current state; do not make strategic decisions.
- Keep Today to 1-3 action-ready priorities.
- Show schedule conflicts without silently moving blocks.
- Keep private details summarized.
- Route clear mutations through state ops with version protection.
- Provide useful loading, empty, error, and conflict states.
- Expose the Worker without pretending it is AI: show recent execution, pending Agent classification, protected changes, failures, and resulting State versions in a compact “后台同步” drawer.

## Public template

- Ship a complete generic asset-free HUD.
- Ship the verified frontend and State Runtime as bundled code; do not ask the installing Agent to recreate pages, calendars, charts, sync, or error handling.
- Keep user changes in state, brain, theme tokens, `public/public-overrides.css`, optional assets, and explicit extensions.
- Remove private images and personal state.
- Keep sample content generic and sparse.
- Describe the promise as: “Install it and use it immediately; keep customizing and iterating afterward.”
