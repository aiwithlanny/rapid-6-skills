# OOS Maintenance

Use this reference when operating an existing OOS after initialization.

## Main Principle

Protect the main chat. The main chat is for judgment, writing, decisions, and coaching. State maintenance should run as a background side effect whenever possible.

The embedded Worker is deterministic local code, not a model or subagent. It executes approved State Ops and projections. An Agent interprets language and decides which operation fits. A host may optionally use a subagent for extra reasoning, but that subagent still writes through State Ops.

## First Flight

After the HUD starts, offer a short operational walkthrough:

1. Capture one real sentence from the user.
2. Apply one reversible state operation.
3. Confirm the corresponding HUD view refreshes.
4. Point out where Current Truth, the Track, and the next action live.

Let the user skip First Flight. Record it as `offered`, `skipped`, or `completed`; skipping never blocks installation or daily use. When the user returns, resume from the first unfinished step without repeating intake or initialization.

## Two-Layer Operation

- Chat brain: interpret what the user said and give the real-world implication.
- State ops / worker hand: apply small updates to state and HUD.

Example:

User: "The brand script is done."

Main chat:
"Great, the deliverable moves from script to filming / rough cut. Next minimum action is a shot list."

Background ops:

- mark script task done;
- set rough-cut task in progress;
- remove stale question;
- add activity;
- HUD refreshes.

## Fast Capture

Use fast capture for low-risk facts:

- weight, food, sleep, workout;
- task completed / submitted / waiting;
- sample arrived, designer replied, brand feedback;
- small mood or energy status;
- quick idea or note.

Fast capture should update state only. Markdown consolidation can happen in daily or weekly maintenance.

## State Ops

Use the generated workspace CLI as the normal Agent-to-state binding:

```text
node scripts/oos-state.js meta
node scripts/oos-state.js op --expected-version <version> --file <ops.json>
```

The CLI prefers the running HTTP Runtime so an open HUD receives an immediate `state.changed` event. Before using HTTP it compares the server's hashed workspace instance id with its own, so a same-port server from another OOS is never treated as the current workspace. If the server is offline or belongs to another workspace, it uses the same file lock, reducer, validation, receipt, backup, and atomic write locally; the HUD will discover the new version when it starts or through polling after the server returns. Never patch `data/state.json` directly during normal capture.

Read `meta.scheduleChanges` before proposing new calendar edits. It is a receipt-derived maintenance feed for HUD and Agent schedule mutations, while `scheduleBlocks` remains the only schedule truth.

Use deterministic operations for small reversible changes. The generated workspace exposes the same registry through `node scripts/oos-state.js ops`.

<!-- OOS_OPERATION_REGISTRY_START -->
> 本表由 `lib/oos-operations.js` 生成；CLI、reducer 与 Agent 指南共用同一注册表。

| Operation | 类别 | 用途 | 输入 |
| --- | --- | --- | --- |
| `task.create` | task | 创建 canonical task；可执行任务由 Worker 自动排期。 | task |
| `task.update` | task | 更新任务字段，不维护任何平行任务状态。 | targetId + patch |
| `task.complete` | task | 完成整个任务并原子处理关联时间块、问题、里程碑、子任务和依赖。 | targetId + triggeringBlockId? |
| `task.reopen` | task | 重新打开任务；不会复活旧时间块。 | targetId |
| `task.archive` | task | 将任务作为历史归档。 | targetId + reason? |
| `task.focus` | task | 将任务设为当前聚焦项。 | targetId |
| `task.pinToday` | task | 将任务放入 Today 的 now 槽位。 | targetId |
| `task.lifecycle.maintain` | task | 运行确定性的任务生命周期清理与唤醒。 | today? |
| `goal.update` | track | 更新 Track 的说明性阶段、风险和指标。 | targetId + patch |
| `question.upsert` | state | 新增或更新显式开放问题。 | question |
| `question.resolve` | state | 解决一条开放问题。 | targetId |
| `activity.add` | state | 追加一条已确认事实。 | text + relatedGoal? |
| `note.add` | state | 新增一条灵感或笔记。 | note |
| `note.update` | state | 更新笔记的分类和关联。 | targetId + patch |
| `review.add` | state | 记录一次结构化回顾。 | review |
| `relationship.add` | state | 在启用关系模块时追加关系记录。 | entry |
| `relationship.record` | state | 按稳定 ID 记录关系条目。 | entry |
| `pipeline.add` | state | 追加抽象化商机管线记录。 | entry |
| `commercial.deal.create` | state | 创建抽象商业项目及其显式任务。 | deal + tasks? |
| `commercial.event.create` | state | 创建商业时间节点。 | task |
| `commercial.event.update` | state | 更新商业时间节点。 | targetId + patch |
| `metric.record` | state | 向 Track 视图追加一条真实测量。 | trackId + viewId + metricKey + entry |
| `weight.record` | state | 记录体重并更新关联趋势。 | entry |
| `onboarding.advance` | onboarding | 推进 First Flight 步骤。 | step |
| `onboarding.skip` | onboarding | 跳过但保留 First Flight。 | 无 |
| `onboarding.resume` | onboarding | 恢复 First Flight。 | 无 |
| `onboarding.complete` | onboarding | 完成 First Flight。 | 无 |
| `schedule.create` | schedule | 创建时间块；允许冲突但不自动挪动其他块。 | block |
| `schedule.update` | schedule | 移动、缩放或编辑未锁定时间块。 | targetId + patch |
| `schedule.complete` | schedule | 只完成本次执行，任务仍保持 active。 | targetId |
| `schedule.cancel` | schedule | 明确取消一个时间块。 | targetId |
| `schedule.clearTime` | schedule | 清空未锁定块的开始和结束时间。 | targetId |
| `memory.observe` | memory | 追加一条用户事实、偏好或模式证据。 | memory { key, type|kind, statement, explicit?, evidence?, relatedTrackIds? } |
| `memory.correct` | memory | 用用户纠正 supersede 旧记忆。 | targetId + memory |
| `memory.forget` | memory | 移除记忆内容与证据，仅保留无内容防回学标记。 | targetId |
| `decision.record` | decision | 记录选择、理由、约束、关联对象与复查点。 | decision { title, options, choice, rationale?, relatedGoal|relatedTrackIds?, reviewAt? } |
| `decision.review` | decision | 复查既有决定并设置下一复查点。 | targetId + review |
| `decision.outcome` | decision | 记录决定结果和学习并关闭循环。 | targetId + outcome |
<!-- OOS_OPERATION_REGISTRY_END -->

Quick Capture commits the note through the Worker and then creates a separate `capture.review` item for Agent judgment. Inspect it with `node scripts/oos-state.js worker-list` or the HUD “后台同步” drawer. After the Agent applies the intended state operation, resolve the item and attach its mutation receipt. Do not claim an item was classified merely because it entered the queue.

Do not use state ops for:

- major goal changes;
- priority rewrites;
- public commitments;
- commercial decisions;
- sensitive relationship interpretation;
- deleting history.

Bring those back to main chat.

## Active Checkpoints

Offer a compact checkpoint when:

- a work block starts or ends;
- a task, draft, workout, meeting, or errand is completed;
- an active track has been quiet too long;
- several updates accumulate in one day;
- tomorrow has hard deadlines.

Checkpoint format:

- What changed.
- Current stage.
- Still open / risky.
- One focused question or 1-3 next actions.

Keep checkpoints light and non-judgmental.

## Current Truth Hygiene

Current Truth is the locator, not the archive.

Keep it to:

- next 24-72 hour reality;
- active blockers;
- active decisions;
- today's / tomorrow's hard windows;
- facts that would change advice right now.

Move old facts to daily logs, project files, reviews, or Wiki.

If Current Truth grows too long, archive and compress it.

## HUD Rules

HUD is the cockpit, not the brain.

- Show 1-3 action-ready priorities.
- Hide done, cancelled, declined, archived, and waiting items from primary Today unless needed.
- Use risk cards for questions that need user judgment.
- Use hard-window calendar for fixed dates.
- Keep Plan movable for unlocked blocks, but only show conflicts; never auto-reschedule.
- Select Track visualizations from the archetype and declared `views`, and keep empty charts honest.
- Keep private details summarized.
- Do not make the user maintain the HUD manually.
- Keep Agent-to-HUD sync automatic: SSE is the immediate path; `state-meta` polling every five seconds plus focus/visibility checks is the fallback.

## Daily Review

Evening review can ask:

1. What moved today?
2. Where did things get stuck?
3. What is tomorrow's one most important action?

Record body, relationship, mood, food, and sleep if mentioned, but do not turn them into judgment unless the user asks.

## Encoding

Preserve UTF-8. Avoid inline PowerShell Chinese writes. Use `apply_patch`, explicit `utf8` scripts, or API calls with UTF-8 JSON.
