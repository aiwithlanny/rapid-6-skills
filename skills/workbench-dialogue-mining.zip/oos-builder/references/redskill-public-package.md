# OOS Public / Xiaohongshu / REDSkill Package

Use this reference when adapting OOS / Hero OS into a public Skill or a Xiaohongshu note that attaches a Skill component.

## Positioning

Do not present OOS as a todo app.

Present it as an AI-powered life cockpit / driving system:

- chat as the driver and brain;
- Current Truth as the short-horizon locator;
- HUD as dashboard / cockpit;
- logs and notes as voyage history;
- State Ops and the deterministic embedded Worker as the background hand; optional subagents only assist reasoning.

Core promise:

> It helps AI remember your lived context without being buried by it, and turns conversation into visible action guidance.

Public setup promise:

> 装完即可使用，之后持续定制迭代。

Translate this promise naturally for the publishing language without weakening either part: immediate usability and ongoing customization.

## Public Boundary

Remove before sharing:

- private state files;
- real daily logs;
- commercial deal details;
- relationship notes;
- renovation / health / body data;
- local absolute paths;
- personal images and persona assets;
- API keys, tokens, secrets, account names.

Keep:

- SKILL.md and references;
- onboarding interview;
- Current Truth concept;
- goal model;
- daily maintenance rules;
- state-ops concept;
- generic HUD template;
- public-safe sample data.

## Release Checklist

1. Public boundary is clean.
2. No mojibake / encoding damage.
3. Driving-system architecture is in the Skill.
4. Onboarding creates 1-3 Tracks with a short interview, not a huge form or module picker.
5. Demo loop is prepared.

## Demo Loop

Use a real, concrete flow:

1. User says one progress sentence.
2. Main chat explains what it means.
3. State ops update tasks / questions / activity.
4. HUD visibly changes.
5. Main chat continues with the next real action.

Example:

Input:

> A client deliverable is complete.

Output:

> Great. The deliverable moves from script to filming / rough cut. Next minimum action is a 5-8 item shot list.

State changes:

- script task done;
- rough cut task in progress;
- commercial next step updated;
- activity recorded.

## Xiaohongshu Note Angle

Lead with an ordinary pain:

- "Sometimes procrastination is not laziness. I just forget what work is still alive."
- "I did not need another todo app. I needed an AI cockpit that knows where I am."
- "I turned Codex / Claude Code into a personal operating system."

Then show:

1. messy real input;
2. chat judgment;
3. HUD state change;
4. why Current Truth prevents context overload;
5. how the public Skill lets viewers build their own first version.

## Public Skill Shape

Package the same `oos-builder/` directory for compatible hosts: place it under the Codex skills directory, `.claude/skills/oos-builder/` for a project-scoped Claude Code install, or the equivalent Agent Skills root. Keep `SKILL.md` and relative bundled-resource paths unchanged.

If platform limits allow: upload a near-original OOS Builder skill with private data removed.

If limits force a smaller package: publish a first-loop sub-skill:

- Today Priority Extractor;
- Content Topic Organizer;
- Goal Coach / Daily Planner.

Frame small packages as:

> This is the first small loop inside the larger OOS method.
