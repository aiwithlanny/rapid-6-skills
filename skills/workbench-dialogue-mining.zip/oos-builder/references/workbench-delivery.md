# Workbench Delivery Workflow

Use this reference when creating a workbench for real use, assessing an existing prototype, preparing a shareable preview, or moving an OOS beyond a private local HUD.

This workflow synthesizes the public outline of the “萬物皆可創｜AI 產品上線陪跑計畫” into OOS-specific operating guidance. It does not reproduce paid course materials. Source: <https://hjkld59.github.io/create-anything/> (reviewed 2026-08-24).

## Outcome and boundary

Move from “a prototype that appears to work” to a workbench whose intended user, core flow, state boundary, recovery path, test evidence, and delivery limits are explicit.

Do not equate public availability with readiness. A valid outcome can be:

- a verified personal local workbench;
- a shareable test preview;
- an independently copied template for each recipient;
- a public product with an appropriate architecture and operating model.

Membership systems, multi-tenant accounts, payments, sensitive personal data, medical, financial, legal, or other high-risk uses require a separate architecture and specialist review. Do not silently expand a lightweight OOS into those categories.

## Start with a delivery brief

Before modifying architecture, capture:

- product or workbench name;
- current path or URL;
- intended user and who must not have access;
- delivery mode: `personal-local`, `shared-preview`, `deliverable-template`, or `public-product`;
- one core job the user must complete end to end;
- target device and browser constraints;
- data that must persist, where it may live, and whether it must cross devices;
- deadline or review window;
- features explicitly outside this release;
- what evidence will count as ready.

If a new OOS is also being designed, reuse the confirmed Personal OOS Plan. Do not repeat questions already answered there.

## Nine delivery gates

### 1. Prototype gate

Audit before changing. Identify the Runtime, start command, current state source, existing tests, deployment configuration, and current failure modes. Exercise the core flow in the normal browser, a fresh or private session, and the smallest supported viewport. Classify the current artifact as concept, demo, functional prototype, release candidate, or delivered product.

Evidence: audit summary, reproducible start instructions, observed failures, and current classification.

### 2. Audience and delivery mode

Confirm whether the workbench is for the owner, a known group, independent recipients, or the public. This decision controls authentication, data isolation, support expectations, and hosting. Do not add login or a database merely to make the product look more complete.

Evidence: named delivery mode, user boundary, access boundary, and explicit non-goals.

### 3. Acceptance specification

Translate the desired outcome into observable checks. Record required screens, the canonical data each screen reads or writes, primary actions, validation, confirmation for destructive actions, recovery behavior, mobile behavior, loading/error/empty/conflict states, and accessibility expectations. Each requirement must be testable by action and result.

For the OOS Runtime, preserve Today, Plan, and Tracks; the Worker/state-op contract; Current Truth; and the single canonical schedule and Track state sources.

Evidence: a concise acceptance checklist mapped to the core flow.

### 4. Recoverable baseline

Before material edits, identify the last known-good version and make recovery possible outside the working copy. Prefer version control plus a verified remote or another recoverable backup appropriate to the user's environment. Never describe another folder on the same device as a complete backup strategy.

Review existing user changes before touching files. Do not create a remote, upload code, publish history, or expose private state without explicit authorization.

Evidence: baseline identifier, backup location/type, and a tested restoration or rollback instruction.

### 5. Core-flow completion

Implement or repair the shortest end-to-end path for the core job before adding secondary features. Test from a first-time user's starting point through persisted result and recovery from one common error. Keep scope exclusions visible when new ideas appear.

For an OOS, the minimum core flow is: start HUD, see Current Truth, open the relevant Track, capture or perform one real update through the Worker/state ops, and observe the refreshed next action.

Evidence: passing core-flow checks and a list of deferred enhancements.

### 6. Data and state boundary

Document every durable data category, source of truth, storage location, retention need, export/backup path, isolation rule, and failure behavior. Decide from the audience and delivery mode whether local files, browser storage, a per-recipient copy, or a server-side service is justified.

For OOS, keep State writes behind the Worker/state-op interface. Do not patch `data/state.json` directly. Never ship real private state as demo or template data.

Evidence: data map, persistence test across refresh/restart, isolation test when applicable, and a secrets inventory containing names and locations but no secret values.

### 7. Preview or deployment

Deploy only when requested. Separate preview from production when the risk or audience justifies it. Confirm build command, runtime configuration, public versus server-only variables, HTTPS, access rules, custom-domain ownership, third-party costs, logging, and rollback.

Never place administrator secrets in frontend code or commit them to the repository. A public URL is evidence of reachability only; it does not pass the remaining gates.

Evidence: authorized target, URL if applicable, configuration checklist, smoke test, and rollback path.

### 8. Independent usability test

For shared or public modes, ask for three representative people when feasible. They should attempt the core job without live coaching. Capture where they hesitate, fail, misunderstand labels, lose data, or cannot recover. For a private local workbench, an independent test is recommended rather than mandatory; use a fresh-session walkthrough as the minimum substitute.

Do not mark issues as user error when the same confusion repeats. Convert observations into prioritized fixes and rerun the affected checks.

Evidence: anonymized test notes, severity, resulting changes, and retest status.

### 9. Release review

Run the operational verification plus the acceptance checklist. Confirm core flow, persistence, responsive behavior, loading/error/empty/conflict states, destructive-action confirmation and recovery, privacy, secrets, permissions, backup, rollback, known limits, third-party costs, accessibility basics, and support owner.

Report one of:

- `ready for personal use`;
- `ready for controlled preview`;
- `ready for stated delivery mode`;
- `not ready`, with blocking evidence and the smallest next action.

Do not promise legal compliance, security certification, commercial suitability, uptime, revenue, or universal readiness from a lightweight review.

## Readiness record

Maintain a small table or structured note:

| Gate | Status | Evidence | Open risk | Next check |
| --- | --- | --- | --- | --- |
| Prototype | pending / active / passed / blocked | artifact or observation | specific risk | observable check |

Only mark a gate passed when evidence exists. Keep unknowns explicit and do not invent test results, dates, backups, users, or deployments.

## Working rhythm

For a time-boxed build, map gates to the user's actual deadline instead of forcing a fixed 14-day schedule. A useful rhythm is kickoff and scope lock, focused build blocks, periodic blocker reviews, independent testing, and a final release review. Treat missed dates as replanning signals, not fabricated completion.

At each checkpoint report:

- what changed;
- current gate and evidence gained;
- what remains risky or out of scope;
- one decision or 1-3 next actions.

## Agent judgment boundary

The Agent may audit, explain, draft specifications, implement authorized local changes, run tests, and prepare deployment instructions. Bring these decisions back to chat before acting:

- changing audience or delivery mode;
- adding authentication, multi-tenancy, payments, or sensitive-data handling;
- changing data architecture or retention promises;
- exposing a private workbench publicly;
- creating accounts, buying domains, incurring costs, or publishing externally;
- declaring final commercial, legal, privacy, or security readiness.
