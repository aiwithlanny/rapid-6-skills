# OOS Goal Model

Each main track should answer three questions:

- Where am I?
- What is the next visible action?
- What risk or question could block me?

Progress does not need to be mathematically perfect. It needs to help the user orient.

## Track Fields

Recommended `state.tracks[]` fields:

- `id`: stable slug.
- `name`: readable name.
- `navLabel`: optional compact HUD label derived from the name; use 4-8 Chinese characters or 10-18 Latin characters.
- `summary`: one sentence that defines the Track at overview scale.
- `detail`: optional longer context shown only in the Track detail view.
- `archetype`: `project`, `habit`, `pipeline`, `learning`, `relationship`, or `trend`.
- `progress`: 0-100, or low pending estimate when unknown.
- `stage`: current stage.
- `nextAction`: concrete next step.
- `lastUpdated`: date.
- `risk`: `low`, `medium`, or `high`.
- `needsQuestion`: one useful question.
- `metric`: how progress is judged.
- `trackType`: migration compatibility mirror of `archetype`; do not use it as a second source of truth.
- `views`: optional ordered operational-view configuration. Infer defaults from `archetype`; do not ask users to select widgets during intake.

## Progress Defaults

- Promise but little detail: 5%.
- Clear state, no plan: 10-20%.
- First action started: 20-35%.
- Visible middle output: 40-70%.
- Near completion / waiting review: 75-95%.
- Done: 100%.

Do not inflate progress to make the dashboard look good.

## Track Types

Choose the behavior, not the life-domain label. Model a content launch as `project` or `pipeline`; model a research or knowledge practice as `learning`.

### Project

Examples: renovation, app, course, film, portfolio, event.

Use: milestones, blockers, deadline, waiting items.

Good charts: milestone board, hard-window calendar, timeline.

### Habit

Examples: workout, reading, writing, sleep, practice.

Use: consistency, recovery, streaks, missed days without shame.

Good charts: check-in grid, dot map.

### Trend

Examples: weight, followers, income, savings, score.

Use: start, current, target, deadline, delta.

Good charts: line chart with target.

### Pipeline

Examples: commercial deals, job search, sales, applications.

Use: lead, quote, contract, production, review, payment, done.

Good charts: stage counters, kanban summary, calendar.

### Learning

Examples: exam, course, language, certification.

Use: coverage, hours, exercises, mock tests, checkpoint.

Good charts: coverage grid, weekly hours.

### Relationship

Optional and private.

Use: moments, warmth, friction, repair action, score only when user provides it.

Good charts: intimacy dot map and recent snippets.

## Operational Views Contract

Keep view configuration small and declarative:

```json
{
  "id": "weight-trend",
  "type": "trend-line",
  "source": "logs.metrics",
  "metric": "weight",
  "unit": "kg",
  "target": 72.5
}
```

Supported default view types:

- `milestone-timeline` for `project`;
- `habit-heatmap` for `habit`;
- `pipeline-board` for `pipeline`;
- `learning-progress` for `learning`;
- `relationship-pulse` for `relationship`;
- `trend-line` for `trend`.

Canonical sources are part of the contract: `habit-heatmap` uses
`source: "logs.habits"` and requires a stable `metric`; numeric `trend-line`
uses `logs.metrics`; project milestones use `logs.milestones`; pipelines use
`logs.pipeline`. `logs.checkins` is review evidence, not a habit-view source.

Treat legacy `chartType` as migration input only. Preserve explicit compatible `views`; otherwise derive one sensible default from the Track archetype. A view selects and presents evidence but never becomes a second state store.

Numeric measurements use `logs.metrics[]` with a stable id, Track id, view id when known, metric key, finite numeric value, unit, local date, optional note, and source. Keep the original measurement. Derive deltas, ranges, target distance, and chart coordinates at read time.

## Logs

Charts must come from real logs or explicit empty states:

- `weight`
- `meals`
- `checkins`
- `milestones`
- `pipeline`
- `contentTopics`
- `learning`
- `relationship.entries`

If data is missing, show "pending" or "not recorded yet"; do not fabricate.
