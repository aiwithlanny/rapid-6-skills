# Optional Visual Soul

Use this chapter only after the operational OOS is installed and the user asks to “加入灵魂”, personalize the HUD, or add character scenes. Never make it part of required onboarding.

The workflow is built into `oos-builder`, but rendering is provider-neutral. Use an available image-generation tool, a locally configured provider, or user-supplied reviewed files. Do not require OpenAI, Imagen, or any named provider for the core OOS.

## 1. Confirm the brief

Ask only what affects the visual result:

- generic mascot or user-inspired persona;
- optional reference image and consent boundary;
- temperament, broad traits, clothing or prop preferences;
- scenes that would add meaning;
- forbidden elements;
- whether the existing theme color should appear in the scenes.

Use reference images only for broad traits. Do not claim identity likeness unless the user requests and reviews it.

## 2. Produce and review directions

Generate or collect 3-6 distinct directions. Inspect them together and accept one before producing a scene set. Reject copied identities, private assets from another OOS, unreadable small-scale detail, repeated poses, and styles the user prohibited.

Keep scene meaning obvious at HUD size. Create only the views and Tracks that benefit from visual storytelling; do not require an image for every page.

## 3. Prepare a local manifest

Use absolute source paths only in the temporary local manifest. Record a provider-neutral `provider` label such as `local-provider`, `agent-image-tool`, or `user-supplied`, plus the exact OOS theme `accent`.

```json
{
  "personaId": "calm-builder",
  "provider": "user-supplied",
  "accent": "#8b5cf6",
  "acceptedDirection": "B",
  "fingerprint": "short reviewed description",
  "views": {
    "today": "C:/local/path/today.png",
    "plan": "C:/local/path/plan.png"
  },
  "tracks": {
    "track-id": "C:/local/path/track.png"
  }
}
```

Never put this local manifest or its absolute paths into a public package.

## 4. Explain the local write before applying

Call `scripts/apply_persona_assets.js` the **local visual-asset application script（本地视觉资产应用脚本）**. Before running it, tell the user that it may:

- copy reviewed files into `public/assets/persona/generated/<persona-id>/`;
- update visual references in `data/state.json`;
- create or update `data/persona-assets.json`;
- append the local audit record in `docs/visual-assets-log.md`.

Do not run it until the user understands that file boundary. Preview the validated write set first, then apply it explicitly:

```text
node scripts/apply_persona_assets.js <oos-workspace> --manifest <visual-manifest.json>
node scripts/apply_persona_assets.js <oos-workspace> --manifest <visual-manifest.json> --write
node scripts/verify_install.js <oos-workspace> --mode visual
```

If the script is absent in a reduced distribution, copy assets and update references through the runtime's normal safe-edit mechanism while preserving the same boundary and audit record. Never download or upload assets without authorization.

## 5. Verify and recover

Inspect changed pages in the browser. Check loading, crop, contrast, identity consistency, and text space. Keep deterministic local visuals available as fallbacks.

If generation, review, or application stops midway:

- leave the operational OOS usable;
- record the optional visual step as paused;
- preserve the accepted brief and manifest locally;
- resume later without rerunning intake or First Flight.

Visual completion enhances personality; it does not determine whether OOS is installed, verified, or ready for daily use.
