#!/usr/bin/env node
"use strict";

const { path, parseArgs, readJson, walk, scanPrivacy, fail } = require("./_cli");
const { validateState } = require("../assets/oos-template/lib/oos-state");

async function main() {
  const args = parseArgs(process.argv.slice(2));
  const root = path.resolve(args._[0] || process.cwd());
  const required = ["AGENTS.md", "data/state.json", "brain/Current/current-truth.md", "brain/Inbox/inbox.md", "server.js", "public/index.html", "public/app.js"];
  const missingFiles = [];
  for (const relative of required) {
    try { await require("fs/promises").access(path.join(root, relative)); } catch { missingFiles.push(relative); }
  }
  let validation = { ok: false, errors: ["data/state.json is missing"], warnings: [] };
  let schemaVersion = null;
  try {
    const state = await readJson(path.join(root, "data/state.json"));
    schemaVersion = state.schemaVersion ?? state.meta?.schemaVersion ?? null;
    validation = validateState(state);
  } catch (error) {
    validation = { ok: false, errors: [error.message], warnings: [] };
  }
  const files = await walk(root);
  const privacyFindings = await scanPrivacy(root);
  const report = { root, schemaVersion, fileCount: files.length, missingFiles, validation, privacyFindings, ok: missingFiles.length === 0 && validation.ok };
  process.stdout.write(`${JSON.stringify(report, null, 2)}\n`);
  if (!report.ok) fail("Audit found blocking installation issues.", 2);
}

main().catch((error) => fail(error.stack || error.message));
