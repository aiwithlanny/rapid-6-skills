#!/usr/bin/env node
"use strict";

const assert = require("assert");
const fs = require("fs");
const os = require("os");
const path = require("path");
const { spawnSync } = require("child_process");

const skillRoot = path.resolve(__dirname, "..");
const target = fs.mkdtempSync(path.join(os.tmpdir(), "oos-plan-compiler-"));
const fixture = path.join(skillRoot, "evals", "fixtures", "mira-plan.json");

try {
  const run = spawnSync(process.execPath, [
    path.join(skillRoot, "scripts", "init_oos.js"),
    target,
    "--plan",
    fixture
  ], { encoding: "utf8" });
  assert.equal(run.status, 0, run.stderr || run.stdout);

  const state = JSON.parse(fs.readFileSync(path.join(target, "data", "state.json"), "utf8"));
  assert.equal(state.meta.hudBaseline, "oos-unified-v5.1");
  assert.equal(state.meta.theme.accent, "#9b6248");
  assert.equal(state.tracks.length, 3);
  assert.deepEqual(state.tracks.map((track) => track.archetype), ["project", "learning", "habit"]);
  assert.deepEqual(state.tracks.map((track) => track.navLabel), ["毕业设计", "雅思", "早睡"]);
  assert(state.logs.milestones.length >= 4, "explicit dates should remain separate structured milestones");
  assert(state.tracks.find((track) => track.id === "ielts").views[0].checkpoints.length === 2);
  assert(state.tracks.find((track) => track.id === "sleep").views[0].habitPlan);
  assert(state.tasks.length >= 10, "structured plan should compile into a useful first week, not one task per Track");
  assert(state.scheduleBlocks.length >= 8, "active initial tasks should receive real schedule blocks");
  const sleepBlock = state.scheduleBlocks.find((block) => block.taskId === "task-sleep-next");
  assert.equal(sleepBlock?.startAt, `${state.tracks.find((track) => track.id === "sleep").lastUpdated}T23:55:00+08:00`);
  assert.equal(sleepBlock?.kind, "routine");
  assert(state.tasks.every((task) => task.goal && state.tracks.some((track) => track.id === task.goal)));
  assert(state.tracks.every((track) => !Object.prototype.hasOwnProperty.call(track, "initialTasks")));
  assert(fs.existsSync(path.join(target, "docs", "worker-model.md")));
  assert(fs.existsSync(path.join(target, "docs", "task-lifecycle.md")));

  const queue = JSON.parse(fs.readFileSync(path.join(target, "data", "worker-queue.json"), "utf8"));
  assert(
    queue.items.some((item) => item.type === "state_ops_request" && item.status === "done"),
    JSON.stringify(queue.items, null, 2)
  );
  const agentOpFile = path.join(target, "agent-op.json");
  fs.writeFileSync(agentOpFile, JSON.stringify({
    clientMutationId: "plan-compiler-agent-meaning",
    summary: "Agent captured a clear first action.",
    humanMeaning: "Mira 明确了下一项可以执行的行动。",
    relatedGoal: "graduation-project",
    ops: [{
      type: "activity.add",
      text: "已确认下一项可执行行动。",
      relatedGoal: "graduation-project"
    }]
  }), "utf8");
  const cli = spawnSync(process.execPath, [
    path.join(target, "scripts", "oos-state.js"),
    "op",
    "--offline",
    "--expected-version",
    "2",
    "--file",
    agentOpFile
  ], { cwd: target, encoding: "utf8" });
  assert.equal(cli.status, 0, cli.stderr || cli.stdout);
  const updatedState = JSON.parse(fs.readFileSync(path.join(target, "data", "state.json"), "utf8"));
  assert.equal(updatedState.receipts[0]?.humanMeaning, "Mira 明确了下一项可以执行的行动。");
  assert.equal(updatedState.receipts[0]?.versionBefore, 2);
  assert.equal(updatedState.receipts[0]?.versionAfter, 3);
  process.stdout.write(`Plan compiler fixture passed: ${state.tasks.length} tasks, ${state.scheduleBlocks.length} blocks, ${state.logs.milestones.length} milestones.\n`);
} finally {
  fs.rmSync(target, { recursive: true, force: true });
}
