#!/usr/bin/env node
"use strict";

const crypto = require("crypto");
const { fsp, path, parseArgs, readJson, walk, fail } = require("./_cli");
const { validateState, deriveTrackHealth, deriveTrackViews, deriveThemeTokens, stateMeta, applyStateOps, hasStateConflict } = require("../assets/oos-template/lib/oos-state");

const MODES = new Set(["operational", "visual", "public"]);
const CORE_VIEWS = ["today", "plan", "tracks"];
const TEXT_EXTENSIONS = new Set([".js", ".json", ".css", ".html", ".md", ".svg", ".txt", ".yaml", ".yml", ".ps1"]);
const USAGE = "Usage: node scripts/verify_install.js <oos-workspace> [--mode operational|visual|public]";

async function sha256(file) {
  const data = await fsp.readFile(file);
  const input = TEXT_EXTENSIONS.has(path.extname(file).toLowerCase()) ? data.toString("utf8").replace(/\r\n/g, "\n") : data;
  return crypto.createHash("sha256").update(input).digest("hex");
}

async function exists(file) {
  try { await fsp.access(file); return true; } catch { return false; }
}

function add(checks, check, ok, detail) {
  checks.push({ check, ok: Boolean(ok), ...(detail === undefined ? {} : { detail }) });
}

async function verifyOperational(root, state, checks) {
  const required = [
    "AGENTS.md", "README.md", "package.json", "server.js", "lib/oos-state.js", "lib/oos-state-model.js", "lib/oos-context-kernel.js", "lib/oos-derived.js", "lib/task-lifecycle.js", "lib/text-integrity.js", "lib/startup-freshness.js", "lib/unified-runtime.js", "lib/oos-store.js", "data/state.json", "data/worker-queue.json",
    "scripts/oos-state.js", "scripts/test-cross-surface-golden.js", "scripts/test-personal-context-kernel.js", "scripts/test-runtime-binding.js", "scripts/test-plan-workbench.js",
    "public/index.html", "public/app.js", "public/styles.css", "public/calendar.css", "public/calendar-engine.js", "public/calendar-ui.js", "public/public-overrides.css",
    "public/hud-baseline.json", "public/assets/brand/odyssey-logo-mark.png",
    "brain/Current/current-truth.md", "brain/Inbox/inbox.md", "docs/worker-model.md", "docs/task-lifecycle.md"
  ];
  for (const relative of required) {
    const present = await exists(path.join(root, relative));
    add(checks, `file:${relative}`, present, present ? undefined : "missing");
  }

  const validation = validateState(state);
  add(checks, "schema-v3", validation.ok, validation.errors);
  add(checks, "operational-readiness", state.meta?.readiness?.operationalReady === true && stateMeta(state).readiness.operationalReady, state.meta?.readiness);
  add(checks, "visual-not-required", typeof state.meta?.readiness?.visualReady === "boolean" && ["none", "local", "provider", "reviewed"].includes(state.visual?.mode), state.visual);

  const tokens = deriveThemeTokens(state.meta?.theme?.accent);
  add(checks, "canonical-user-accent", /^#[0-9a-f]{6}$/i.test(String(state.meta?.theme?.accent || "")) && tokens.accent === String(state.meta.theme.accent).toLowerCase(), tokens);
  add(checks, "generic-track-contract", (state.tracks || []).length > 0 && state.tracks.every((track) => track.name && track.navLabel && track.summary && ["project", "habit", "pipeline", "learning", "relationship", "trend"].includes(track.archetype)), (state.tracks || []).map(({ id, navLabel, archetype }) => ({ id, navLabel, archetype })));
  add(checks, "track-view-contract", (state.tracks || []).every((track) => Array.isArray(track.views) && track.views.length > 0 && track.views.every((view) => view.id && view.type && view.source)), (state.tracks || []).map(({ id, views }) => ({ id, views })));
  const trackViews = deriveTrackViews(state);
  add(checks, "derived-track-views", (state.tracks || []).every((track) => trackViews[track.id]?.views?.every((view) => Array.isArray(view.entries) && typeof view.empty === "boolean")), trackViews);
  add(checks, "raw-metric-log-contract", Array.isArray(state.logs?.metrics), state.logs?.metrics);
  add(checks, "compressed-track-labels", (state.tracks || []).every((track) => /[\u4e00-\u9fff]/.test(track.navLabel) ? [...track.navLabel].length <= 8 : track.navLabel.length <= 18));
  add(checks, "first-flight-state", ["not_started", "in_progress", "skipped", "completed"].includes(state.onboarding?.firstFlight?.status), state.onboarding?.firstFlight);
  add(checks, "personal-context-shape", Array.isArray(state.context?.memories) && Array.isArray(state.decisions), { context: state.context, decisions: state.decisions });
  const activeTasks = (state.tasks || []).filter((task) => !task.archived && ["open", "in_progress"].includes(task.status) && task.autoSchedule !== false && task.schedulePolicy !== "unscheduled");
  const scheduledTaskIds = new Set((state.scheduleBlocks || []).filter((block) => ["planned", "in_progress"].includes(block.status) && block.startAt).map((block) => block.taskId));
  add(checks, "initial-actions-scheduled", activeTasks.every((task) => scheduledTaskIds.has(task.id)), activeTasks.filter((task) => !scheduledTaskIds.has(task.id)).map((task) => task.id));

  const baseline = await readJson(path.join(root, "public", "hud-baseline.json"));
  const baselineFiles = await Promise.all((baseline.files || []).map(async (item) => {
    const relative = String(item.target || "");
    const file = path.join(root, relative);
    return { relative, ok: await exists(file) && await sha256(file) === item.sha256 };
  }));
  add(checks, "portable-hud-baseline", baseline.contract === "oos-unified-v5.1" && baselineFiles.every((item) => item.ok) && baseline.files?.some((item) => item.target === "public/calendar-ui.js") && baseline.files?.some((item) => item.target === "public/oos-client.js") && baseline.files?.some((item) => item.target === "lib/unified-runtime.js") && baseline.files?.some((item) => item.target === "lib/text-integrity.js") && baseline.files?.some((item) => item.target === "lib/oos-context-kernel.js"), baselineFiles.filter((item) => !item.ok));
  add(checks, "runtime-extension-boundary", Array.isArray(baseline.mutablePaths) && baseline.mutablePaths.includes("data/**") && baseline.mutablePaths.includes("public/public-overrides.css") && Array.isArray(baseline.extensionPaths) && baseline.extensionPaths.includes("extensions/**"), { mutablePaths: baseline.mutablePaths, extensionPaths: baseline.extensionPaths });

  const [indexHtml, appJs, publicOverrides, serverJs, storeJs, unifiedRuntimeJs, stateCli, workerQueue, currentTruth] = await Promise.all([
    fsp.readFile(path.join(root, "public", "index.html"), "utf8"),
    fsp.readFile(path.join(root, "public", "app.js"), "utf8"),
    fsp.readFile(path.join(root, "public", "public-overrides.css"), "utf8"),
    fsp.readFile(path.join(root, "server.js"), "utf8"),
    fsp.readFile(path.join(root, "lib", "oos-store.js"), "utf8"),
    fsp.readFile(path.join(root, "lib", "unified-runtime.js"), "utf8"),
    fsp.readFile(path.join(root, "scripts", "oos-state.js"), "utf8"),
    readJson(path.join(root, "data", "worker-queue.json")),
    fsp.readFile(path.join(root, "brain", "Current", "current-truth.md"), "utf8")
  ]);
  const surfaceMisses = CORE_VIEWS.filter((surface) => !indexHtml.includes(`data-view="${surface}"`) && !appJs.includes(`case "${surface}"`));
  add(checks, "core-three-surface-contract", surfaceMisses.length === 0 && !indexHtml.includes('data-view="notes"') && !indexHtml.includes('data-view="review"') && appJs.includes("QUICK CAPTURE") && appJs.includes("todayClosePanel"), surfaceMisses);
  add(checks, "asset-free-operational-hud", !indexHtml.includes("/assets/persona/") && !appJs.includes("/assets/persona/oos-"));
  add(checks, "first-flight-ui", appJs.includes("onboarding.advance") && appJs.includes("onboarding.skip") && appJs.includes("onboarding.resume") && appJs.includes("onboarding.complete"));
  add(checks, "hidden-navigation-contract", /\[hidden\]\s*\{[^}]*display:\s*none\s*!important/i.test(publicOverrides));
  add(checks, "shared-state-runtime", serverJs.includes("createUnifiedRuntime") && unifiedRuntimeJs.includes("atomicWriteJson") && unifiedRuntimeJs.includes("defaultScheduleCandidates") && storeJs.includes("workspaceInstanceId") && stateCli.includes("--expected-version"));
  add(checks, "workspace-instance-guard", serverJs.includes("instanceId: INSTANCE_ID") && storeJs.includes("workspaceInstanceId") && stateCli.includes("wrong_oos_instance"));
  add(checks, "agent-hud-live-sync", serverJs.includes("/api/events") && serverJs.includes("state.changed") && appJs.includes("new EventSource") && appJs.includes("setInterval(checkStateMeta, 5000)") && appJs.includes("visibilitychange") && appJs.includes("window.addEventListener(\"focus\""));
  add(checks, "agent-change-feed", serverJs.includes("/api/changes") && unifiedRuntimeJs.includes("humanMeaning") && unifiedRuntimeJs.includes("changedEntities") && stateCli.includes('command === "changes"'));
  add(checks, "mutation-envelope", serverJs.includes("clientMutationId is required") && appJs.includes("clientMutationId(") && stateCli.includes("clientMutationId"));
  add(checks, "real-worker-queue", Array.isArray(workerQueue.items) && serverJs.includes("enqueueAgentReview") && serverJs.includes("/api/worker") && unifiedRuntimeJs.includes("stateOpsPending") && unifiedRuntimeJs.includes("agentReviewPending") && stateCli.includes("worker-list") && appJs.includes("data-worker-open"), workerQueue);
  add(checks, "current-truth-version", currentTruth.includes(`sourceStateVersion: ${Number(state.meta?.version || 0)}`), { stateVersion: state.meta?.version });
  add(checks, "public-overrides-loaded", indexHtml.includes("/public-overrides.css"));
  add(checks, "calendar-runtime-loaded", indexHtml.includes("/calendar.css") && indexHtml.includes("/calendar-engine.js") && indexHtml.includes("/calendar-ui.js"));
  const calendarUi = await fsp.readFile(path.join(root, "public", "calendar-ui.js"), "utf8");
  const calendarCss = await fsp.readFile(path.join(root, "public", "calendar.css"), "utf8");
  add(checks, "plan-workbench-contract", calendarUi.includes('mode: "workbench"') && calendarUi.includes("four-week-calendar") && calendarUi.includes("selected-day-timeline") && calendarUi.includes("data-calendar-date-drop") && calendarCss.includes(".plan-mode .hero { display:none;"));

  const health = deriveTrackHealth(state);
  add(checks, "derived-track-health", health.length === state.tracks.length);
  add(checks, "track-archetypes-preserved", state.tracks.every((track) => state.goals.find((goal) => goal.id === track.id)?.trackType === track.archetype));

  let operationFixture = state;
  let sampleTask = state.tasks.find((task) => ["open", "in_progress"].includes(task.status));
  if (!sampleTask) {
    const created = applyStateOps(state, [{
      type: "task.create",
      task: {
        id: "verify-task-complete-contract",
        title: "Verify canonical completion contract",
        goal: state.tracks[0]?.id || "system",
        status: "open",
        priority: "normal",
        unscheduled: true
      }
    }]);
    operationFixture = created.state;
    sampleTask = created.state.tasks.find((task) => task.id === "verify-task-complete-contract");
  }
  if (sampleTask) {
    const linkedBlock = (operationFixture.scheduleBlocks || []).find((block) => block.taskId === sampleTask.id && ["planned", "in_progress"].includes(block.status));
    const execution = linkedBlock ? applyStateOps(operationFixture, [{ type: "schedule.complete", targetId: linkedBlock.id }]) : null;
    add(checks, "state-op-execution-complete", !linkedBlock || (execution.ok && execution.state.tasks.find((task) => task.id === sampleTask.id)?.status !== "done" && execution.state.logs.executions.some((item) => item.blockId === linkedBlock.id)));
    const completionInput = execution?.state || operationFixture;
    const complete = applyStateOps(completionInput, [{ type: "task.complete", targetId: sampleTask.id }]);
    add(checks, "state-op-task-complete", complete.ok && complete.state.meta.version === completionInput.meta.version + 1 && complete.state.tasks.find((task) => task.id === sampleTask.id)?.status === "done");
  }
  const flight = applyStateOps(state, [{ type: "onboarding.advance", step: 2 }, { type: "onboarding.skip" }, { type: "onboarding.resume" }, { type: "onboarding.complete" }]);
  add(checks, "state-op-first-flight", flight.ok && flight.state.onboarding.firstFlight.status === "completed" && flight.state.meta.readiness.firstFlight === "completed");
  const note = applyStateOps(state, [{ type: "note.add", note: { title: "Verification note", body: "Round-trip note write." } }]);
  add(checks, "state-op-note-add", note.ok && note.state.notes[0]?.title === "Verification note");
  const review = applyStateOps(state, [{ type: "review.add", review: { progress: "Verified write loop", tomorrow: "Continue" } }]);
  add(checks, "state-op-review-add", review.ok && review.state.logs?.checkins?.[0]?.progress === "Verified write loop");
  const metricFixture = JSON.parse(JSON.stringify(state));
  metricFixture.tracks.push({ id: "verify-trend", name: "Verification Trend", navLabel: "Verify Trend", summary: "Runtime-only verification track.", detail: "", archetype: "trend", trackType: "trend", role: "supporting", cadenceDays: 7, monitoring: { enabled: true }, progress: 0, stage: "Verify", nextAction: "Verify metric write", risk: "low", metric: "verification", lastUpdated: "", views: [{ id: "trend", type: "trend-line", source: "logs.metrics", metric: "verification", unit: "unit", target: 10, direction: "up", label: "Verification" }] });
  const metricOp = { type: "metric.record", trackId: "verify-trend", viewId: "trend", metricKey: "verification", entry: { value: 2.5, unit: "unit", date: "2026-01-01", note: "Verifier record", source: "system" } };
  const metric = applyStateOps(metricFixture, [metricOp]);
  const metricAgain = metric.ok ? applyStateOps(metric.state, [metricOp]) : { ok: false, skipped: [] };
  const metricInvalid = applyStateOps(metricFixture, [{ ...metricOp, entry: { ...metricOp.entry, value: "not-a-number" } }]);
  const derivedMetric = metric.ok ? deriveTrackViews(metric.state)["verify-trend"]?.views?.[0] : null;
  add(checks, "state-op-metric-record", metric.ok && metric.state.logs.metrics.length === metricFixture.logs.metrics.length + 1 && derivedMetric?.entries?.[0]?.value === 2.5 && derivedMetric?.empty === false);
  add(checks, "state-op-metric-idempotent", metricAgain.ok && metricAgain.applied.length === 0 && metricAgain.skipped[0]?.idempotent === true && metricAgain.state.meta.version === metric.state.meta.version);
  add(checks, "state-op-metric-invalid-rejected", !metricInvalid.ok && metricInvalid.state.logs.metrics.length === metricFixture.logs.metrics.length);
  add(checks, "expected-version-conflict", metric.ok && hasStateConflict(metric.state, metricFixture.meta.version) && !hasStateConflict(metric.state, metric.state.meta.version));

  const readme = await fsp.readFile(path.join(root, "README.md"), "utf8");
  add(checks, "documented-default-port", readme.includes("localhost:4174") && !readme.includes("localhost:4173"));
  const dailyDir = path.join(root, "brain", "Daily");
  let dailyLogs = [];
  try { dailyLogs = (await fsp.readdir(dailyDir)).filter((name) => name.endsWith(".md")); } catch {}
  add(checks, "first-daily-log", dailyLogs.length > 0, dailyLogs);
  return validation.warnings;
}

async function verifyVisual(root, state, checks) {
  let manifest = null;
  try { manifest = await readJson(path.join(root, "data", "persona-assets.json")); } catch {}
  const viewAssets = state.visual?.assets?.views || {};
  const trackAssets = state.visual?.assets?.tracks || {};
  const invalidViews = Object.keys(viewAssets).filter((key) => !CORE_VIEWS.includes(key));
  const trackIds = new Set((state.tracks || []).map((track) => track.id));
  const invalidTracks = Object.keys(trackAssets).filter((key) => !trackIds.has(key));
  const paths = [...Object.values(viewAssets), ...Object.values(trackAssets)].filter(Boolean);
  const invalidPaths = paths.filter((asset) => !/^\/assets\/persona\/generated\/[^/]+\/[^/]+\.(?:png|webp|jpe?g)$/i.test(String(asset)));
  const missingFiles = [];
  const undersizedFiles = [];
  const hashes = [];
  for (const asset of paths) {
    const file = path.join(root, "public", String(asset).replace(/^\//, ""));
    try {
      const stat = await fsp.stat(file);
      if (stat.size < 32768) undersizedFiles.push(asset);
      hashes.push(await sha256(file));
    } catch { missingFiles.push(asset); }
  }
  const distinct = hashes.length === paths.length && new Set(hashes).size === hashes.length;
  const declared = Object.values(manifest?.sceneSha256 || {});
  const declaredOk = declared.length === hashes.length && hashes.every((hash) => declared.includes(hash));
  let contactSheetOk = false;
  try {
    const contactFile = path.join(root, "public", String(manifest?.contactSheet || "").replace(/^\//, ""));
    contactSheetOk = (await fsp.stat(contactFile)).size >= 32768 && await sha256(contactFile) === manifest?.contactSheetSha256;
  } catch {}
  add(checks, "reviewed-visual-assets", state.meta?.readiness?.visualReady === true && state.visual?.mode === "reviewed" && state.visual?.status === "approved" && Boolean(state.visual?.provider) && Boolean(state.visual?.acceptedDirection) && Boolean(state.visual?.fingerprint) && Boolean(state.visual?.approvedAt) && manifest?.provider === state.visual.provider && paths.length > 0 && invalidViews.length === 0 && invalidTracks.length === 0 && invalidPaths.length === 0 && missingFiles.length === 0 && undersizedFiles.length === 0 && distinct && declaredOk && contactSheetOk, { invalidViews, invalidTracks, invalidPaths, missingFiles, undersizedFiles, distinct, declaredOk, contactSheetOk });
}

async function verifyPublic(root, state, checks) {
  add(checks, "public-generic-owner", state.meta?.owner === "OOS User", state.meta?.owner);
  add(checks, "public-generic-tracks", (state.tracks || []).every((track) => track.id === "primary-track"), (state.tracks || []).map((track) => track.id));
  const privateRaster = (await walk(path.join(root, "public"))).filter((file) => /assets[\\/]persona[\\/]generated[\\/].+\.(?:png|webp|jpe?g)$/i.test(file));
  add(checks, "public-no-personal-raster", privateRaster.length === 0, privateRaster.map((file) => path.relative(root, file)));
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  if (args.help) {
    process.stdout.write(`${USAGE}\n`);
    return;
  }
  if (!args._[0]) return fail(USAGE, 2);
  const root = path.resolve(args._[0]);
  const mode = String(args.mode || "operational").toLowerCase();
  if (!MODES.has(mode)) return fail(`Unknown verification mode: ${mode}. Use operational, visual, or public.`, 2);
  const state = await readJson(path.join(root, "data", "state.json"));
  const checks = [];
  const warnings = await verifyOperational(root, state, checks);
  if (mode === "visual") await verifyVisual(root, state, checks);
  if (mode === "public") await verifyPublic(root, state, checks);

  const corrupt = [];
  for (const file of await walk(root)) {
    if (/\.(?:png|jpe?g|gif|webp|ico|woff2?)$/i.test(file)) continue;
    const text = await fsp.readFile(file, "utf8");
    if (text.includes("�") || /(?:閿熸枻鎷|鐎电钖)/.test(text)) corrupt.push(path.relative(root, file).replaceAll("\\", "/"));
  }
  add(checks, "utf8-and-mojibake", corrupt.length === 0, corrupt);

  const report = { root, mode, ok: checks.every((item) => item.ok), checks, warnings };
  process.stdout.write(`${JSON.stringify(report, null, 2)}\n`);
  if (!report.ok) fail(`${mode} installation verification failed.`, 2);
}

main().catch((error) => fail(error.stack || error.message));
