#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");
const { markdown } = require("../assets/oos-template/lib/oos-operations");

const START = "<!-- OOS_OPERATION_REGISTRY_START -->";
const END = "<!-- OOS_OPERATION_REGISTRY_END -->";
const files = [
  path.join(__dirname, "..", "assets", "oos-template", "AGENTS.md"),
  path.join(__dirname, "..", "references", "maintenance.md")
];

function synchronize(file, write) {
  const source = fs.readFileSync(file, "utf8");
  const pattern = new RegExp(`${START}[\\s\\S]*?${END}`);
  if (!pattern.test(source)) throw new Error(`Operation registry markers missing: ${file}`);
  const next = source.replace(pattern, markdown());
  if (write) fs.writeFileSync(file, next, "utf8");
  else if (next !== source) throw new Error(`Operation docs are stale: ${file}`);
}

const write = process.argv.includes("--write");
for (const file of files) synchronize(file, write);
console.log(write ? "Operation docs synchronized." : "Operation docs are synchronized.");
