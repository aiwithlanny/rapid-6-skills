#!/usr/bin/env node
"use strict";

const crypto = require("crypto");
const { fsp, path, parseArgs, readJson, writeJson, fail } = require("./_cli");
const { validateState } = require("../assets/oos-template/lib/oos-state");

const VIEW_KEYS = ["today", "plan", "tracks", "notes", "review"];
const RASTER = new Set([".png", ".webp", ".jpg", ".jpeg"]);

function safeSlug(value) {
  const original = String(value || "persona");
  const base = original.toLowerCase().replace(/[^a-z0-9-]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 36);
  const suffix = crypto.createHash("sha256").update(original).digest("hex").slice(0, 8);
  return `${base || "asset"}-${suffix}`;
}

async function requireRaster(file, label) {
  const absolute = path.resolve(String(file || ""));
  if (!RASTER.has(path.extname(absolute).toLowerCase())) throw new Error(`${label} must be a reviewed PNG, WebP, or JPEG asset.`);
  const stat = await fsp.stat(absolute);
  if (!stat.isFile() || stat.size < 32768) throw new Error(`${label} is missing or smaller than the 32 KB visual-review floor.`);
  const bytes = await fsp.readFile(absolute);
  let width = 0;
  let height = 0;
  if (path.extname(absolute).toLowerCase() === ".png" && bytes.length >= 24 && bytes.subarray(1, 4).toString("ascii") === "PNG") {
    width = bytes.readUInt32BE(16);
    height = bytes.readUInt32BE(20);
    if (width < 800 || height < 500) throw new Error(`${label} must be at least 800x500; received ${width}x${height}.`);
  }
  return { absolute, sha256: crypto.createHash("sha256").update(bytes).digest("hex"), bytes: stat.size, width, height };
}

async function copyAsset(source, directory, name) {
  const extension = path.extname(source).toLowerCase();
  const filename = `${name}${extension}`;
  await fsp.copyFile(source, path.join(directory, filename));
  return `/assets/persona/generated/${path.basename(directory)}/${filename}`;
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  if (!args._[0] || !args.manifest) return fail("Usage: node apply_persona_assets.js <oos-workspace> --manifest <visual-manifest.json> [--write]", 2);
  const root = path.resolve(args._[0]);
  const manifestFile = path.resolve(String(args.manifest));
  const manifest = await readJson(manifestFile);
  const provider = String(manifest.provider || manifest.generator || "local").trim();
  if (!provider) return fail("Manifest must name the image provider or use provider: local.", 2);
  if (!manifest.acceptedDirection || !manifest.fingerprint) return fail("Manifest must include acceptedDirection and fingerprint.", 2);

  const stateFile = path.join(root, "data", "state.json");
  const state = await readJson(stateFile);
  const declaredAccent = String(manifest.accent || manifest.themeAccent || "").toLowerCase();
  const stateAccent = String(state.meta?.theme?.accent || "").toLowerCase();
  if (!declaredAccent || declaredAccent !== stateAccent) return fail(`Manifest accent must match the OOS theme accent ${stateAccent}.`, 2);

  const viewEntries = Object.entries(manifest.views || {});
  const trackEntries = Object.entries(manifest.tracks || {});
  const invalidViews = viewEntries.map(([key]) => key).filter((key) => !VIEW_KEYS.includes(key));
  const trackIds = new Set((state.tracks || []).map((track) => track.id));
  const invalidTracks = trackEntries.map(([key]) => key).filter((key) => !trackIds.has(key));
  if (invalidViews.length) return fail(`Manifest contains unknown core views: ${invalidViews.join(", ")}`, 2);
  if (invalidTracks.length) return fail(`Manifest contains unknown Tracks: ${invalidTracks.join(", ")}`, 2);
  if (!viewEntries.length && !trackEntries.length) return fail("Manifest must contain at least one reviewed view or Track scene.", 2);

  const sceneSources = [
    ...viewEntries.map(([, source]) => path.resolve(String(source))),
    ...trackEntries.map(([, source]) => path.resolve(String(source)))
  ];
  if (new Set(sceneSources.map((item) => item.toLowerCase())).size !== sceneSources.length) return fail("Each core view and Track must use a distinct reviewed scene asset.", 2);
  const inspectedScenes = await Promise.all(sceneSources.map((source, index) => requireRaster(source, `scene.${index + 1}`)));
  if (new Set(inspectedScenes.map((item) => item.sha256)).size !== inspectedScenes.length) return fail("Duplicate visual hashes found; each core view and Track needs a distinct reviewed image.", 2);
  const previousHashes = await readPreviousSceneHashes(root);
  const replacingKeys = new Set([...viewEntries.map(([key]) => `view:${key}`), ...trackEntries.map(([key]) => `track:${key}`)]);
  const retainedHashes = Object.entries(previousHashes).filter(([key]) => !replacingKeys.has(key)).map(([, hash]) => hash);
  if (inspectedScenes.some((item) => retainedHashes.includes(item.sha256))) return fail("A new scene duplicates an already applied visual asset.", 2);
  const contactSheet = await requireRaster(manifest.contactSheet, "contactSheet");

  const personaId = safeSlug(manifest.personaId || state.meta?.owner);
  const outputDir = path.join(root, "public", "assets", "persona", "generated", personaId);
  const plannedChanges = [
    path.relative(root, outputDir).replaceAll("\\", "/"),
    "data/state.json",
    "data/persona-assets.json",
    "docs/visual-assets-log.md"
  ];
  if (!args.write) {
    process.stdout.write(`${JSON.stringify({ mode: "dry-run", root, provider, personaId, accent: stateAccent, sceneCount: inspectedScenes.length, plannedChanges, readyToApply: true }, null, 2)}\n`);
    return;
  }

  await fsp.mkdir(outputDir, { recursive: true });
  const views = { ...(state.visual?.assets?.views || {}) };
  for (const [key, sourceFile] of viewEntries) {
    const source = await requireRaster(sourceFile, `views.${key}`);
    views[key] = await copyAsset(source.absolute, outputDir, `view-${safeSlug(key)}`);
  }
  const tracks = { ...(state.visual?.assets?.tracks || {}) };
  for (const [trackId, sourceFile] of trackEntries) {
    const source = await requireRaster(sourceFile, `tracks.${trackId}`);
    tracks[trackId] = await copyAsset(source.absolute, outputDir, `track-${safeSlug(trackId)}`);
  }
  const contactName = `contact-sheet${path.extname(contactSheet.absolute).toLowerCase()}`;
  await fsp.copyFile(contactSheet.absolute, path.join(outputDir, contactName));

  const approvedAt = new Date().toISOString();
  const assets = { views, tracks, contactSheet: `/assets/persona/generated/${personaId}/${contactName}` };
  state.visual = {
    ...(state.visual || {}),
    mode: "reviewed",
    status: "approved",
    provider,
    acceptedDirection: String(manifest.acceptedDirection),
    fingerprint: String(manifest.fingerprint),
    approvedAt,
    assets
  };
  state.meta.readiness = { ...(state.meta.readiness || {}), operationalReady: true, visualReady: true, firstFlight: state.onboarding?.firstFlight?.status || "not_started" };
  state.meta.version = Number(state.meta.version || 0) + 1;
  state.meta.lastUpdated = approvedAt;
  const validation = validateState(state);
  if (!validation.ok) return fail(`Visual assets would leave state invalid: ${validation.errors.join("; ")}`, 2);

  const backup = `${stateFile}.before-visual-assets-${Date.now()}.bak`;
  await fsp.copyFile(stateFile, backup);
  const temp = `${stateFile}.${process.pid}.tmp`;
  await writeJson(temp, state);
  await fsp.rename(temp, stateFile);

  const publicManifest = {
    personaId,
    provider,
    accent: stateAccent,
    acceptedDirection: String(manifest.acceptedDirection),
    fingerprint: String(manifest.fingerprint),
    approvedAt,
    contactSheet: assets.contactSheet,
    contactSheetSha256: contactSheet.sha256,
    views,
    tracks,
    sceneSha256: {
      ...previousHashes,
      ...Object.fromEntries([
        ...viewEntries.map(([key], index) => [`view:${key}`, inspectedScenes[index].sha256]),
        ...trackEntries.map(([trackId], index) => [`track:${trackId}`, inspectedScenes[viewEntries.length + index].sha256])
      ])
    }
  };
  await writeJson(path.join(root, "data", "persona-assets.json"), publicManifest);
  await fsp.mkdir(path.join(root, "docs"), { recursive: true });
  await fsp.writeFile(path.join(root, "docs", "visual-assets-log.md"), `# Visual Assets Log\n\n- Provider: ${provider}\n- Theme accent: ${stateAccent}\n- Accepted direction: ${publicManifest.acceptedDirection}\n- Approved at: ${approvedAt}\n- Persona: ${personaId}\n- Fingerprint: ${publicManifest.fingerprint}\n- Contact sheet: ${publicManifest.contactSheet}\n- Scene count: ${Object.keys(views).length + Object.keys(tracks).length}\n`, "utf8");
  process.stdout.write(`${JSON.stringify({ mode: "write", root, provider, personaId, approvedAt, accent: stateAccent, plannedChanges, backup }, null, 2)}\n`);
}

main().catch((error) => fail(error.stack || error.message));

async function readPreviousSceneHashes(root) {
  try { return (await readJson(path.join(root, "data", "persona-assets.json"))).sceneSha256 || {}; }
  catch { return {}; }
}
