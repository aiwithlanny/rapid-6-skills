#!/usr/bin/env node
"use strict";

const crypto = require("crypto");
const { fsp, path, parseArgs, readJson, fail } = require("./_cli");

async function exists(file) {
  try { await fsp.access(file); return true; } catch { return false; }
}

const TEXT_EXTENSIONS = new Set([".js", ".json", ".css", ".html", ".md", ".svg", ".txt", ".yaml", ".yml", ".ps1"]);

async function sha256(file) {
  const data = await fsp.readFile(file);
  const input = TEXT_EXTENSIONS.has(path.extname(file).toLowerCase()) ? data.toString("utf8").replace(/\r\n/g, "\n") : data;
  return crypto.createHash("sha256").update(input).digest("hex");
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  const target = path.resolve(args._[0] || process.cwd());
  const template = path.resolve(__dirname, "..", "assets", "oos-template");
  const manifest = await readJson(path.join(template, "public", "hud-baseline.json"));
  const changes = [];
  for (const item of manifest.files || []) {
    const source = path.join(template, item.target);
    const destination = path.join(target, item.target);
    const present = await exists(destination);
    const currentHash = present ? await sha256(destination) : "";
    changes.push({ target: item.target, status: !present ? "missing" : currentHash === item.sha256 ? "current" : "modified-or-old", currentHash, nextHash: item.sha256, source });
  }
  const report = {
    mode: args.write ? "write" : "dry-run",
    target,
    contract: manifest.contract,
    changes: changes.filter((item) => item.status !== "current"),
    preserved: manifest.mutablePaths,
    extensionPaths: manifest.extensionPaths
  };
  if (!args.write) {
    process.stdout.write(`${JSON.stringify(report, null, 2)}\n`);
    return;
  }
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  const backupRoot = path.join(target, ".oos-backups", `runtime-${stamp}`);
  for (const item of changes.filter((entry) => entry.status !== "current")) {
    const destination = path.join(target, item.target);
    if (await exists(destination)) {
      const backup = path.join(backupRoot, item.target);
      await fsp.mkdir(path.dirname(backup), { recursive: true });
      await fsp.copyFile(destination, backup);
    }
    await fsp.mkdir(path.dirname(destination), { recursive: true });
    await fsp.copyFile(item.source, destination);
  }
  await fsp.copyFile(path.join(template, "public", "hud-baseline.json"), path.join(target, "public", "hud-baseline.json"));
  const queueFile = path.join(target, "data", "worker-queue.json");
  if (!(await exists(queueFile))) {
    await fsp.mkdir(path.dirname(queueFile), { recursive: true });
    await fsp.copyFile(path.join(template, "data", "worker-queue.json"), queueFile);
  }
  const overrides = path.join(target, "public", "public-overrides.css");
  if (!(await exists(overrides))) await fsp.copyFile(path.join(template, "public", "public-overrides.css"), overrides);
  await fsp.mkdir(path.join(target, "extensions"), { recursive: true });

  report.backup = backupRoot;
  report.updated = report.changes.map((item) => item.target);
  report.stateUntouched = true;
  process.stdout.write(`${JSON.stringify(report, null, 2)}\n`);
}

main().catch((error) => fail(error.stack || error.message));
