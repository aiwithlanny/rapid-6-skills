#!/usr/bin/env python3
"""Compatibility wrapper for the Node-based OOS initializer."""

from __future__ import annotations

import shutil
import subprocess
import sys
from pathlib import Path


def main() -> int:
    node = shutil.which("node")
    if not node:
        print("Node.js 18+ is required. `node` was not found on PATH.", file=sys.stderr)
        return 2
    script = Path(__file__).with_name("init_oos.js")
    return subprocess.call([node, str(script), *sys.argv[1:]])


if __name__ == "__main__":
    raise SystemExit(main())
