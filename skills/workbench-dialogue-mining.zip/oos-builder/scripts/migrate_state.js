#!/usr/bin/env node
"use strict";

const { fsp, path, parseArgs, readJson, writeJson, fail } = require("./_cli");
const { migrateState, validateState } = require("../assets/oos-template/lib/oos-state");

async function main() {
  const args = parseArgs(process.argv.slice(2));
  const target = path.resolve(args._[0] || process.cwd());
  const stateFile = target.endsWith(".json") ? target : path.join(target, "data", "state.json");
  const original = await readJson(stateFile);
  const result = migrateState(original);
  const validation = validateState(result.state);
  const changed = JSON.stringify(original) !== JSON.stringify(result.state);
  const report = { mode: args.write ? "write" : "dry-run", stateFile, changed, changes: result.changes, warnings: [...new Set([...result.warnings, ...validation.warnings])], validation };
  if (!validation.ok) {
    process.stdout.write(`${JSON.stringify(report, null, 2)}\n`);
    return fail("Migration output is invalid; nothing was written.", 2);
  }
  if (args.write && changed) {
    const stamp = new Date().toISOString().replace(/[:.]/g, "-");
    const backup = `${stateFile}.backup-${stamp}`;
    await fsp.copyFile(stateFile, backup);
    await writeJson(stateFile, result.state);
    report.backup = backup;
  }
  process.stdout.write(`${JSON.stringify(report, null, 2)}\n`);
}

main().catch((error) => fail(error.stack || error.message));
