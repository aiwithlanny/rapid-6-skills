#!/usr/bin/env node
"use strict";

const { fsp, path, parseArgs, readJson, writeJson, directoryIsEmpty, copyTree, fail } = require("./_cli");
const { validateState, deriveThemeTokens } = require("../assets/oos-template/lib/oos-state");
const { createUnifiedRuntime } = require("../assets/oos-template/lib/unified-runtime");

function slugify(value, fallback) {
  const slug = String(value || "").toLowerCase().normalize("NFKD").replace(/[^a-z0-9\u4e00-\u9fff]+/g, "-").replace(/^-|-$/g, "");
  return slug || fallback;
}

function navLabel(value, name) {
  const text = String(value || name || "Track").trim();
  if (/[\u4e00-\u9fff]/.test(text)) return [...text.replace(/[\s·:：|/\\—–_-]+/g, "")].slice(0, 8).join("") || "轨道";
  return text.replace(/\s+/g, " ").slice(0, 18).trim() || "Track";
}

function archetype(value) {
  const legacy = { content: "project", knowledge: "learning" };
  const candidate = legacy[value] || value;
  return ["project", "habit", "pipeline", "learning", "relationship", "trend"].includes(candidate) ? candidate : "project";
}

function accent(value) {
  const candidate = String(value || "").trim();
  return /^#[0-9a-f]{6}$/i.test(candidate) ? candidate.toLowerCase() : "#111111";
}

const VIEW_DEFAULTS = {
  project: { id: "milestones", type: "milestone-timeline", source: "logs.milestones" },
  habit: { id: "habit", type: "habit-heatmap", source: "logs.habits", metric: "completion" },
  pipeline: { id: "pipeline", type: "pipeline-board", source: "logs.pipeline" },
  learning: { id: "learning", type: "learning-progress", source: "logs.learning", metric: "minutes", unit: "min" },
  relationship: { id: "relationship", type: "relationship-pulse", source: "relationship.entries" },
  trend: { id: "trend", type: "trend-line", source: "logs.metrics", metric: "value" }
};

function trackViews(item, trackArchetype, label) {
  const explicit = Array.isArray(item.views) ? item.views : Array.isArray(item.visualizations) ? item.visualizations : [];
  const numericTarget = Object.prototype.hasOwnProperty.call(item, "targetValue")
    ? item.targetValue
    : (typeof item.target === "number" || /^\s*-?\d+(?:\.\d+)?\s*$/.test(String(item.target || "")) ? Number(item.target) : undefined);
  const input = explicit.length ? explicit : [{
    ...VIEW_DEFAULTS[trackArchetype],
    ...(item.metricKey ? { metric: String(item.metricKey) } : {}),
    ...(item.unit ? { unit: String(item.unit) } : {}),
    ...(numericTarget !== undefined ? { target: numericTarget } : {}),
    ...(item.direction ? { direction: String(item.direction) } : {})
  }];
  return input.map((raw, index) => {
    const view = { ...(raw && typeof raw === "object" ? raw : {}) };
    view.id = String(view.id || `${view.type || "view"}-${index + 1}`);
    view.type = String(view.type || VIEW_DEFAULTS[trackArchetype].type);
    view.source = String(view.source || VIEW_DEFAULTS[trackArchetype].source);
    view.label = String(view.label || label);
    if (Object.prototype.hasOwnProperty.call(view, "metric")) view.metric = String(view.metric);
    if (Object.prototype.hasOwnProperty.call(view, "unit")) view.unit = String(view.unit);
    return view;
  });
}

function today(timezone) {
  try { return new Intl.DateTimeFormat("en-CA", { timeZone: timezone, year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date()); }
  catch { return new Date().toISOString().slice(0, 10); }
}

function arrayOf(value) {
  if (Array.isArray(value)) return value;
  if (value === null || value === undefined || value === "") return [];
  return [value];
}

function datedEntries(values, fallbackTitle) {
  const rows = [];
  for (const raw of arrayOf(values)) {
    if (raw && typeof raw === "object") {
      const date = String(raw.date || raw.due || raw.deadline || "").slice(0, 10);
      if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) continue;
      rows.push({
        title: String(raw.title || raw.name || raw.label || fallbackTitle),
        date,
        status: String(raw.status || "planned"),
        summary: String(raw.summary || raw.note || "")
      });
      continue;
    }
    for (const segment of String(raw || "").split(/[\n；;。]+/).map((item) => item.trim()).filter(Boolean)) {
      const matches = [...segment.matchAll(/\b(20\d{2}-\d{2}-\d{2})\b/g)];
      for (const [index, match] of matches.entries()) {
        const nextIndex = matches[index + 1]?.index ?? segment.length;
        const title = segment
          .slice(Number(match.index) + match[0].length, nextIndex)
          .replace(/^[\s,，:：·—–-]+|[\s,，:：·—–-]+$/g, "")
          .trim();
        rows.push({ title: title || fallbackTitle, date: match[1], status: "planned", summary: "" });
      }
    }
  }
  const seen = new Set();
  return rows
    .filter((row) => {
      const key = `${row.date}|${row.title}`;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    })
    .sort((left, right) => left.date.localeCompare(right.date));
}

function checkpointEntries(item) {
  return arrayOf(item.checkpoints || item.coverage || item.learningCheckpoints).map((raw, index) => {
    if (raw && typeof raw === "object") {
      return {
        title: String(raw.title || raw.name || raw.label || `Checkpoint ${index + 1}`),
        status: String(raw.status || "planned"),
        ...(raw.date || raw.due ? { date: String(raw.date || raw.due).slice(0, 10) } : {})
      };
    }
    return { title: String(raw), status: "planned" };
  }).filter((entry) => entry.title);
}

function taskSeeds(item) {
  return arrayOf(item.initialTasks || item.actions || item.firstWeekActions).map((raw) => {
    if (raw && typeof raw === "object") return { ...raw };
    return { title: String(raw || "") };
  }).filter((entry) => String(entry.title || entry.name || entry.action || "").trim());
}

function normalizePlan(raw, args) {
  const input = Array.isArray(raw) ? { tracks: raw } : (raw && typeof raw === "object" ? raw : {});
  const user = input.user && typeof input.user === "object" ? input.user : {};
  const timezone = String(args.timezone || input.timezone || user.timezone || "Asia/Shanghai");
  const date = today(timezone);
  const owner = String(args.name || input.owner || input.name || user.name || user.owner || "OOS User");
  const sourceTracks = Array.isArray(input.tracks) ? input.tracks : Array.isArray(input.goals) ? input.goals : [];
  const source = sourceTracks.length ? sourceTracks.slice(0, 3) : [{ name: "Primary Track", target: "Define the desired outcome", nextAction: "Complete the first OOS check-in", risk: "medium" }];
  const tracks = source.map((item, index) => {
    const name = String(item.name || `Track ${index + 1}`);
    const trackArchetype = archetype(item.archetype || item.trackType);
    const label = navLabel(item.navLabel, name);
    const milestones = datedEntries([
      ...arrayOf(item.milestones),
      ...arrayOf(item.hardWindows),
      item.deadline
    ], `${name}节点`);
    const checkpoints = checkpointEntries(item);
    const stages = arrayOf(item.stages || item.pipelineStages).map(String).filter(Boolean);
    const views = trackViews(item, trackArchetype, label).map((view) => ({
      ...view,
      ...(trackArchetype === "learning" && checkpoints.length && !Array.isArray(view.checkpoints) ? { checkpoints } : {}),
      ...(trackArchetype === "pipeline" && stages.length && !Array.isArray(view.stages) ? { stages } : {}),
      ...(trackArchetype === "habit" && item.habitPlan && !view.habitPlan ? { habitPlan: item.habitPlan } : {})
    }));
    return {
      id: slugify(item.id || name, `track-${index + 1}`),
      name,
      navLabel: label,
      summary: String(item.summary || item.target || item.metric || "Keep the next meaningful outcome visible."),
      detail: String(item.detail || ""),
      archetype: trackArchetype,
      role: ["primary", "operational", "supporting"].includes(item.role) ? item.role : (index === 0 ? "primary" : index < 3 ? "operational" : "supporting"),
      cadenceDays: Math.max(1, Number(item.cadenceDays || 7)),
      monitoring: item.monitoring === false ? false : { ...(typeof item.monitoring === "object" ? item.monitoring : {}), enabled: item.monitoring?.enabled !== false },
      progress: Math.max(0, Math.min(100, Number(item.progress || 0))),
      trackType: trackArchetype,
      stage: String(item.stage || item.current || "Starting"),
      nextAction: String(item.nextAction || "Define the smallest next action."),
      nextActionDue: String(item.nextActionDue || item.due || ""),
      risk: ["low", "medium", "high"].includes(item.risk) ? item.risk : "medium",
      needsQuestion: String(item.needsQuestion || ""),
      metric: String(item.metric || item.target || "Pending definition."),
      target: String(item.target || "Pending definition."),
      deadline: String(
        item.deadline && typeof item.deadline === "object"
          ? (item.deadline.date || item.deadline.due || "")
          : (item.deadline || "")
      ).slice(0, 10),
      lastUpdated: date,
      views,
      milestones,
      checkpoints,
      initialTasks: taskSeeds(item),
      ...(item.habitPlan ? { habitPlan: item.habitPlan } : {}),
      ...(stages.length ? { pipelineStages: stages } : {})
    };
  });
  const hudInput = input.hud && typeof input.hud === "object" ? input.hud : {};
  const enabledModules = ["Today", "Plan", "Tracks"];
  return {
    owner,
    timezone,
    date,
    tracks,
    accent: accent(input.theme?.accent || input.themeColor || input.visual?.accentColor),
    profile: {
      useRhythm: Array.isArray(input.useRhythm) ? input.useRhythm.map(String) : Array.isArray(user.useRhythm) ? user.useRhythm.map(String) : [],
      privacy: input.privacy && typeof input.privacy === "object" ? input.privacy : {},
      firstWeek: input.firstWeek && typeof input.firstWeek === "object" ? input.firstWeek : {},
      watchTracks: Array.isArray(input.watchTracks) ? input.watchTracks : []
    },
    hud: { ...hudInput, enabledModules, disabledModules: [] },
    currentTruth: input.currentTruth && typeof input.currentTruth === "object" ? input.currentTruth : {},
    visual: input.visual && typeof input.visual === "object" ? input.visual : {}
  };
}

function buildState(plan) {
  const stateTracks = plan.tracks.map(({ initialTasks, milestones, ...track }) => track);
  const goals = stateTracks.map((track) => ({ id: track.id, name: track.name, navLabel: track.navLabel, progress: track.progress, stage: track.stage, nextAction: track.nextAction, lastUpdated: track.lastUpdated, risk: track.risk, metric: track.metric, archetype: track.archetype, trackType: track.archetype }));
  const themeTokens = deriveThemeTokens(plan.accent);
  return {
    meta: {
      schemaVersion: 3,
      name: "OOS",
      fullName: "OOS Personal Operating System",
      owner: plan.owner,
      timezone: plan.timezone,
      lastUpdated: new Date().toISOString(),
      version: 1,
      maintenanceMode: "Chat-first / Agent-maintained",
      dataIntegrity: "Only user-stated facts are real; missing data remains pending.",
      theme: { accent: themeTokens.accent, warn: "#c3542f", ok: "#14865b", sidebar: "dark", style: "oos-line-workbench" },
      readiness: { operationalReady: true, visualReady: false, firstFlight: "not_started" },
      hudBaseline: "oos-unified-v5.1"
    },
    onboarding: {
      firstFlight: { status: "not_started", currentStep: 0, completedSteps: [] }
    },
    visual: {
      mode: "none",
      status: "not_started",
      provider: "",
      acceptedDirection: "",
      fingerprint: "",
      approvedAt: "",
      brief: plan.visual
    },
    profile: plan.profile,
    hud: plan.hud,
    watchTracks: plan.profile.watchTracks,
    principles: ["Know what matters now", "Keep the next action visible", "Preserve context without overload"],
    tracks: stateTracks,
    goals,
    tasks: [],
    scheduleBlocks: [],
    capabilities: [
      { id: "local-state", name: "OOS local state", kind: "local", status: "available", scopes: ["read", "write-low-risk"], approvalPolicy: "automatic-low-risk" },
      { id: "agent-runtime", name: "Compatible agent runtime", kind: "runtime", status: "manual", scopes: ["delegate", "automate"], approvalPolicy: "conversation-owned" },
      { id: "state-cli", name: "OOS State CLI", kind: "local", status: "available", scopes: ["read", "write-versioned", "worker-review"], approvalPolicy: "automatic-low-risk" }
    ],
    approvals: [],
    delegations: [],
    receipts: [],
    questions: plan.tracks.flatMap((track) => {
      const items = [];
      if (!track.target || track.target === "Pending definition.") items.push({ id: `q-${track.id}-target`, text: `“${track.name}”最终要产生什么结果？`, goal: track.id, date: plan.date, resolved: false });
      if (track.needsQuestion) items.push({ id: `q-${track.id}-risk`, text: track.needsQuestion, goal: track.id, date: plan.date, resolved: false });
      return items;
    }),
    notes: [{ id: "note-oos-start", date: plan.date, title: "OOS starts from chat", summary: "Speak naturally; your compatible agent can maintain the system.", body: "The HUD projects current focus while chat remains the primary interface.", tags: ["system"], relatedGoals: ["system"], links: [] }],
    activity: [{ id: "activity-initialized", date: plan.date, text: "OOS 已根据确认后的个人计划完成初始化。", relatedGoal: "system" }],
    logs: {
      daily: [],
      checkins: [],
      milestones: plan.tracks.flatMap((track) => track.milestones.map((entry, index) => ({
        id: `milestone-${track.id}-${index + 1}`,
        goal: track.id,
        trackId: track.id,
        title: entry.title,
        date: entry.date,
        status: entry.status || "planned",
        summary: entry.summary || ""
      }))),
      pipeline: [],
      habits: [],
      learning: [],
      metrics: [],
      executions: []
    },
    context: { memories: [] },
    decisions: [],
    relationship: { enabled: false, partnerLabel: "Partner", scale: "0-5", entries: [], openRepairs: [] },
    inbox: []
  };
}

function initialTaskOps(plan) {
  const ops = [];
  const seen = new Set();
  const scheduleIso = (date, minute) => {
    const dateValue = new Date(`${date}T12:00:00Z`);
    dateValue.setUTCDate(dateValue.getUTCDate() + Math.floor(minute / 1440));
    const normalizedMinute = ((minute % 1440) + 1440) % 1440;
    const hour = String(Math.floor(normalizedMinute / 60)).padStart(2, "0");
    const minutes = String(normalizedMinute % 60).padStart(2, "0");
    return `${dateValue.toISOString().slice(0, 10)}T${hour}:${minutes}:00+08:00`;
  };
  const append = (track, seed, index, fallbackId) => {
    const title = String(seed.title || seed.name || seed.action || "").trim();
    if (!title) return;
    const key = `${track.id}|${title.toLowerCase()}`;
    if (seen.has(key)) return;
    seen.add(key);
    const due = String(seed.due || seed.date || "").slice(0, 10);
    const status = String(seed.status || "open");
    const task = {
      id: String(seed.id || fallbackId || `task-${track.id}-${index + 1}`),
      title,
      goal: track.id,
      status,
      priority: String(seed.priority || (track.risk === "high" ? "high" : "normal")),
      nextStep: String(seed.nextStep || title),
      estimatedMinutes: Math.max(15, Number(seed.estimatedMinutes || seed.durationMinutes || 60))
    };
    if (/^\d{4}-\d{2}-\d{2}$/.test(due)) task.due = due;
    if (seed.scheduleDate) task.scheduleDate = String(seed.scheduleDate).slice(0, 10);
    if (seed.reviewAt) task.reviewAt = String(seed.reviewAt).slice(0, 10);
    if (seed.reviewEveryDays) task.reviewEveryDays = Math.max(1, Number(seed.reviewEveryDays));
    ops.push({
      type: "task.create",
      task,
      ...((seed.unscheduled === true || !["open", "in_progress"].includes(status)) ? { unscheduled: true } : {})
    });
    const scheduleTime = String(seed.scheduleTime || "").trim();
    const timeMatch = scheduleTime.match(/^([01]\d|2[0-3]):([0-5]\d)$/);
    const scheduleDate = String(seed.scheduleDate || due || plan.date).slice(0, 10);
    if (
      timeMatch
      && /^\d{4}-\d{2}-\d{2}$/.test(scheduleDate)
      && ["open", "in_progress"].includes(status)
      && seed.unscheduled !== true
    ) {
      const startMinute = Number(timeMatch[1]) * 60 + Number(timeMatch[2]);
      const duration = Math.max(15, Math.ceil(task.estimatedMinutes / 15) * 15);
      ops.push({
        type: "schedule.create",
        block: {
          id: `block-seed-${task.id}`,
          taskId: task.id,
          title: task.title,
          goal: task.goal,
          kind: track.archetype === "habit" ? "routine" : "focus",
          startAt: scheduleIso(scheduleDate, startMinute),
          endAt: scheduleIso(scheduleDate, startMinute + duration),
          status: "planned",
          source: "system",
          locked: false,
          note: task.nextStep
        }
      });
    }
  };

  for (const track of plan.tracks) {
    append(track, {
      title: track.nextAction,
      due: track.nextActionDue,
      priority: track.risk === "high" ? "high" : "normal",
      estimatedMinutes: track.archetype === "habit" ? 15 : 60,
      ...(track.archetype === "habit" && (track.habitPlan?.actionTime || track.habitPlan?.targetTime)
        ? { scheduleDate: plan.date, scheduleTime: track.habitPlan.actionTime || track.habitPlan.targetTime }
        : {})
    }, 0, `task-${track.id}-next`);
    track.initialTasks.forEach((seed, index) => append(track, seed, index + 1));
  }

  const primary = plan.tracks[0];
  for (const [index, raw] of arrayOf(plan.profile.firstWeek.actions).entries()) {
    const seed = raw && typeof raw === "object" ? { ...raw } : { title: String(raw || "") };
    const requested = String(seed.trackId || seed.goal || "");
    const track = plan.tracks.find((entry) => entry.id === requested || entry.name === requested || entry.navLabel === requested)
      || plan.tracks.find((entry) => String(seed.title || "").includes(entry.name) || String(seed.title || "").includes(entry.navLabel))
      || primary;
    if (track) append(track, seed, index + 1, `task-${track.id}-week-${index + 1}`);
  }
  return ops;
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  if (!args._[0]) return fail("Usage: node init_oos.js <empty-target-directory> [--plan plan.json] [--name NAME] [--timezone IANA]", 2);
  const target = path.resolve(args._[0]);
  if (!(await directoryIsEmpty(target))) return fail(`Target must be empty; refusing to overwrite: ${target}`, 2);
  let rawPlan = {};
  const planFile = args.plan || args["goals-file"];
  if (planFile) rawPlan = await readJson(path.resolve(String(planFile)));
  const plan = normalizePlan(rawPlan, args);
  const state = buildState(plan);
  const validation = validateState(state);
  if (!validation.ok) return fail(`Generated state is invalid: ${validation.errors.join("; ")}`, 2);

  const template = path.resolve(__dirname, "..", "assets", "oos-template");
  await fsp.mkdir(target, { recursive: true });
  await copyTree(template, target);
  await writeJson(path.join(target, "data", "state.json"), state);
  await fsp.mkdir(path.join(target, "brain", "Current"), { recursive: true });
  await fsp.mkdir(path.join(target, "brain", "Inbox"), { recursive: true });
  await fsp.mkdir(path.join(target, "brain", "Daily"), { recursive: true });
  await fsp.mkdir(path.join(target, "brain", "Wiki"), { recursive: true });
  await fsp.mkdir(path.join(target, "extensions"), { recursive: true });
  const trackLines = plan.tracks.map((track) => `- **${track.name}** — ${track.stage}; next: ${track.nextAction}`).join("\n");
  const truthLines = Array.isArray(plan.currentTruth.next72Hours) && plan.currentTruth.next72Hours.length ? plan.currentTruth.next72Hours.map((item) => `- ${item}`).join("\n") : trackLines;
  const questionLines = plan.tracks.filter((track) => track.needsQuestion).map((track) => `- **${track.name}:** ${track.needsQuestion}`).join("\n") || "- Add only questions that can change the next action.";
  await fsp.writeFile(path.join(target, "brain", "Current", "current-truth.md"), `# Current Truth\n\nUpdated: ${plan.date}\n\n## Active 24-72 hours\n\n${truthLines}\n\n## Track orientation\n\n${trackLines}\n\n## Unknowns\n\n${questionLines}\n`, "utf8");
  await fsp.writeFile(path.join(target, "brain", "Inbox", "inbox.md"), "# Inbox\n\nCapture unclassified thoughts here.\n", "utf8");
  await fsp.writeFile(path.join(target, "brain", "Daily", `${plan.date}.md`), `# ${plan.date}\n\n- 已为 ${plan.owner} 初始化 OOS。\n- 当前活跃轨道：${plan.tracks.map((track) => track.name).join("、")}。\n`, "utf8");
  const rhythmLines = plan.profile.useRhythm.map((item) => `- ${item}`).join("\n") || "- Not specified yet.";
  const privacy = plan.profile.privacy;
  const hiddenLines = Array.isArray(privacy.hideOrSummarize) ? privacy.hideOrSummarize.map((item) => `- ${item}`).join("\n") : "- Not specified yet.";
  const neverLines = Array.isArray(privacy.neverInclude) ? privacy.neverInclude.map((item) => `- ${item}`).join("\n") : "- Never include credentials, secrets, or private raw records.";
  const firstWeekActions = Array.isArray(plan.profile.firstWeek.actions)
    ? plan.profile.firstWeek.actions.map((item) => `- ${typeof item === "object" ? (item.title || item.action || item.name || "Untitled action") : item}`).join("\n")
    : "- Follow the visible next actions.";
  await fsp.writeFile(path.join(target, "brain", "Wiki", "personal-operating-profile.md"), `# Personal Operating Profile\n\n## Use rhythm\n\n${rhythmLines}\n\n## HUD modules\n\n- Enabled: ${plan.hud.enabledModules.join(", ") || "Core only"}\n- Disabled: ${plan.hud.disabledModules.join(", ") || "None"}\n\n## Privacy: hide or summarize\n\n${hiddenLines}\n\n## Privacy: never include\n\n${neverLines}\n\n## First week\n\n${firstWeekActions}\n${plan.profile.firstWeek.checkpoint ? `\nCheckpoint: ${plan.profile.firstWeek.checkpoint}\n` : ""}`, "utf8");
  const readme = path.join(target, "README.md");
  try {
    const text = await fsp.readFile(readme, "utf8");
    await fsp.writeFile(readme, text.replaceAll("{{OWNER}}", plan.owner).replaceAll("{{TIMEZONE}}", plan.timezone), "utf8");
  } catch {}
  const runtime = createUnifiedRuntime({
    root: target,
    stateFile: path.join(target, "data", "state.json"),
    queueFile: path.join(target, "data", "worker-queue.json"),
    currentTruthFile: path.join(target, "brain", "Current", "current-truth.md"),
    cursorFile: path.join(target, "data", ".runtime-cache", "change-cursors.json")
  });
  const initialized = await runtime.submit({
    expectedVersion: 1,
    clientMutationId: "system-initial-task-seed-v1",
    source: "system",
    summary: "Create the first canonical actions and schedule them.",
    relatedGoal: "system",
    ops: initialTaskOps(plan)
  });
  if (initialized.status !== "done") return fail(`Initial task transaction failed: ${initialized.status}`, 2);
  process.stdout.write(`${JSON.stringify({ target, owner: plan.owner, timezone: plan.timezone, trackCount: plan.tracks.length, taskCount: initialized.state.tasks.length, scheduleBlockCount: initialized.state.scheduleBlocks.length, stateVersion: initialized.version, schemaVersion: 3, accent: plan.accent, operationalReady: true, visualReady: false }, null, 2)}\n`);
}

main().catch((error) => fail(error.stack || error.message));
