"use strict";

const fs = require("fs");
const fsp = require("fs/promises");
const path = require("path");
const crypto = require("crypto");

function parseArgs(argv) {
  const out = { _: [] };
  for (let i = 0; i < argv.length; i += 1) {
    const token = argv[i];
    if (!token.startsWith("--")) out._.push(token);
    else {
      const [rawKey, inline] = token.slice(2).split("=", 2);
      if (inline !== undefined) out[rawKey] = inline;
      else if (argv[i + 1] && !argv[i + 1].startsWith("--")) out[rawKey] = argv[++i];
      else out[rawKey] = true;
    }
  }
  return out;
}

async function readJson(file) {
  return JSON.parse((await fsp.readFile(file, "utf8")).replace(/^\uFEFF/, ""));
}

async function writeJson(file, value) {
  await fsp.mkdir(path.dirname(file), { recursive: true });
  await fsp.writeFile(file, `${JSON.stringify(value, null, 2)}\n`, "utf8");
}

async function directoryIsEmpty(dir) {
  try { return (await fsp.readdir(dir)).length === 0; } catch (error) { if (error.code === "ENOENT") return true; throw error; }
}

async function walk(root) {
  const files = [];
  async function visit(dir) {
    for (const entry of await fsp.readdir(dir, { withFileTypes: true })) {
      if ([".git", "node_modules", "__pycache__", ".DS_Store"].includes(entry.name)) continue;
      const absolute = path.join(dir, entry.name);
      if (entry.isDirectory()) await visit(absolute);
      else files.push(absolute);
    }
  }
  await visit(root);
  return files;
}

const BINARY_EXTENSIONS = new Set([".png", ".jpg", ".jpeg", ".gif", ".webp", ".ico", ".woff", ".woff2", ".zip"]);
const PRIVATE_PATTERNS = [
  ["windows-user-path", /[A-Za-z]:\\Users\\[^\\\s]+/g],
  ["posix-user-path", /\/(?:Users|home)\/[^/\s]+/g],
  ["api-key", /\b(?:sk-[A-Za-z0-9_-]{16,}|api[_-]?key\s*[:=]\s*["']?[^\s"']{12,})/gi],
  ["private-key", /-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/g],
  ["credential", /\b(?:password|secret|token)\s*[:=]\s*["'][^"']{8,}["']/gi],
  ["known-private-context", /\b(?:AnySearch|Huawei|Mate\s*X7|Niko)\b|hero['’]?s journey/gi]
];

async function scanPrivacy(root) {
  const findings = [];
  const localUsername = String(process.env.USERNAME || process.env.USER || "").trim();
  const usernamePattern = localUsername && !/^(?:user|runner|root)$/i.test(localUsername)
    ? new RegExp(localUsername.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "i")
    : null;
  for (const file of await walk(root)) {
    const relative = path.relative(root, file).replaceAll("\\", "/");
    if (/\.(?:pyc|pfx|pem|key)$/i.test(relative)) findings.push({ file: relative, rule: "forbidden-file-type" });
    if (/\/(?:private|personal|exports?|backups?)\//i.test(`/${relative}`)) findings.push({ file: relative, rule: "private-directory-name" });
    if (/public\/assets\/persona\/.*\.(?:png|jpe?g|webp)$/i.test(relative)) findings.push({ file: relative, rule: "personal-image" });
    if (/brain\/Daily\/[^/]+\.md$/i.test(relative)) findings.push({ file: relative, rule: "private-daily-log" });
    if (usernamePattern?.test(relative)) findings.push({ file: relative, rule: "local-username" });
    if (BINARY_EXTENSIONS.has(path.extname(file).toLowerCase())) continue;
    const text = await fsp.readFile(file, "utf8");
    for (const [rule, regex] of PRIVATE_PATTERNS) {
      if (rule === "known-private-context" && relative === "scripts/_cli.js") continue;
      regex.lastIndex = 0;
      if (regex.test(text)) findings.push({ file: relative, rule });
    }
    if (usernamePattern?.test(text)) findings.push({ file: relative, rule: "local-username" });
    if (relative === "assets/oos-template/data/state.json") {
      try {
        const state = JSON.parse(text.replace(/^\uFEFF/, ""));
        if (state.meta?.owner !== "OOS User" || state.tracks?.some((item) => item.id !== "primary-track")) findings.push({ file: relative, rule: "non-generic-template-state" });
      } catch { findings.push({ file: relative, rule: "invalid-template-state" }); }
    }
  }
  return findings;
}

async function copyTree(source, target) {
  await fsp.cp(source, target, {
    recursive: true,
    filter: (entry) => ![".git", "node_modules", "__pycache__", ".DS_Store"].includes(path.basename(entry))
  });
}

async function sha256Manifest(root, excluded = new Set()) {
  const manifest = {};
  for (const file of (await walk(root)).sort()) {
    const relative = path.relative(root, file).replaceAll("\\", "/");
    if (excluded.has(relative)) continue;
    manifest[relative] = crypto.createHash("sha256").update(await fsp.readFile(file)).digest("hex");
  }
  return manifest;
}

function fail(message, code = 1) {
  process.stderr.write(`${message}\n`);
  process.exitCode = code;
}

module.exports = { fs, fsp, path, parseArgs, readJson, writeJson, directoryIsEmpty, walk, scanPrivacy, copyTree, sha256Manifest, fail };
