#!/usr/bin/env node
"use strict";

const { fsp, path, parseArgs, directoryIsEmpty, copyTree, scanPrivacy, sha256Manifest, writeJson, fail } = require("./_cli");

async function main() {
  const args = parseArgs(process.argv.slice(2));
  const skillRoot = path.resolve(args.source || path.join(__dirname, ".."));
  if (!args.output) return fail("Usage: node package_public.js --output <empty-directory> [--source <skill-directory>]", 2);
  const output = path.resolve(String(args.output));
  if (!(await directoryIsEmpty(output))) return fail(`Output directory must be empty: ${output}`, 2);
  const releaseFiles = [
    "SKILL.md",
    "agents/openai.yaml",
    "references/persona-assets.md",
    "scripts/apply_persona_assets.js",
    "scripts/verify_install.js",
    "assets/style-reference/oos-persona-line-dna.png",
    "assets/oos-template/public/hud-baseline.json"
    ,"assets/oos-template/runtime-manifest.json"
  ];
  const releaseMisses = [];
  for (const relative of releaseFiles) {
    try {
      const stat = await fsp.stat(path.join(skillRoot, relative));
      if (!stat.isFile() || (relative.endsWith(".png") && stat.size < 32768)) releaseMisses.push(relative);
    } catch { releaseMisses.push(relative); }
  }
  if (releaseMisses.length) return fail(`Skill release prerequisites are missing or invalid: ${releaseMisses.join(", ")}`, 2);
  await fsp.mkdir(output, { recursive: true });
  await copyTree(skillRoot, path.join(output, "oos-builder"));
  const stagedSkill = path.join(output, "oos-builder");
  const findings = await scanPrivacy(stagedSkill);
  const report = { generatedAt: new Date().toISOString(), package: "oos-builder", publicSafe: findings.length === 0, findings };
  await writeJson(path.join(output, "privacy-report.json"), report);
  if (findings.length) return fail(`Privacy scan found ${findings.length} blocking item(s).`, 3);
  const manifest = await sha256Manifest(output, new Set(["SHA256SUMS.json"]));
  await writeJson(path.join(output, "SHA256SUMS.json"), { algorithm: "sha256", files: manifest });
  process.stdout.write(`${JSON.stringify({ output, fileCount: Object.keys(manifest).length, privacySafe: true }, null, 2)}\n`);
}

main().catch((error) => fail(error.stack || error.message));
