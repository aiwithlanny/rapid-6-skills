#!/usr/bin/env node
"use strict";

const crypto = require("crypto");
const fs = require("fs/promises");
const path = require("path");

const TEMPLATE = path.resolve(__dirname, "..", "assets", "oos-template");
const BASELINE = path.join(TEMPLATE, "public", "hud-baseline.json");
const TEXT_EXTENSIONS = new Set([".js", ".json", ".css", ".html", ".md", ".svg", ".txt", ".yaml", ".yml", ".ps1"]);
const CORE_FILES = [
  "runtime-manifest.json",
  "AGENTS.md",
  "docs/worker-model.md",
  "docs/task-lifecycle.md",
  "package.json",
  "server.js",
  "lib/oos-operations.js",
  "lib/oos-state.js",
  "lib/oos-state-model.js",
  "lib/oos-context-kernel.js",
  "lib/oos-derived.js",
  "lib/task-lifecycle.js",
  "lib/text-integrity.js",
  "lib/startup-freshness.js",
  "lib/unified-runtime.js",
  "lib/oos-store.js",
  "scripts/oos-state.js",
  "scripts/check-operation-registry.js",
  "scripts/sync-operation-registry.js",
  "scripts/check-runtime-manifest.js",
  "scripts/check-state.js",
  "scripts/test-cross-surface-golden.js",
  "scripts/test-personal-context-kernel.js",
  "scripts/test-calendar-engine.js",
  "scripts/test-plan-workbench.js",
  "scripts/test-worker-observability.js",
  "scripts/test-text-integrity.js",
  "scripts/test-startup-freshness.js",
  "scripts/test-store-transaction.js",
  "scripts/test-runtime-binding.js",
  "public/styles.css",
  "public/calendar.css",
  "public/calendar-engine.js",
  "public/calendar-ui.js",
  "public/app.js",
  "public/oos-client.js",
  "public/index.html",
  "public/favicon.svg",
  "public/assets/brand/odyssey-logo-mark.png"
];

async function sha256(file) {
  const data = await fs.readFile(file);
  const input = TEXT_EXTENSIONS.has(path.extname(file).toLowerCase()) ? data.toString("utf8").replace(/\r\n/g, "\n") : data;
  return crypto.createHash("sha256").update(input).digest("hex");
}

async function build() {
  const files = [];
  for (const target of CORE_FILES) files.push({ target, sha256: await sha256(path.join(TEMPLATE, target)) });
  return {
    contract: "oos-unified-v5.1",
    sourceBranch: "codex/oos-builder-v5-1-convergence",
    theme: "user-selected-with-neutral-fallback",
    stateBinding: "observable-embedded-worker+agent-review+semantic-receipts+change-feed+operation-registry+agent-cli+sse+polling",
    requiredSurfaces: ["today", "plan", "tracks"],
    requiredPatterns: ["health-strip", "worker-drawer", "cockpit-timeline", "hard-window-list", "guide-card", "track-grid", "capture", "today-close", "calendar-shell", "calendar-workbench-v3", "four-week-calendar", "selected-day-timeline", "week-calendar", "month-calendar", "agenda-calendar", "calendar-block", "trend-chart", "metric-form", "first-flight"],
    mutablePaths: ["data/**", "brain/**", "public/public-overrides.css", "public/assets/persona/generated/**", "docs/visual-assets-log.md"],
    extensionPaths: ["extensions/**"],
    files
  };
}

async function main() {
  const expected = `${JSON.stringify(await build(), null, 2)}\n`;
  if (process.argv.includes("--write")) {
    await fs.writeFile(BASELINE, expected, "utf8");
    console.log(`Runtime baseline updated: ${CORE_FILES.length} files.`);
    return;
  }
  const current = await fs.readFile(BASELINE, "utf8");
  if (current !== expected) {
    console.error("Runtime baseline is stale. Run: node scripts/update_runtime_baseline.js --write");
    process.exit(1);
  }
  console.log(`Runtime baseline verified: ${CORE_FILES.length} files.`);
}

main().catch((error) => { console.error(error.message); process.exit(1); });
