---
name: oos-builder
description: Build, initialize, migrate, verify, operate, and package a complete OOS / Hero OS personal operating system and workbench with Current Truth, schema-v3 Tracks, a local static HUD, deterministic state operations, and an optional prototype-to-delivery workflow. Use for new OOS or workbench creation, existing-system migration, HUD operation, product-readiness review, optional deployment preparation, visual personalization, release verification, or privacy-safe Xiaohongshu / REDSkill packaging across Codex, Claude Code, and compatible Agent Skills runtimes.
---

# OOS Builder

Treat chat as the brain, Current Truth as the 24-72 hour locator, the HUD as the cockpit, Markdown as durable memory, and state ops as reversible buttons. Deliver a useful system immediately; continue customizing and iterating after installation.

Release status: `5.1.0` public release on the `oos-unified-v5.1` Runtime contract. It includes observable Worker execution, hard Agent operating rules, structured plan compilation, and the data-first HUD composition proven in the main OOS. The packaged release must still pass its privacy report, SHA-256 manifest, and forward-install checks before every upload.

## Build a new OOS

Follow this default order:

1. Explain OOS briefly in plain language.
2. Read `references/intake.md` and conduct the short interview.
3. Produce and confirm a Personal OOS Plan with 1-3 Tracks and the user's theme color. Infer each Track's operational views from its archetype and progress signal; do not make the user choose chart widgets during intake.
4. Save the confirmed plan as UTF-8 JSON. Use `archetype` for new Tracks and accept legacy `trackType` during migration. Preserve `views`, `nextActionDue`, `needsQuestion`, structured `milestones` / `hardWindows`, learning `checkpoints`, pipeline `stages`, `habitPlan`, rhythm, privacy, Current Truth, and first-week actions. Omit unknown dates. Do not flatten several dated checkpoints into one deadline sentence.
5. Initialize a complete asset-free HUD:

   ```text
   node scripts/init_oos.js <empty-target-directory> --plan <plan.json>
   ```

6. Verify operational readiness:

   ```text
   node scripts/verify_install.js <target-directory> --mode operational
   npm.cmd run check
   ```

7. Start with `npm.cmd start`. Open `http://127.0.0.1:4174` unless `OOS_HOST` or `PORT` overrides it.
8. Offer First Flight: capture one real update, perform one reversible state operation, and confirm the HUD refreshes. Let the user skip it; record it as resumable onboarding rather than a blocker.

The initializer must refuse a non-empty target. Use `scripts/init_oos.py` only as a compatibility wrapper; Node.js 18+ remains required.

## Build or ship a workbench

When the user asks to create a workbench, turn an existing prototype into a usable product, publish the HUD, or prepare it for other people, read `references/workbench-delivery.md` and select the smallest applicable mode:

- `personal-local`: one owner, local-first, no public deployment required;
- `shared-preview`: a reviewable URL with test data and explicit access boundaries;
- `deliverable-template`: each recipient gets an independent copy and data space;
- `public-product`: public use with an explicit data, secrets, privacy, and support model.

Do not assume that a local personal OOS should become public. Deployment, external account creation, domain changes, and uploads require explicit authorization. If the intended audience or data boundary is unclear, stop before architecture or deployment changes and resolve that decision in chat.

Use the delivery gates in order, but resume from the first gate without sufficient evidence instead of restarting completed work. Keep a compact readiness record with status, evidence, open risks, and the next acceptance check for every gate. “It runs on my machine” is prototype evidence, not delivery evidence.

For a new OOS that the user intends to share or sell, confirm the Personal OOS Plan first, initialize and verify the bundled Runtime, then enter the delivery gates. Do not replace the verified Runtime during this process unless the user explicitly requests a product-level frontend change.

## Reuse the bundled Runtime

Treat `assets/oos-template` as a complete versioned product Runtime, not as inspiration for an Agent to rewrite. Initialization must copy its verified frontend, server, State Service, Agent CLI, interaction components, loading/error/conflict states, calendar, Track visualizations, and First Flight unchanged.

Personalize through the generated state, Current Truth, Tracks, theme tokens, `public/public-overrides.css`, optional reviewed assets, and explicit extensions. Do not rebuild the core HTML/CSS/JavaScript for each user. Modify or eject Runtime files only when the user explicitly asks for a product-level frontend change.

For an existing generated OOS, preview a Runtime upgrade with `node scripts/upgrade_runtime.js <workspace>`. Review modified core files, then use `--write` only after confirmation. The upgrader backs up replaced core files and leaves State, its version, Current Truth, brain, overrides, user assets, and extensions untouched; operational state changes remain owned by state ops and the Worker. Text-file hashes normalize CRLF/LF so Windows checkout differences are not reported as product drift.

## Keep the navigation stable

Use Today, Plan, and Tracks as the fixed core navigation. Notes are a global Quick Capture, search result, and Track-linked context library; Review is a derived Today closeout and periodic entry, not another primary page. Do not ask which author-domain modules to install. Represent content, fitness, commercial, learning, renovation, relationships, and other life areas as user-defined Tracks, not hard-coded product sections.

Give each Track an optional `navLabel` derived from its name. Keep it readable at HUD scale: 4-8 Chinese characters or 10-18 Latin characters. Ask only when shortening would change the meaning.

## Assemble operational views

Always ship the Plan calendar with the same canonical `scheduleBlocks` used by Today. Its default desktop workbench is one continuous surface: a four-week overview, the selected day's precise timeline, and a sticky unscheduled-task shelf. The selected-day plan is the scheduled-block view; do not create a second "scheduled cards" collection or duplicate status. A block can move inside the selected-day timeline or be dragged from the four-week overview to another date while preserving its time and duration. An unscheduled task can be dropped on a date for the first available 15-minute-aligned 60-minute slot, or directly on the selected-day timeline for precise placement. Keep week, month, and agenda as alternate inspection modes.

Plan is a work surface, so remove the presentation Hero there. On desktop, keep operational text readable: timeline labels and metadata at least 11px, body and controls 12-13px, block titles 13px, section titles 16-18px, and interactive controls at least 32px high. Verify 1280x720, 1440x900, and 1920x1080 without horizontal overflow.

When Worker risk rules classify a drag or edit as a major change, the HUD must show an explicit confirmation drawer and resubmit the same intended ops with a fresh mutation id and `confirmedMajor: true`. A generic failure toast is not an acceptable confirmation flow.

Infer Track views by behavior:

- `project`: milestone timeline and hard-window calendar;
- `habit`: check-in grid and continuity;
- `trend`: real metric line with target, unit, and quick recording;
- `pipeline`: stage counts and delivery calendar;
- `learning`: coverage and weekly effort;
- `relationship`: private activity rhythm and recent authorized context.

Read `references/goal-model.md` for the reusable `views` contract and `references/visual-system.md` for interaction rules. Charts must come from real logs. Render an explicit empty state when evidence is missing; never substitute progress percentages for a time series.

## Add visual soul only when invited

Treat visuals as a built-in optional chapter. Do not ask for photos, persona direction, visual scenes, or an image provider during default setup. The asset-free HUD is complete and usable.

When the user asks to “加入灵魂”, personalize the visuals, or add character scenes, read `references/persona-assets.md`. Use any available image-generation provider or user-supplied reviewed assets; never make the core workflow depend on one provider.

Before running the local visual-asset application script（本地视觉资产应用脚本）, state exactly which workspace files it will add or update. Keep visual changes local, inspect them, and preserve the operational HUD if personalization is skipped or interrupted.

## Audit or migrate

- Run `node scripts/audit_existing.js <workspace>` for a read-only audit.
- Run `node scripts/migrate_state.js <workspace>` to preview schema-v3 normalization.
- Review warnings. Never invent completion times or progress.
- Run with `--write` only after confirmation; require a backup and idempotent second run.
- Audit and verify again after migration.

Use canonical `tracks`, `scheduleBlocks`, and `meta.version`. Derive health at read time; never persist `__derived`.

## Operate safely

- Distinguish the embedded Worker from an Agent or subagent. The Worker is deterministic local code: it serializes State Ops, checks version and risk, writes atomically, rebuilds Current Truth, records receipts, and emits sync events. A subagent is optional reasoning capacity and never owns persistence.
- In a generated workspace, read the version with `node scripts/oos-state.js meta`, write a UTF-8 operation payload, and run `node scripts/oos-state.js op --expected-version <version> --file <ops.json>`. The file may be a direct operation array or an envelope with `ops`/`operations`. This is the default Agent binding.
- At every Agent or automation wake, consume `node scripts/oos-state.js changes --consumer <stable-id>`. If it reports `resyncRequired`, reload state and Current Truth; acknowledge only after reading the affected entities.
- The CLI uses `/api/state-ops` while the server is available and the same locked atomic State Runtime offline. Do not patch `data/state.json` directly during normal operation.
- The CLI verifies the server's workspace instance id before every HTTP operation so another OOS on the default port cannot receive the write.
- Use `/api/state-ops` directly only for compatible clients that implement the same expected-version contract.
- Use `metric.record` for an explicit numeric Track measurement. Preserve its date, unit, source, and optional note.
- Send `expectedVersion` and a unique `clientMutationId` with every mutation. On `409 state_conflict`, reload and retry only the intended action. Reuse an ID only to retry the identical payload.
- Keep `schedule.complete` (one execution) distinct from `task.complete` (the entire canonical task and its linked lifecycle).
- Use `memory.observe/correct/forget` and `decision.record/review/outcome` for explainable long-term personalization. Preserve evidence arrays and `relatedTrackIds`; `memory.kind` is accepted as an alias for canonical `memory.type`. Inferred patterns need three supporting observations across two days and confidence of at least 0.75; candidate patterns may only prompt a question, and sensitive inference requires disclosure plus corroboration. Use `node scripts/oos-state.js attention` to inspect derived reminders without a browser.
- Expect an open HUD to refresh through `state.changed` SSE with five-second and focus polling fallback. Manual refresh is a recovery action, not the normal Agent-to-HUD sync mechanism.
- Review real pending captures with `node scripts/oos-state.js worker-list`; apply the chosen state operation before resolving the Worker item.
- Explain Quick Capture accurately: the note commits immediately through the Worker; its separate `capture.review` item waits for Agent judgment and is not autonomous classification.
- Keep major goal, priority, schedule, business, and sensitive relationship decisions in chat.
- Preserve history and UTF-8. Do not invent progress.
- Read `references/maintenance.md` for daily operation and First Flight recovery.
- Read `references/goal-model.md` when selecting progress models.
- Read `references/visual-system.md` only for HUD styling or optional visual personalization.

## Package publicly

1. Read `references/redskill-public-package.md`.
2. Remove private state, logs, paths, images, credentials, account names, and sensitive details.
3. Run `node scripts/package_public.js --output <empty-staging-directory>`.
4. Require `privacy-report.json` to report `publicSafe: true` and retain `SHA256SUMS.json`.
5. Validate and forward-test the staged skill before publishing.

Do not upload, overwrite an installed skill, or publish externally without explicit authorization.

## References

- `references/intake.md`: onboarding and Personal OOS Plan.
- `references/maintenance.md`: operation, state ops, and First Flight.
- `references/goal-model.md`: generic Track models.
- `references/visual-system.md`: fixed information architecture and theme rules.
- `references/persona-assets.md`: optional provider-neutral visual-soul workflow.
- `references/workbench-delivery.md`: prototype-to-workbench delivery gates, evidence, testing, and deployment boundaries.
- `references/redskill-public-package.md`: public boundary and demo loop.
