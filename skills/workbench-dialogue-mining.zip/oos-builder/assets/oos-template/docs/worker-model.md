# OOS Embedded Worker

The OOS Worker is a deterministic local queue processor. It is not a model, a hidden Agent, or a subagent.

## Responsibilities

For every HUD or Agent mutation, the Worker:

1. stores a versioned `state_ops_request`;
2. checks `expectedVersion`, the operation registry, locks, and risk rules;
3. serializes concurrent writes;
4. applies the reducer once;
5. validates the resulting state;
6. atomically replaces `data/state.json` with a backup;
7. rebuilds Current Truth and durable projections;
8. records a semantic receipt;
9. emits `state.changed` and `worker.changed`.

The queue therefore answers “did this state change safely happen?” It does not answer “what did the user mean?”

## Agent Review

Quick Capture commits the user's note immediately and creates a separate `capture.review` item. That item waits for an Agent to decide whether the capture should also update a task, milestone, memory, decision, or other canonical record.

This separation is deliberate:

- Worker execution is deterministic and retryable.
- Agent interpretation is contextual and may require a question.
- Both eventually write through the same State Ops boundary.

## Subagents

A subagent is an optional second reasoning process offered by some hosts. It can inspect or classify work, but it is not part of the OOS persistence contract. A subagent must never write `state.json` directly or create a parallel queue.

## Observability

Inspect the queue with:

```text
node scripts/oos-state.js worker-list
```

The HUD “后台同步” drawer shows:

- State Ops still waiting or executing;
- captures waiting for Agent judgment;
- operations needing user review;
- the most recent completed action and State version.

Queue statuses:

- `queued`, `processing`, `projection_pending`: Worker-owned execution;
- `pending` on `capture.review`: waiting for Agent judgment;
- `needs_review`: waiting for explicit user confirmation;
- `conflict`: prepared from an old State version;
- `failed`: deterministic execution exhausted its retries;
- `done`: State and projections committed.

