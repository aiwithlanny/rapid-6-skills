# OOS Automation Prompts

## Daily Light Maintenance

Read `data/state.json` and today's notes. Summarize:

- New updates to record.
- Tasks due soon or overdue.
- Goals whose risk changed.
- One next action for tomorrow.

## Weekly Review

Read `data/state.json`, `brain/Inbox/inbox.md`, and recent review notes. Produce:

- What moved this week.
- What stalled.
- Which goals need a plan change.
- Next week's day-level plan when enough information exists.

