# OOS Task Lifecycle

`data/state.json.tasks` is the only mutable task registry. Chat, HUD, Tracks, calendars, Current Truth, extensions, and Markdown history project it rather than maintaining another task status.

## Status Model

| Status | Meaning | Active views | Automatic time block |
| --- | --- | --- | --- |
| `open` | Executable now | Yes | Yes |
| `in_progress` | Currently being advanced | Yes | Yes |
| `waiting` | Waiting on another person or condition | No | No |
| `blocked` | Cannot proceed because of a blocker | No | No |
| `deferred` | Intentionally inactive until `wakeAt` | No | Reserved for wake date |
| `postponed` | Legacy deferred status | No | Reserved for wake date |
| `done` | Completed history | No | No |
| `cancelled` | Explicitly no longer required | No | No |
| `declined` | Opportunity or proposal rejected | No | No |
| `archived` | Historical record only | No | No |

## Date Semantics

- `due`: real completion deadline.
- `wakeAt`: date when deferred work becomes active.
- `reviewAt`: one-time reconsideration date.
- `reviewEveryDays`: recurring reconsideration cadence.
- `lastPromptedAt`: last proactive Agent prompt; not progress.
- `lastProgressAt`: last confirmed real movement.
- `scheduleBlock.startAt/endAt`: actual planned execution time.

Every long-running commitment needs a deadline, wake date, or review cadence. Moving a time block never silently moves the deadline.

## Deterministic Maintenance

The embedded Worker runs lifecycle maintenance after transactions, at service startup, and once per local calendar day. It:

- archives closed tasks out of active views;
- cancels remaining active blocks linked to closed tasks;
- resolves explicitly task-linked questions and milestones;
- wakes deferred tasks whose `wakeAt` arrived;
- blocks unresolved dependencies and activates downstream work after prerequisites complete;
- closes unfinished descendants linked by `parentTaskId` when their parent closes;
- archives tasks explicitly superseded by a newer task.

## Completion

- `schedule.complete` completes one execution and preserves the linked task.
- `task.complete` closes the whole canonical task. `triggeringBlockId` identifies the execution that completed it; other future blocks are reconciled in the same version.
- `task.reopen` creates a new active execution path and never revives historical blocks.
- Cascades require explicit IDs. Similar names and shared Track membership are not relationships.

## Reliability

- Overdue work stays visible until an explicit decision closes or reschedules it.
- Parent-child links define cleanup scope; dependency links define execution order.
- History is archived, not deleted.
- Completion time is never invented.
- Semantic receipts let Agents understand HUD mutations through `/api/changes`.

