#!/usr/bin/env node
"use strict";

const fs = require("fs/promises");
const path = require("path");
const crypto = require("crypto");
const {
  workspaceInstanceId,
  readJson,
  mutateStateFile,
  readWorkerQueue,
  workerQueueStats,
  enqueueWorkerItem,
  resolveWorkerItem
} = require("../lib/oos-store");
const { helpJson } = require("../lib/oos-operations");
const { stateMeta } = require("../lib/oos-state");
const { createUnifiedRuntime } = require("../lib/unified-runtime");
const { conversationAttentionSummary } = require("../lib/task-lifecycle");

const ROOT = path.resolve(__dirname, "..");
const STATE_FILE = process.env.OOS_STATE_FILE ? path.resolve(process.env.OOS_STATE_FILE) : path.join(ROOT, "data", "state.json");
const QUEUE_FILE = process.env.OOS_WORKER_QUEUE_FILE ? path.resolve(process.env.OOS_WORKER_QUEUE_FILE) : path.join(ROOT, "data", "worker-queue.json");
const BRAIN_DIR = process.env.OOS_BRAIN_DIR ? path.resolve(process.env.OOS_BRAIN_DIR) : path.join(ROOT, "brain");
const CURRENT_TRUTH = path.join(BRAIN_DIR, "Current", "current-truth.md");
const CURSOR_FILE = path.join(path.dirname(STATE_FILE), ".runtime-cache", "change-cursors.json");
const API_BASE = process.env.OOS_URL || `http://127.0.0.1:${Number(process.env.PORT || 4174)}`;
const INSTANCE_ID = workspaceInstanceId(ROOT);
const localRuntime = createUnifiedRuntime({ root: ROOT, stateFile: STATE_FILE, queueFile: QUEUE_FILE, currentTruthFile: CURRENT_TRUTH, cursorFile: CURSOR_FILE });

function mutationId(prefix = "agent") {
  return `${prefix}-${Date.now()}-${crypto.randomBytes(6).toString("hex")}`;
}

function parseArgs(argv) {
  const result = { _: [] };
  for (let index = 0; index < argv.length; index += 1) {
    const token = argv[index];
    if (!token.startsWith("--")) result._.push(token);
    else {
      const key = token.slice(2);
      if (argv[index + 1] && !argv[index + 1].startsWith("--")) result[key] = argv[++index];
      else result[key] = true;
    }
  }
  return result;
}

function output(value) {
  process.stdout.write(`${JSON.stringify(value, null, 2)}\n`);
}

function transportFields(response) {
  const fields = { transport: response.transport };
  if (response.fallbackReason) {
    fields.fallbackReason = response.fallbackReason;
    fields.fallbackMessage = response.fallbackReason === "wrong_oos_instance"
      ? "A different OOS workspace is using the default HUD address; this command safely used the current workspace's locked local Runtime."
      : "The HUD API was unavailable, so this command safely used the current workspace's locked local Runtime.";
  }
  return fields;
}

function fail(error) {
  output({ ok: false, code: error.code || "oos_state_error", message: error.message, version: error.version, skipped: error.skipped });
  process.exitCode = error.status === 409 ? 4 : 1;
}

async function api(pathname, options = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 650);
  try {
    const response = await fetch(`${API_BASE}${pathname}`, {
      ...options,
      signal: controller.signal,
      headers: { "Content-Type": "application/json", ...(options.headers || {}) }
    });
    const body = await response.json();
    if (!response.ok) {
      const error = new Error(body.message || body.code || `HTTP ${response.status}`);
      Object.assign(error, body, { status: response.status });
      throw error;
    }
    return body;
  } finally { clearTimeout(timer); }
}

async function withApiFallback(pathname, options, fallback, offline) {
  let fallbackReason = offline ? "offline_requested" : "";
  if (!offline) {
    try {
      const meta = await api("/api/state-meta");
      if (meta.runtime?.instanceId !== INSTANCE_ID) {
        const error = new Error(`HUD server belongs to another OOS workspace: ${API_BASE}`);
        error.code = "wrong_oos_instance";
        throw error;
      }
      return { transport: "http", result: pathname === "/api/state-meta" ? meta : await api(pathname, options) };
    }
    catch (error) {
      const reason = error.cause?.code || error.code || error.name;
      if (!["ECONNREFUSED", "UND_ERR_CONNECT_TIMEOUT", "AbortError", "wrong_oos_instance"].includes(reason)) throw error;
      fallbackReason = reason;
    }
  }
  return { transport: "local", fallbackReason, result: await fallback() };
}

async function jsonInput(args) {
  if (args.file) return JSON.parse((await fs.readFile(path.resolve(args.file), "utf8")).replace(/^\uFEFF/, ""));
  if (args.json) return JSON.parse(String(args.json));
  throw Object.assign(new Error("Use --file <json-file> or --json <json>."), { code: "missing_input" });
}

async function currentMeta() {
  const state = await readJson(STATE_FILE);
  const queue = await readWorkerQueue(QUEUE_FILE);
  const meta = stateMeta(state, {});
  return { ...meta, maintenanceQueue: { ...meta.maintenanceQueue, ...workerQueueStats(queue) } };
}

async function localSubmit(input) {
  const result = await localRuntime.submit(input);
  if (result.status === "conflict") throw Object.assign(new Error("State changed after this operation was prepared."), { code: "state_conflict", status: 409, version: result.state?.meta?.version });
  if (result.status !== "done") throw Object.assign(new Error("State operation was not committed."), { code: result.reviewReason || result.status || "state_ops_rejected", status: 422 });
  const receipt = result.state?.receipts?.find((item) => item.id === result.receiptId) || null;
  return { ...result, receipt };
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  const command = args._[0] || "help";
  const offline = args.offline === true;
  if (command === "help") {
    output({
      usage: [
        "node scripts/oos-state.js meta",
        "node scripts/oos-state.js get",
        "node scripts/oos-state.js attention [--limit 1] [--related-goal <track-id>]",
        "node scripts/oos-state.js ops",
        "node scripts/oos-state.js op --expected-version <n> --file <ops.json>",
        "node scripts/oos-state.js capture --expected-version <n> --file <capture.txt>",
        "node scripts/oos-state.js changes --consumer <id> [--ack current|<version>]",
        "node scripts/oos-state.js worker-list",
        "node scripts/oos-state.js worker-resolve <id> [--note text]"
      ],
      note: "op files may be a direct operation array or an envelope with an ops/operations array. HTTP is used when the HUD server is available; --offline uses the same locked atomic State Runtime locally."
    });
    return;
  }
  if (command === "ops") return output({ ok: true, operations: helpJson() });
  if (command === "meta") {
    const response = await withApiFallback("/api/state-meta", {}, currentMeta, offline);
    return output({ ok: true, ...transportFields(response), ...response.result });
  }
  if (command === "get") {
    const response = await withApiFallback("/api/state", {}, () => readJson(STATE_FILE), offline);
    return output({ ok: true, ...transportFields(response), state: response.result });
  }
  if (command === "attention") {
    const limit = Math.max(1, Math.min(5, Number(args.limit) || 1));
    const relatedGoal = String(args["related-goal"] || "").trim();
    const query = new URLSearchParams({ limit: String(limit) });
    if (relatedGoal) query.set("relatedGoal", relatedGoal);
    const response = await withApiFallback(`/api/conversation-attention?${query}`, {}, async () => {
      const current = await localRuntime.stateWithMeta();
      return { version: current.meta?.version, ...conversationAttentionSummary(current, { limit, relatedGoal }) };
    }, offline);
    return output({ ok: true, ...transportFields(response), ...response.result, attention: response.result });
  }
  if (command === "op") {
    const raw = await jsonInput(args);
    const envelopeOps = Array.isArray(raw?.ops) ? raw.ops : Array.isArray(raw?.operations) ? raw.operations : null;
    const ops = Array.isArray(raw) ? raw : envelopeOps || (raw?.type ? [raw] : []);
    if (!ops.length) throw Object.assign(new Error("Operation input must be a direct array, a single operation with type, or an envelope with ops/operations."), { code: "invalid_ops_payload", status: 400 });
    const expectedVersion = Number(args["expected-version"] ?? raw.expectedVersion);
    if (!Number.isInteger(expectedVersion)) throw Object.assign(new Error("--expected-version must be an integer from the latest meta read."), { code: "expected_version_required", status: 428 });
    const clientMutationId = String(args["client-mutation-id"] || raw.clientMutationId || mutationId("agent-op"));
    const input = {
      expectedVersion,
      clientMutationId,
      source: "agent",
      summary: String(raw.summary || `Agent applied ${ops.length} operation(s).`),
      humanMeaning: String(raw.humanMeaning || "").trim() || undefined,
      followUp: raw.followUp && typeof raw.followUp === "object" ? raw.followUp : undefined,
      relatedGoal: String(raw.relatedGoal || "").trim() || undefined,
      confirmedMajor: raw.confirmedMajor === true,
      autoSchedule: raw.autoSchedule !== false,
      ops
    };
    const response = await withApiFallback("/api/state-ops", { method: "POST", body: JSON.stringify(input) }, () => localSubmit(input), offline);
    return output({ ok: true, ...transportFields(response), ...response.result });
  }
  if (command === "capture") {
    const expectedVersion = Number(args["expected-version"]);
    if (!Number.isInteger(expectedVersion)) throw Object.assign(new Error("--expected-version must be an integer from the latest meta read."), { code: "expected_version_required", status: 428 });
    const text = args.file ? (await fs.readFile(path.resolve(args.file), "utf8")).trim() : String(args.text || "").trim();
    if (!text) throw Object.assign(new Error("Capture text is empty."), { code: "invalid_capture" });
    const clientMutationId = String(args["client-mutation-id"] || mutationId("agent-capture"));
    const response = await withApiFallback("/api/capture", { method: "POST", body: JSON.stringify({ expectedVersion, clientMutationId, source: "agent", text }) }, async () => {
      const mutation = await localSubmit({ expectedVersion, clientMutationId, source: "agent", summary: text, relatedGoal: "inbox", ops: [{ type: "activity.add", text, relatedGoal: "inbox" }] });
      const queued = await enqueueWorkerItem(QUEUE_FILE, { type: "capture.review", source: "agent", sourceText: text, relatedGoal: "inbox" });
      return { ...mutation, worker: { queued: queued.result, stats: workerQueueStats(queued.queue) } };
    }, offline);
    return output({ ok: true, ...transportFields(response), ...response.result });
  }
  if (command === "worker-list") {
    const response = await withApiFallback("/api/worker", {}, async () => {
      const queue = await readWorkerQueue(QUEUE_FILE);
      return { items: queue.items, stats: workerQueueStats(queue) };
    }, offline);
    return output({ ok: true, ...transportFields(response), ...response.result });
  }
  if (command === "worker-resolve") {
    const id = String(args._[1] || "");
    if (!id) throw Object.assign(new Error("worker-resolve requires an item id."), { code: "missing_worker_id" });
    const resolution = { status: args.dismiss ? "dismissed" : "done", note: String(args.note || ""), receiptId: String(args.receipt || "") };
    const response = await withApiFallback(`/api/worker/${encodeURIComponent(id)}/resolve`, { method: "POST", body: JSON.stringify(resolution) }, async () => {
      const resolved = await resolveWorkerItem(QUEUE_FILE, id, resolution);
      return { item: resolved.result, stats: workerQueueStats(resolved.queue) };
    }, offline);
    return output({ ok: true, ...transportFields(response), ...response.result });
  }
  if (command === "changes") {
    const consumer = String(args.consumer || "").trim();
    const sinceVersion = Number(args["since-version"] ?? 0);
    if (!consumer && !Number.isInteger(sinceVersion)) throw Object.assign(new Error("--since-version must be an integer."), { code: "invalid_cursor_version" });
    const pathname = consumer ? `/api/changes?consumer=${encodeURIComponent(consumer)}` : `/api/changes?sinceVersion=${encodeURIComponent(sinceVersion)}`;
    const response = await withApiFallback(pathname, {}, () => consumer ? localRuntime.changesForConsumer(consumer) : localRuntime.changesSince(sinceVersion), offline);
    const result = response.result;
    if (args.ack !== undefined) {
      if (!consumer) throw Object.assign(new Error("--ack requires --consumer."), { code: "invalid_consumer" });
      const version = args.ack === true || args.ack === "current" ? result.currentVersion : Number(args.ack);
      if (!Number.isInteger(version)) throw Object.assign(new Error("--ack must be an integer or current."), { code: "invalid_cursor_version" });
      result.acknowledgement = response.transport === "http"
        ? await api("/api/changes/ack", { method: "POST", body: JSON.stringify({ consumer, version }) })
        : await localRuntime.acknowledgeChanges(consumer, version);
    }
    return output({ ok: true, ...transportFields(response), ...result });
  }
  throw Object.assign(new Error(`Unknown command: ${command}`), { code: "unknown_command" });
}

main().catch(fail);
