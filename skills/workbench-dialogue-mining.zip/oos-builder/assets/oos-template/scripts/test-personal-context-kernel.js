"use strict";

const assert = require("assert");
const fs = require("fs");
const path = require("path");
const { ensureStateShape, applyStateOps, validateState } = require("../lib/oos-state-model");
const { deriveStateProjection } = require("../lib/oos-derived");

let state = ensureStateShape({
  meta: { version: 20, timezone: "Asia/Shanghai" },
  goals: [{ id: "studio", name: "Studio", trackType: "project" }],
  tracks: [{ id: "studio", name: "Studio", archetype: "project", role: "primary" }],
  tasks: [], scheduleBlocks: [], questions: [], notes: [], inbox: [], activity: []
});

function transact(op) {
  const before = state.meta.version;
  const result = applyStateOps(state, [op]);
  assert.equal(result.ok, true, JSON.stringify(result.skipped));
  if (result.applied.length) assert.equal(result.state.meta.version, before + 1, "one context transaction must create one version");
  else assert.equal(result.state.meta.version, before, "idempotent context transaction must not create a version");
  state = result.state;
  return result;
}

const pattern = {
  type: "memory.observe",
  memory: {
    key: "best-focus-window",
    type: "pattern",
    statement: "Deep work is easier before lunch.",
    sensitivity: "ordinary"
  }
};

transact({ ...pattern, memory: { ...pattern.memory, observedAt: "2026-07-17T09:00:00+08:00", evidence: { id: "focus-evidence-1", source: "chat", statement: "Focused well at 09:00." } } });
transact({ ...pattern, memory: { ...pattern.memory, observedAt: "2026-07-17T10:00:00+08:00", evidence: { id: "focus-evidence-2", source: "execution", statement: "Finished another morning block." } } });
let memory = state.context.memories.find((item) => item.key === "best-focus-window");
assert.equal(memory.status, "candidate");
assert.equal(memory.advicePolicy, "question_only", "two observations may only support a question");

transact({ ...pattern, memory: { ...pattern.memory, observedAt: "2026-07-18T09:30:00+08:00", evidence: { id: "focus-evidence-3", source: "execution", statement: "A second-day morning session went well." } } });
memory = state.context.memories.find((item) => item.key === "best-focus-window");
assert.equal(memory.status, "active");
assert.equal(memory.confidence, 0.75);
assert.equal(new Set(memory.evidence.map((item) => item.date)).size, 2);

const duplicate = transact({ ...pattern, memory: { ...pattern.memory, observedAt: "2026-07-18T09:30:00+08:00", evidence: { id: "focus-evidence-3", source: "execution", statement: "A second-day morning session went well." } } });
assert(duplicate.skipped.some((item) => item.idempotent), "duplicate evidence must be idempotent");

transact({ ...pattern, memory: { ...pattern.memory, observedAt: "2026-07-18T15:00:00+08:00", evidence: { id: "focus-contradiction-1", source: "chat", polarity: "contradict", statement: "Today the morning was unusually difficult." } } });
memory = state.context.memories.find((item) => item.key === "best-focus-window");
assert.equal(memory.status, "disputed");
assert.equal(memory.advicePolicy, "question_only");

const oldMemoryId = memory.id;
transact({
  type: "memory.correct",
  targetId: oldMemoryId,
  memory: {
    key: "best-focus-window",
    type: "preference",
    statement: "Protect a quiet 10:00–12:00 focus window when possible.",
    observedAt: "2026-07-18T16:00:00+08:00",
    source: "user_correction"
  }
});
assert.equal(state.context.memories.find((item) => item.id === oldMemoryId).status, "superseded");
const corrected = state.context.memories.find((item) => item.supersedesId === oldMemoryId);
assert.equal(corrected.status, "active");
assert.equal(corrected.confidence, 1);

transact({ type: "memory.forget", targetId: corrected.id, forgottenAt: "2026-07-18T16:05:00+08:00" });
const tombstone = state.context.memories.find((item) => item.id === corrected.id);
assert.deepStrictEqual(Object.keys(tombstone).sort(), ["forgottenAt", "id", "keyHash", "reasonCode", "status"].sort());
const blockedRelearn = transact({
  type: "memory.observe",
  memory: { key: "best-focus-window", type: "preference", statement: "Protect mornings.", explicit: true, observedAt: "2026-07-18T17:00:00+08:00" }
});
assert(blockedRelearn.skipped.some((item) => item.idempotent), "forgotten content must not be silently learned again");
transact({
  type: "memory.observe",
  allowRelearn: true,
  memory: { key: "best-focus-window", type: "preference", statement: "Protect mornings.", explicit: true, observedAt: "2026-07-18T17:05:00+08:00" }
});
assert(state.context.memories.some((item) => item.key === "best-focus-window" && item.status === "active" && item.id !== corrected.id));

transact({
  type: "memory.observe",
  memory: {
    id: "memory-public-alias-contract",
    key: "review-style",
    kind: "preference",
    statement: "Show a usable version before polishing it.",
    explicit: true,
    observedAt: "2026-07-18T18:00:00+08:00",
    relatedTrackIds: ["studio"],
    evidence: [{ id: "alias-evidence-1", source: "chat", text: "The user stated this preference explicitly." }]
  }
});
const aliasMemory = state.context.memories.find((item) => item.id === "memory-public-alias-contract");
assert.equal(aliasMemory.type, "preference");
assert.deepStrictEqual(aliasMemory.relatedTrackIds, ["studio"]);
assert.equal(aliasMemory.evidence[0].statement, "The user stated this preference explicitly.");

transact({
  type: "memory.observe",
  memory: {
    key: "batch-evidence-contract",
    type: "pattern",
    statement: "Batch evidence preserves each observation date.",
    evidence: [
      { id: "batch-evidence-1", observedAt: "2026-07-17T09:00:00+08:00", source: "chat", text: "First day." },
      { id: "batch-evidence-2", observedAt: "2026-07-18T09:00:00+08:00", source: "chat", text: "Second day." },
      { id: "batch-evidence-3", observedAt: "2026-07-18T10:00:00+08:00", source: "review", text: "Second-day confirmation." }
    ]
  }
});
const batchMemory = state.context.memories.find((item) => item.key === "batch-evidence-contract");
assert.equal(batchMemory.status, "active");
assert.equal(new Set(batchMemory.evidence.map((item) => item.date)).size, 2);

for (const [index, observedAt] of ["2026-07-17T22:00:00+08:00", "2026-07-18T07:00:00+08:00", "2026-07-18T22:00:00+08:00"].entries()) {
  transact({
    type: "memory.observe",
    memory: {
      key: "sleep-energy-pattern",
      type: "pattern",
      statement: "Short sleep is followed by lower energy.",
      sensitivity: "health",
      observedAt,
      evidence: { id: `sleep-evidence-${index + 1}`, source: "chat", statement: `Observation ${index + 1}` }
    }
  });
}
const sensitive = state.context.memories.find((item) => item.key === "sleep-energy-pattern");
assert.equal(sensitive.status, "active");
assert.equal(sensitive.advicePolicy, "disclose_and_corroborate", "sensitive inference cannot be the sole hidden basis for high-impact advice");

transact({
  type: "decision.record",
  decision: {
    id: "decision-studio-offer",
    title: "Choose the studio offer",
    options: ["Retail package", "Residential package"],
    choice: "Retail package",
    rationale: "Shorter sales cycle and clearer evidence.",
    constraints: ["No client names in HUD"],
    relatedTrackIds: ["studio"],
    memoryIds: [sensitive.id],
    decidedAt: "2026-07-17T12:00:00+08:00",
    reviewAt: "2026-07-18"
  }
});
let projection = deriveStateProjection(state, new Date("2026-07-18T12:00:00+08:00"));
assert.equal(state.decisions.find((item) => item.id === "decision-studio-offer").relatedGoal, "studio");
assert.deepStrictEqual(state.decisions.find((item) => item.id === "decision-studio-offer").relatedTrackIds, ["studio"]);
assert(projection.__derived.attention.items.some((item) => item.entityId === "decision-studio-offer" && item.reason === "decision_review_due"));
assert(projection.__derived.context.decisions.active.includes("decision-studio-offer"));

transact({
  type: "decision.review",
  targetId: "decision-studio-offer",
  review: { id: "decision-review-1", reviewedAt: "2026-07-18T12:30:00+08:00", summary: "Still valid.", nextReviewAt: "2026-08-18" }
});
projection = deriveStateProjection(state, new Date("2026-07-18T13:00:00+08:00"));
assert(!projection.__derived.attention.items.some((item) => item.entityId === "decision-studio-offer"));

transact({
  type: "decision.outcome",
  targetId: "decision-studio-offer",
  outcome: { summary: "The retail package converted.", result: "won", learned: "Keep the qualification checklist.", recordedAt: "2026-08-12T12:00:00+08:00" }
});
assert.equal(state.decisions.find((item) => item.id === "decision-studio-offer").status, "closed");
assert.equal(validateState(state).valid, true);
const hudSource = fs.readFileSync(path.join(__dirname, "..", "public", "app.js"), "utf8");
assert.match(hudSource, /state\.__derived\?\.attention\?\.items/, "Today risk signals must consume canonical derived Attention");

console.log("Personal context and decision kernel tests passed.");
