#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");
const { markdown } = require("../lib/oos-operations");

const file = path.join(__dirname, "..", "AGENTS.md");
const source = fs.readFileSync(file, "utf8");
const eol = source.includes("\r\n") ? "\r\n" : "\n";
const generated = markdown().replace(/\n/g, eol);
const next = source.replace(/<!-- OOS_OPERATION_REGISTRY_START -->[\s\S]*?<!-- OOS_OPERATION_REGISTRY_END -->/, generated);
if (next === source && !source.includes(generated)) throw new Error("AGENTS.md operation registry markers are missing.");
if (process.argv.includes("--write")) {
  fs.writeFileSync(file, next, "utf8");
  process.stdout.write("AGENTS.md operation registry synchronized.\n");
} else if (source !== next) {
  process.stderr.write("AGENTS.md operation registry is stale. Run sync-operation-registry.js --write.\n");
  process.exitCode = 1;
} else process.stdout.write("AGENTS.md operation registry is current.\n");
