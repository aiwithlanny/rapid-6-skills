const fs = require("fs");
const path = require("path");

const root = path.resolve(__dirname, "..");
const files = [
  "data/state.json",
  "server.js",
  "public/app.js",
  "public/index.html"
];

const suspiciousMojibake = [
  "\u9225", "\u951b", "\u9286", "\u942d", "\u9350", "\u7481", "\u6d63",
  "\u7efe", "\u5bf0", "\u7441", "\u935f", "\u9351", "\u93af", "\u93c6",
  "\u95c7", "\u6942", "\u95b3", "\u95bf", "\u95b5", "\u95bb", "\u9420",
  "\u5a34", "\u7f01", "\u7035", "\u941f", "\u9352", "\u6d93", "\u6d60",
  "\u7459"
].join("|");
const badPattern = new RegExp(String.raw`\?{3,}|\uFFFD|${suspiciousMojibake}`);
const allowedQuestionPattern = /^https?:\/\/|^\?.*=|^\?$/;

function walkJson(value, location, hits) {
  if (typeof value === "string") {
    if (badPattern.test(value) && !allowedQuestionPattern.test(value)) {
      hits.push({ location, value });
    }
    return;
  }
  if (Array.isArray(value)) {
    value.forEach((item, index) => walkJson(item, `${location}[${index}]`, hits));
    return;
  }
  if (value && typeof value === "object") {
    Object.entries(value).forEach(([key, item]) => walkJson(item, `${location}.${key}`, hits));
  }
}

function scanText(file, text, hits) {
  const lines = text.split(/\r?\n/);
  lines.forEach((line, index) => {
    if (badPattern.test(line)) {
      hits.push({ location: `${file}:${index + 1}`, value: line.trim().slice(0, 180) });
    }
  });
}

const hits = [];

for (const relative of files) {
  const file = path.join(root, relative);
  if (!fs.existsSync(file)) continue;
  const text = fs.readFileSync(file, "utf8");
  if (relative.endsWith(".json")) {
    walkJson(JSON.parse(text), relative, hits);
  } else {
    scanText(relative, text, hits);
  }
}

if (hits.length) {
  console.error("Mojibake guard failed. Fix these HUD-facing strings:");
  for (const hit of hits.slice(0, 80)) {
    console.error(`- ${hit.location}: ${hit.value}`);
  }
  if (hits.length > 80) console.error(`...and ${hits.length - 80} more.`);
  process.exit(1);
}

console.log("Mojibake guard passed.");
