"use strict";

const assert = require("node:assert/strict");
const Calendar = require("../public/calendar-engine.js");

function segment(id, start, end) {
  return { id, blockId: id, start, end, block: { id } };
}

assert.equal(Calendar.snapMinute(67, 15), 60, "67 minutes snaps to 60");
assert.equal(Calendar.snapMinute(68, 15), 75, "68 minutes snaps to 75");
assert.equal(Calendar.weekStart("2026-07-18"), "2026-07-13", "week starts on Monday");
assert.equal(Calendar.addMonths("2026-12-18", 1), "2027-01-01", "month navigation crosses year");

const overnight = { id: "overnight", startAt: "2026-07-18T23:30:00", endAt: "2026-07-19T01:15:00" };
const overnightSegments = Calendar.blockSegments(overnight, ["2026-07-18", "2026-07-19"]);
assert.deepEqual(overnightSegments.map((item) => [item.date, item.start, item.end, item.isStart, item.isEnd]), [
  ["2026-07-18", 1410, 1440, true, false],
  ["2026-07-19", 0, 75, false, true]
], "cross-midnight block is clipped into adjacent dates");

const two = Calendar.layoutDaySegments([segment("a", 540, 660), segment("b", 600, 720)]);
assert.deepEqual(two.map((item) => [item.blockId, item.lane, item.laneCount]), [["a", 0, 2], ["b", 1, 2]], "two overlaps use two lanes");

const three = Calendar.layoutDaySegments([segment("a", 540, 720), segment("b", 570, 630), segment("c", 600, 690)]);
assert.equal(Math.max(...three.map((item) => item.laneCount)), 3, "nested three-way overlap uses three lanes");
assert.equal(new Set(three.map((item) => item.lane)).size, 3, "each nested overlap remains selectable");

const partial = Calendar.layoutDaySegments([segment("a", 540, 600), segment("b", 570, 630), segment("c", 620, 690)]);
assert.equal(Math.max(...partial.map((item) => item.laneCount)), 2, "partial overlap reuses a free lane");

const touching = Calendar.layoutDaySegments([segment("a", 540, 600), segment("b", 600, 660)]);
assert.deepEqual(touching.map((item) => item.laneCount), [1, 1], "end-to-start blocks do not conflict");

const blocks = [
  { id: "scheduled", taskId: "task-1", startAt: "2026-07-18T09:00:00", endAt: "2026-07-18T10:00:00", status: "planned" }
];
const tasks = [
  { id: "task-1", title: "Already scheduled", due: "2026-07-18", status: "open" },
  { id: "task-2", title: "Due only", due: "2026-07-19", status: "open" }
];
assert.deepEqual(Calendar.dueItems(tasks, blocks, "2026-07-18", "2026-07-20").map((item) => item.taskId), ["task-2"], "scheduled tasks are removed from all-day due strip");

const allStatuses = Calendar.activeCalendarBlocks([
  { id: "planned", startAt: "2026-07-18T09:00:00", status: "planned" },
  { id: "completed", startAt: "2026-07-18T10:00:00", status: "completed" },
  { id: "cancelled", startAt: "2026-07-18T11:00:00", status: "cancelled" },
  { id: "archived", startAt: "2026-07-18T12:00:00", status: "archived" }
]);
assert.deepEqual(allStatuses.map((item) => item.id), ["planned", "completed", "cancelled"], "default calendar keeps every non-archived status visible");

const occupiedMorning = [
  { id: "fixed", startAt: "2026-07-21T10:00:00", endAt: "2026-07-21T11:00:00", status: "planned", kind: "fixed", locked: true },
  { id: "focus", startAt: "2026-07-21T11:00:00", endAt: "2026-07-21T12:30:00", status: "planned" }
];
assert.equal(Calendar.firstFreeMinute(occupiedMorning, "2026-07-21", 60, 600, 15), 750, "date drop chooses the first 15-minute-aligned free slot after occupied blocks");
assert.equal(Calendar.firstFreeMinute([], "2026-07-21", 60, 607, 15), 600, "preferred date-drop time snaps to 15 minutes");
assert.equal(Calendar.firstFreeMinute([{ id: "cancelled", startAt: "2026-07-21T10:00:00", endAt: "2026-07-21T23:00:00", status: "cancelled" }], "2026-07-21", 60, 600, 15), 600, "cancelled blocks do not reserve calendar space");

console.log("calendar engine tests passed");
