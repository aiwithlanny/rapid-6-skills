"use strict";

const assert = require("assert");
const { staleStartupQuestions } = require("../lib/startup-freshness");

const state = {
  meta: { lastUpdated: "2026-07-23T08:00:00+08:00" },
  questions: [
    { id: "fresh", date: "2026-07-22" },
    { id: "stale", date: "2026-07-18" },
    { id: "undated", date: "" }
  ]
};
const issues = staleStartupQuestions(state);
assert.deepEqual(issues.map((item) => item.id).sort(), ["stale", "undated"]);
assert.equal(issues.find((item) => item.id === "stale").ageDays, 5);

process.stdout.write("Startup freshness checks passed.\n");

