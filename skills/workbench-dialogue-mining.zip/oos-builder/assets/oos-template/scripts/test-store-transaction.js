"use strict";

const assert = require("assert");
const fs = require("fs/promises");
const os = require("os");
const path = require("path");
const { mutateStateAndEnqueue, readWorkerQueue } = require("../lib/oos-store");

async function main() {
  const temp = await fs.mkdtemp(path.join(os.tmpdir(), "oos-store-transaction-"));
  const stateFile = path.join(temp, "state.json");
  const queueFile = path.join(temp, "worker-queue.json");
  try {
    await fs.copyFile(path.join(__dirname, "..", "data", "state.json"), stateFile);
    await fs.copyFile(path.join(__dirname, "..", "data", "worker-queue.json"), queueFile);
    const before = JSON.parse(await fs.readFile(stateFile, "utf8"));
    const beforeQueue = await readWorkerQueue(queueFile);

    await fs.writeFile(`${queueFile}.lock`, JSON.stringify({ test: true }), "utf8");
    await assert.rejects(
      mutateStateAndEnqueue({
        stateFile,
        queueFile,
        expectedVersion: before.meta.version,
        source: "test",
        ops: [{ type: "activity.add", text: "must not half-commit", relatedGoal: "system" }],
        worker: { sourceText: "must not half-commit" },
        lock: { timeoutMs: 250, staleMs: 30000 }
      }),
      (error) => error.code === "state_locked"
    );
    const afterLockFailure = JSON.parse(await fs.readFile(stateFile, "utf8"));
    assert.equal(afterLockFailure.meta.version, before.meta.version, "queue lock failure must not advance state");
    assert(!afterLockFailure.activity.some((item) => item.text === "must not half-commit"));

    await fs.unlink(`${queueFile}.lock`);
    const committed = await mutateStateAndEnqueue({
      stateFile,
      queueFile,
      expectedVersion: before.meta.version,
      source: "test",
      ops: [{ type: "activity.add", text: "combined commit", relatedGoal: "system" }],
      worker: { sourceText: "combined commit", source: "test" }
    });
    const queue = await readWorkerQueue(queueFile);
    assert.equal(committed.state.meta.version, before.meta.version + 1);
    assert.equal(queue.items.length, beforeQueue.items.length + 1);
    assert.equal(queue.items.at(-1).sourceText, "combined commit");
    assert.equal(committed.queued.id, queue.items.at(-1).id);
    process.stdout.write("OOS State + Worker transaction tests passed.\n");
  } finally {
    await fs.rm(temp, { recursive: true, force: true });
  }
}

main().catch((error) => { console.error(error.stack || error.message); process.exitCode = 1; });
