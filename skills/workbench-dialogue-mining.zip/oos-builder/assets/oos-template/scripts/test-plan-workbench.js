"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");

global.OOSCalendar = require("../public/calendar-engine.js");
global.document = { addEventListener() {}, elementsFromPoint() { return []; } };
global.requestAnimationFrame = (callback) => callback();
const CalendarUI = require("../public/calendar-ui.js");

const fixture = {
  tracks: [{ id: "content", name: "Content", navLabel: "内容" }],
  tasks: [
    { id: "scheduled-task", title: "已排脚本", goal: "content", status: "open" },
    { id: "unscheduled-task", title: "等待排期任务", goal: "content", status: "open", due: "2026-07-24" }
  ],
  scheduleBlocks: [
    { id: "movable-block", taskId: "scheduled-task", title: "已排脚本", goal: "content", startAt: "2026-07-21T10:00:00", endAt: "2026-07-21T11:00:00", status: "planned", kind: "focus" },
    { id: "fixed-block", title: "固定行程", goal: "content", startAt: "2026-07-22T15:00:00", endAt: "2026-07-22T16:00:00", status: "planned", kind: "fixed", locked: true }
  ]
};

const root = { innerHTML: "", querySelector() { return null; } };
const controller = CalendarUI.create({
  esc: (value) => String(value ?? "").replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;"),
  shortText: (value, length) => String(value || "").slice(0, length),
  getState: () => fixture,
  trackName: (id) => id === "content" ? "内容" : id,
  toast() {},
  today: () => "2026-07-21",
  renderHost() {},
  mutate: async () => {},
  openEditor() {}
});
controller.render(root);

assert.equal(controller.mode, "workbench", "Plan defaults to the unified workbench");
assert.match(root.innerHTML, /calendar-workbench-v3/, "workbench contract marker renders");
assert.match(root.innerHTML, /four-week-calendar/, "four-week overview renders");
assert.match(root.innerHTML, /selected-day-timeline/, "selected-day timeline renders in the same workspace");
assert.match(root.innerHTML, /calendar-backlog/, "unscheduled shelf remains visible beside the workspace");
assert.match(root.innerHTML, /data-calendar-date-drop="2026-07-22"/, "calendar dates accept cross-date drops");
assert.match(root.innerHTML, /data-calendar-month-block="movable-block"/, "scheduled blocks expose a cross-date drag handle");
assert.match(root.innerHTML, /data-calendar-stage="2026-07-21"/, "selected day exposes the precise timeline drop stage");
assert.doesNotMatch(root.innerHTML, /data-calendar-backlog-id="scheduled-task"/, "scheduled tasks are not duplicated in the unscheduled shelf");
assert.match(root.innerHTML, /data-calendar-backlog-id="unscheduled-task"/, "unscheduled tasks remain available for later placement");

const css = fs.readFileSync(path.join(__dirname, "..", "public", "calendar.css"), "utf8");
const uiSource = fs.readFileSync(path.join(__dirname, "..", "public", "calendar-ui.js"), "utf8");
const appSource = fs.readFileSync(path.join(__dirname, "..", "public", "app.js"), "utf8");
assert.match(uiSource, /beginMonthPointer/, "cross-date dragging has a pointer-events path for real mouse input");
assert.match(uiSource, /moveBlockToDate\(drag\.blockId, drag\.target\.dataset\.calendarDateDrop\)/, "pointer drop commits through schedule.update");
assert.match(appSource, /data-major-confirm/, "large schedule changes expose an explicit confirmation action");
assert.match(appSource, /confirmedMajor: options\.confirmedMajor === true/, "confirmed schedule changes are resubmitted through the canonical envelope");
assert.match(css, /\.plan-mode \.hero\s*\{\s*display:none;/, "Plan removes the presentation hero");
assert.match(css, /\.calendar-workbench-v2\s*\{[^}]*grid-template-columns:minmax\(720px,1fr\) 310px;/s, "desktop workbench keeps a stable right rail");
assert.match(css, /\.calendar-backlog\s*\{[^}]*position:sticky;[^}]*max-height:/s, "backlog is sticky and height-controlled");
assert.match(css, /\.calendar-block-body strong\s*\{\s*font-size:13px;/, "time-block titles remain readable");
assert.match(css, /\.week-ruler span\s*\{\s*font-size:11px;/, "timeline labels never fall below 11px");
assert.match(css, /\.calendar-modes button,[\s\S]*min-height:32px;/, "compact controls keep a 32px hit target");

console.log("plan workbench tests passed");
