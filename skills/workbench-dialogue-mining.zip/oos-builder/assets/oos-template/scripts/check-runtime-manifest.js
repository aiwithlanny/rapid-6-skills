#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const ROOT = path.resolve(__dirname, "..");
const MANIFEST_FILE = path.join(ROOT, "runtime-manifest.json");
const RUNTIME_VERSION = "oos-unified-v5.1";
const CORE_FILES = [
  "server.js",
  "AGENTS.md",
  "lib/unified-runtime.js",
  "lib/task-lifecycle.js",
  "lib/text-integrity.js",
  "lib/startup-freshness.js",
  "lib/oos-context-kernel.js",
  "lib/oos-derived.js",
  "lib/oos-operations.js",
  "scripts/oos-state.js",
  "public/app.js",
  "public/styles.css",
  "public/calendar.css",
  "public/calendar-engine.js",
  "public/calendar-ui.js",
  "public/oos-client.js"
];

function sha256(file) {
  const normalized = fs.readFileSync(file, "utf8").replace(/\r\n/g, "\n");
  return crypto.createHash("sha256").update(normalized, "utf8").digest("hex");
}

function currentManifest() {
  const files = {};
  for (const relative of CORE_FILES) {
    const file = path.join(ROOT, relative);
    if (!fs.existsSync(file)) throw new Error(`Runtime core file is missing: ${relative}`);
    files[relative.replaceAll("\\", "/")] = sha256(file);
  }
  const coreSha256 = crypto.createHash("sha256").update(JSON.stringify(files)).digest("hex");
  return { runtimeVersion: RUNTIME_VERSION, coreSha256, files };
}

const current = currentManifest();
if (process.argv.includes("--write")) {
  fs.writeFileSync(MANIFEST_FILE, `${JSON.stringify(current, null, 2)}\n`, "utf8");
  process.stdout.write(`Wrote ${path.relative(ROOT, MANIFEST_FILE)} (${current.coreSha256})\n`);
} else {
  const expected = JSON.parse(fs.readFileSync(MANIFEST_FILE, "utf8"));
  if (JSON.stringify(expected) !== JSON.stringify(current)) {
    process.stderr.write(`${JSON.stringify({ ok: false, expected, current }, null, 2)}\n`);
    process.exitCode = 1;
  } else process.stdout.write(`Runtime manifest clean: ${current.runtimeVersion} ${current.coreSha256}\n`);
}
