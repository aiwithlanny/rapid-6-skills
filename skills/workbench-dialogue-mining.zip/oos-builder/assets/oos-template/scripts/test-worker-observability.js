"use strict";

const assert = require("assert");
const fs = require("fs/promises");
const os = require("os");
const path = require("path");
const { createUnifiedRuntime, queueStats } = require("../lib/unified-runtime");

(async () => {
  const now = new Date().toISOString();
  const stats = queueStats({
    items: [
      { id: "done-1", type: "state_ops_request", status: "done", summary: "Committed task", stateVersionAfter: 3, updatedAt: now },
      { id: "op-1", type: "state_ops_request", status: "queued", summary: "Queued task", updatedAt: now },
      { id: "capture-1", type: "capture.review", status: "pending", sourceText: "A thought", updatedAt: now },
      { id: "review-1", type: "state_ops_request", status: "needs_review", summary: "Protected change", updatedAt: now }
    ]
  });
  assert.equal(stats.stateOpsPending, 1);
  assert.equal(stats.agentReviewPending, 1);
  assert.equal(stats.needsReview, 1);
  assert.equal(stats.status, "review");
  assert(stats.lastActivity?.id);

  const temp = await fs.mkdtemp(path.join(os.tmpdir(), "oos-worker-observable-"));
  const stateFile = path.join(temp, "state.json");
  const queueFile = path.join(temp, "worker-queue.json");
  const truthFile = path.join(temp, "current-truth.md");
  await fs.copyFile(path.join(__dirname, "..", "data", "state.json"), stateFile);
  await fs.writeFile(queueFile, JSON.stringify({ items: [] }), "utf8");
  const runtime = createUnifiedRuntime({ root: temp, stateFile, queueFile, currentTruthFile: truthFile, cursorFile: path.join(temp, "cursors.json") });

  const first = await runtime.enqueueAgentReview({
    clientMutationId: "worker-observability-capture",
    source: "test",
    sourceText: "Keep this exact thought",
    relatedGoal: "inbox"
  });
  const duplicate = await runtime.enqueueAgentReview({
    clientMutationId: "worker-observability-capture",
    source: "test",
    sourceText: "Keep this exact thought",
    relatedGoal: "inbox"
  });
  assert.equal(first.result.id, duplicate.result.id, "Agent-review enqueue must be idempotent");
  assert.equal(first.stats.agentReviewPending, 1);
  const resolved = await runtime.resolveAgentReview(first.result.id, { note: "Classified", receiptId: "receipt-test" });
  assert.equal(resolved.result.status, "done");
  assert.equal(resolved.stats.agentReviewPending, 0);

  await fs.rm(temp, { recursive: true, force: true });
  process.stdout.write("Worker observability checks passed.\n");
})().catch((error) => {
  process.stderr.write(`${error.stack || error.message}\n`);
  process.exitCode = 1;
});

