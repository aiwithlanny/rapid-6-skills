"use strict";

const state = require("../data/state.json");
const { validateState, deriveThemeTokens, deriveTrackViews, migrateState, stateMeta, applyStateOps, hasStateConflict } = require("../lib/oos-state");

const validation = validateState(state);
if (!validation.ok) {
  console.error(validation.errors.join("\n"));
  process.exit(1);
}
const task = state.tasks[0];
const simulation = task ? applyStateOps(state, [{ type: "task.complete", targetId: task.id }]) : { ok: true };
if (!simulation.ok) {
  console.error("State operation simulation failed.");
  process.exit(1);
}
const flight = applyStateOps(state, [
  { type: "onboarding.advance", step: 2 },
  { type: "onboarding.skip" },
  { type: "onboarding.resume" },
  { type: "onboarding.complete" }
]);
if (!flight.ok || flight.state.onboarding.firstFlight.status !== "completed" || flight.state.meta.readiness.firstFlight !== "completed") {
  console.error("First Flight state operation simulation failed.");
  process.exit(1);
}
const meta = stateMeta(state);
const tokens = deriveThemeTokens(state.meta.theme.accent);
if (!meta.readiness.operationalReady || meta.readiness.visualReady || tokens.accent !== state.meta.theme.accent) {
  console.error("Readiness or theme token derivation failed.");
  process.exit(1);
}
const archetypes = ["project", "habit", "pipeline", "learning", "relationship", "trend"];
const archetypeFixture = migrateState({
  meta: { schemaVersion: 3, version: 1, theme: { accent: "#111111" } },
  tracks: archetypes.map((archetype, index) => ({ id: `track-${archetype}`, name: archetype, navLabel: archetype, summary: archetype, archetype, role: index ? "supporting" : "primary", cadenceDays: 7, progress: 0 })),
  goals: [], tasks: [], scheduleBlocks: []
}).state;
const archetypeValidation = validateState(archetypeFixture);
const emptyViews = deriveTrackViews(archetypeFixture);
if (!archetypeValidation.ok || archetypes.some((archetype) => emptyViews[`track-${archetype}`]?.views?.length !== 1 || !emptyViews[`track-${archetype}`].views[0].empty)) {
  console.error("Archetype view contracts or empty visualization derivation failed.");
  process.exit(1);
}
const trendState = JSON.parse(JSON.stringify(archetypeFixture));
const metricOp = {
  type: "metric.record",
  trackId: "track-trend",
  viewId: "trend",
  metricKey: "value",
  entry: { value: 80.25, date: "2026-07-17", note: "User-provided check-in", unit: "", source: "chat" }
};
const recorded = applyStateOps(trendState, [metricOp]);
const derivedRecorded = recorded.ok ? deriveTrackViews(recorded.state)["track-trend"].views[0] : null;
if (!recorded.ok || recorded.state.logs.metrics.length !== 1 || derivedRecorded.empty || derivedRecorded.entries[0].value !== 80.25 || recorded.state.meta.version !== trendState.meta.version + 1) {
  console.error("Metric record or derived trend data failed.");
  process.exit(1);
}
const repeated = applyStateOps(recorded.state, [metricOp]);
if (!repeated.ok || repeated.applied.length || !repeated.skipped[0]?.idempotent || repeated.state.meta.version !== recorded.state.meta.version || repeated.state.logs.metrics.length !== 1) {
  console.error("Metric record idempotency failed.");
  process.exit(1);
}
const invalid = applyStateOps(trendState, [{ ...metricOp, entry: { ...metricOp.entry, value: "not-a-number" } }]);
if (invalid.ok || invalid.state.logs.metrics.length !== 0 || invalid.state.meta.version !== trendState.meta.version) {
  console.error("Invalid metric rejection failed.");
  process.exit(1);
}
if (!hasStateConflict(recorded.state, trendState.meta.version) || hasStateConflict(recorded.state, recorded.state.meta.version) || hasStateConflict(recorded.state, undefined)) {
  console.error("Expected-version conflict detection failed.");
  process.exit(1);
}
const fixedCreated = applyStateOps(trendState, [{ type: "schedule.create", block: { id: "fixed-test", title: "Fixed appointment", kind: "fixed", startAt: "2026-07-17T10:00:00", endAt: "2026-07-17T11:00:00", source: "system", locked: false } }]);
const fixedMove = fixedCreated.ok ? applyStateOps(fixedCreated.state, [{ type: "schedule.update", targetId: "fixed-test", patch: { startAt: "2026-07-17T12:00:00", endAt: "2026-07-17T13:00:00" } }]) : { ok: false };
const fixedComplete = fixedCreated.ok ? applyStateOps(fixedCreated.state, [{ type: "schedule.complete", targetId: "fixed-test" }]) : { ok: false };
if (!fixedCreated.ok || fixedCreated.state.scheduleBlocks[0]?.locked !== true || fixedMove.ok || fixedMove.state.scheduleBlocks[0]?.startAt !== "2026-07-17T10:00:00" || !fixedComplete.ok || fixedComplete.state.scheduleBlocks[0]?.status !== "completed") {
  console.error("Fixed schedule locking failed.");
  process.exit(1);
}
console.log("Schema v3 and state operation checks passed.");
