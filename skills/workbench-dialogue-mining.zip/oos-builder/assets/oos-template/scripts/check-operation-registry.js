"use strict";

const fs = require("fs");
const path = require("path");
const { markdown, OPERATIONS } = require("../lib/oos-operations");

const agents = fs.readFileSync(path.join(__dirname, "..", "AGENTS.md"), "utf8").replace(/\r\n/g, "\n");
if (!agents.includes(markdown().replace(/\r\n/g, "\n"))) {
  console.error("AGENTS.md operation table is not synchronized with lib/oos-operations.js.");
  process.exit(1);
}
for (const required of ["task.create", "task.complete", "schedule.complete", "memory.observe", "memory.correct", "memory.forget", "decision.record", "decision.review", "decision.outcome"]) {
  if (OPERATIONS.some((operation) => operation.type === required)) continue;
  console.error(`Operation registry is missing ${required}.`);
  process.exit(1);
}
const reducer = fs.readFileSync(path.join(__dirname, "..", "lib", "oos-state.js"), "utf8");
if (!reducer.includes('require("./oos-operations")') || !reducer.includes("isSupportedOperation(op?.type)")) {
  console.error("Reducer is not guarded by the shared operation registry.");
  process.exit(1);
}
console.log("Operation registry and Agent guide are synchronized.");
