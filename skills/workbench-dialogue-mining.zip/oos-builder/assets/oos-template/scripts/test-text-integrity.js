"use strict";

const assert = require("assert");
const { assertValidText, findInvalidText } = require("../lib/text-integrity");

assert.equal(findInvalidText({ text: "正常的中文和 English text" }).length, 0);
assert.equal(findInvalidText({ url: "https://example.com/?a=1" }).length, 0);
assert.throws(
  () => assertValidText({ ops: [{ title: "bad???broken" }] }, "stateOps"),
  (error) => error.code === "invalid_text_encoding" && error.hits[0].location.includes("ops")
);

process.stdout.write("Text integrity checks passed.\n");
