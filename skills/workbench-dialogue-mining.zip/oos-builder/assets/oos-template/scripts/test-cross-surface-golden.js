"use strict";

const assert = require("assert");
const { ensureStateShape, applyStateOps } = require("../lib/oos-state-model");
const { deriveStateProjection } = require("../lib/oos-derived");

const ACTIVE = new Set(["open", "in_progress", "waiting", "blocked"]);

function surfaces(state) {
  const projection = deriveStateProjection(state, new Date("2026-07-18T10:00:00+08:00"));
  const activeTasks = state.tasks.filter((task) => ACTIVE.has(task.status) && task.archived !== true);
  const activeBlocks = state.scheduleBlocks.filter((block) => ["planned", "in_progress"].includes(block.status));
  return {
    todayTaskIds: activeTasks.filter((task) => task.todayFocus || task.due === "2026-07-18").map((task) => task.id),
    planTaskIds: [...new Set([...activeBlocks.map((block) => block.taskId), ...activeTasks.map((task) => task.id)].filter(Boolean))],
    trackTaskIds: projection.__derived.trackViews.delivery.activeTaskIds,
    search: state.tasks.map((task) => ({ id: task.id, status: task.status, archived: task.archived === true })),
    agent: state.tasks.map((task) => ({ id: task.id, status: task.status, archived: task.archived === true })),
    blockStatuses: Object.fromEntries(state.scheduleBlocks.map((block) => [block.id, block.status]))
  };
}

const initial = ensureStateShape({
  meta: { version: 7, timezone: "Asia/Shanghai" },
  goals: [{ id: "delivery", name: "Client delivery", trackType: "project" }],
  tracks: [{ id: "delivery", name: "Client delivery", archetype: "project", role: "primary" }],
  tasks: [
    { id: "task-design", title: "Finish layout", goal: "delivery", status: "in_progress", priority: "high", due: "2026-07-18", todayFocus: true },
    { id: "task-handoff", title: "Send handoff", goal: "delivery", status: "blocked", dependsOnTaskIds: ["task-design"] }
  ],
  scheduleBlocks: [
    { id: "block-design-1", taskId: "task-design", title: "Layout session", goal: "delivery", kind: "focus", startAt: "2026-07-18T10:00:00+08:00", endAt: "2026-07-18T11:00:00+08:00", status: "planned", source: "chat", locked: false },
    { id: "block-design-2", taskId: "task-design", title: "Layout polish", goal: "delivery", kind: "focus", startAt: "2026-07-18T14:00:00+08:00", endAt: "2026-07-18T15:00:00+08:00", status: "planned", source: "chat", locked: false }
  ],
  questions: [{ id: "question-design", taskId: "task-design", goal: "delivery", text: "Which variant is final?" }],
  notes: [], inbox: [], activity: [], logs: { milestones: [{ id: "milestone-design", taskId: "task-design", goal: "delivery", name: "Layout approved", status: "planned" }] }
});

const before = surfaces(initial);
for (const key of ["todayTaskIds", "planTaskIds", "trackTaskIds"]) {
  assert(before[key].includes("task-design"), `${key} must point to the canonical task before execution`);
}
assert.equal(before.search.find((item) => item.id === "task-design").status, "in_progress");
assert.deepStrictEqual(before.search, before.agent, "Search and Agent must read the same canonical task records");

const execution = applyStateOps(initial, [{ type: "schedule.complete", targetId: "block-design-1" }]);
assert.equal(execution.ok, true);
assert.equal(execution.state.meta.version, initial.meta.version + 1, "one execution action must create one state version");
assert.equal(execution.state.tasks.find((task) => task.id === "task-design").status, "in_progress");
assert.equal(execution.state.scheduleBlocks.find((block) => block.id === "block-design-1").status, "completed");
assert.equal(execution.state.logs.executions.filter((item) => item.blockId === "block-design-1").length, 1);
const afterExecution = surfaces(execution.state);
for (const key of ["todayTaskIds", "planTaskIds", "trackTaskIds"]) {
  assert(afterExecution[key].includes("task-design"), `${key} must keep the task active after completing only one execution`);
}

const completion = applyStateOps(execution.state, [{
  type: "task.complete",
  targetId: "task-design",
  triggeringBlockId: "block-design-2",
  completedAt: "2026-07-18T07:00:00.000Z"
}]);
assert.equal(completion.ok, true);
assert.equal(completion.state.meta.version, execution.state.meta.version + 1, "one task completion must create one state version");
const completedTask = completion.state.tasks.find((task) => task.id === "task-design");
assert.equal(completedTask.status, "done");
assert.equal(completedTask.archived, true);
assert.equal(completion.state.scheduleBlocks.find((block) => block.id === "block-design-2").status, "completed");
assert.equal(completion.state.questions.some((item) => item.taskId === "task-design"), false);
assert.equal(completion.state.logs.milestones.find((item) => item.taskId === "task-design").status, "completed");
assert.equal(completion.state.tasks.find((task) => task.id === "task-handoff").status, "open");

const afterCompletion = surfaces(completion.state);
for (const key of ["todayTaskIds", "planTaskIds", "trackTaskIds"]) {
  assert(!afterCompletion[key].includes("task-design"), `${key} must remove the closed task in the same state version`);
}
assert.equal(afterCompletion.search.find((item) => item.id === "task-design").status, "done", "Search keeps canonical history with its true status");
assert.deepStrictEqual(afterCompletion.search, afterCompletion.agent, "Agent and Search must agree after task completion");

const reopened = applyStateOps(completion.state, [{ type: "task.reopen", targetId: "task-design" }]);
assert.equal(reopened.ok, true);
assert.equal(reopened.state.meta.version, completion.state.meta.version + 1);
assert.equal(reopened.state.tasks.find((task) => task.id === "task-design").status, "open");
assert.equal(reopened.state.scheduleBlocks.filter((block) => block.taskId === "task-design" && ["planned", "in_progress"].includes(block.status)).length, 0, "reopen must not resurrect old schedule blocks");

console.log("Cross-surface canonical task golden loop passed.");
