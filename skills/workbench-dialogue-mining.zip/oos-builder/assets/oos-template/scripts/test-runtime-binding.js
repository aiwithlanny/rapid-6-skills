#!/usr/bin/env node
"use strict";

const assert = require("assert/strict");
const fs = require("fs/promises");
const http = require("http");
const os = require("os");
const path = require("path");
const { spawn } = require("child_process");
const { mutateStateFile } = require("../lib/oos-store");

const ROOT = path.resolve(__dirname, "..");

async function waitFor(url, timeoutMs = 5000) {
  const started = Date.now();
  while (Date.now() - started < timeoutMs) {
    try { const response = await fetch(url); if (response.ok) return; } catch {}
    await new Promise((resolve) => setTimeout(resolve, 50));
  }
  throw new Error(`Timed out waiting for ${url}`);
}

async function request(base, pathname, options = {}) {
  const response = await fetch(`${base}${pathname}`, {
    ...options,
    headers: { "Content-Type": "application/json", ...(options.headers || {}) }
  });
  const body = await response.json();
  return { status: response.status, body };
}

function runNode(script, args, env) {
  return new Promise((resolve, reject) => {
    const child = spawn(process.execPath, [script, ...args], { cwd: ROOT, env: { ...process.env, ...env }, windowsHide: true });
    let stdout = "";
    let stderr = "";
    child.stdout.on("data", (chunk) => { stdout += chunk; });
    child.stderr.on("data", (chunk) => { stderr += chunk; });
    child.once("error", reject);
    child.once("exit", (code) => code === 0 ? resolve({ stdout, stderr }) : reject(new Error(`CLI exited ${code}: ${stdout}\n${stderr}`)));
  });
}

async function waitForEvent(response, eventName, timeoutMs = 4000) {
  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  const timeout = setTimeout(() => reader.cancel(), timeoutMs);
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) throw new Error(`SSE ended before ${eventName}`);
      buffer += decoder.decode(value, { stream: true });
      const events = buffer.split("\n\n");
      buffer = events.pop() || "";
      for (const event of events) {
        if (!event.includes(`event: ${eventName}`)) continue;
        const data = event.split("\n").find((line) => line.startsWith("data: "))?.slice(6) || "{}";
        return JSON.parse(data);
      }
    }
  } finally { clearTimeout(timeout); }
}

async function main() {
  const temp = await fs.mkdtemp(path.join(os.tmpdir(), "oos-runtime-binding-"));
  const stateFile = path.join(temp, "state.json");
  const queueFile = path.join(temp, "worker-queue.json");
  const opsFile = path.join(temp, "ops.json");
  const port = 43000 + Math.floor(Math.random() * 1000);
  const base = `http://127.0.0.1:${port}`;
  let server = null;
  let impostor = null;
  let eventController = null;
  try {
    await fs.copyFile(path.join(ROOT, "data", "state.json"), stateFile);
    await fs.copyFile(path.join(ROOT, "data", "worker-queue.json"), queueFile);
    const initial = JSON.parse(await fs.readFile(stateFile, "utf8"));
    const initialQueue = JSON.parse(await fs.readFile(queueFile, "utf8"));
    const initialPending = (initialQueue.items || []).filter((item) => item.status === "pending").length;
    const primaryTrackId = initial.tracks?.[0]?.id || initial.goals?.[0]?.id;
    assert(primaryTrackId, "runtime fixture requires at least one Track");
    const expectedVersion = initial.meta.version;
    const concurrent = await Promise.allSettled([
      mutateStateFile({ stateFile, expectedVersion, source: "agent-test", ops: [{ type: "activity.add", text: "Concurrent A", relatedGoal: "system" }], requireExpectedVersion: true }),
      mutateStateFile({ stateFile, expectedVersion, source: "hud-test", ops: [{ type: "activity.add", text: "Concurrent B", relatedGoal: "system" }], requireExpectedVersion: true })
    ]);
    assert.equal(concurrent.filter((item) => item.status === "fulfilled").length, 1);
    assert.equal(concurrent.filter((item) => item.status === "rejected" && item.reason.code === "state_conflict").length, 1);

    const afterConcurrent = JSON.parse(await fs.readFile(stateFile, "utf8"));
    await fs.writeFile(opsFile, `${JSON.stringify({ clientMutationId: "binding-offline-envelope", summary: "Use the public operations envelope alias", operations: [{ type: "activity.add", text: "Offline Agent CLI used the shared locked Runtime", relatedGoal: "system" }] }, null, 2)}\n`, "utf8");
    const offlineCli = await runNode(path.join(ROOT, "scripts", "oos-state.js"), ["op", "--offline", "--expected-version", String(afterConcurrent.meta.version), "--file", opsFile], { PORT: String(port), OOS_STATE_FILE: stateFile, OOS_WORKER_QUEUE_FILE: queueFile, OOS_BRAIN_DIR: path.join(temp, "brain") });
    const offlineResult = JSON.parse(offlineCli.stdout);
    assert.equal(offlineResult.ok, true);
    assert.equal(offlineResult.transport, "local");
    assert.equal(offlineResult.receipt.source, "agent");

    const afterOffline = JSON.parse(await fs.readFile(stateFile, "utf8"));
    let impostorMutations = 0;
    impostor = http.createServer((req, res) => {
      if (req.url === "/api/state-meta") {
        res.writeHead(200, { "Content-Type": "application/json" });
        return res.end(JSON.stringify({ version: 999, runtime: { id: "oos-runtime-v4", instanceId: "oos-another-workspace" } }));
      }
      impostorMutations += 1;
      res.writeHead(500, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ code: "wrong_target_reached" }));
    });
    await new Promise((resolve, reject) => {
      impostor.once("error", reject);
      impostor.listen(port, "127.0.0.1", resolve);
    });
    await fs.writeFile(opsFile, `${JSON.stringify([{ type: "activity.add", text: "Wrong workspace server was rejected", relatedGoal: "system" }], null, 2)}\n`, "utf8");
    const guardedCli = await runNode(path.join(ROOT, "scripts", "oos-state.js"), ["op", "--expected-version", String(afterOffline.meta.version), "--file", opsFile], { PORT: String(port), OOS_STATE_FILE: stateFile, OOS_WORKER_QUEUE_FILE: queueFile, OOS_BRAIN_DIR: path.join(temp, "brain") });
    const guardedResult = JSON.parse(guardedCli.stdout);
    assert.equal(guardedResult.transport, "local");
    assert.equal(guardedResult.fallbackReason, "wrong_oos_instance");
    assert(/safely used/.test(guardedResult.fallbackMessage));
    assert.equal(impostorMutations, 0);
    await new Promise((resolve) => impostor.close(resolve));
    impostor = null;

    server = spawn(process.execPath, [path.join(ROOT, "server.js")], {
      cwd: ROOT,
      env: { ...process.env, PORT: String(port), OOS_STATE_FILE: stateFile, OOS_WORKER_QUEUE_FILE: queueFile, OOS_BRAIN_DIR: path.join(temp, "brain") },
      windowsHide: true,
      stdio: ["ignore", "pipe", "pipe"]
    });
    await waitFor(`${base}/api/state-meta`);

    eventController = new AbortController();
    const eventResponse = await fetch(`${base}/api/events`, { signal: eventController.signal });
    assert.equal(eventResponse.status, 200);
    const stateChanged = waitForEvent(eventResponse, "state.changed");
    const meta = (await request(base, "/api/state-meta")).body;
    await fs.writeFile(opsFile, `${JSON.stringify([{ type: "activity.add", text: "Agent CLI reached the shared Runtime", relatedGoal: "system" }], null, 2)}\n`, "utf8");
    const cli = await runNode(path.join(ROOT, "scripts", "oos-state.js"), ["op", "--expected-version", String(meta.version), "--file", opsFile], { PORT: String(port), OOS_STATE_FILE: stateFile, OOS_WORKER_QUEUE_FILE: queueFile, OOS_BRAIN_DIR: path.join(temp, "brain") });
    const cliResult = JSON.parse(cli.stdout);
    assert.equal(cliResult.ok, true);
    assert.equal(cliResult.transport, "http");
    assert.equal(cliResult.receipt.source, "agent");
    const event = await stateChanged;
    assert.equal(event.version, meta.version + 1);

    const stateAfterAgent = (await request(base, "/api/state")).body;
    assert(stateAfterAgent.activity.some((item) => item.text === "Agent CLI reached the shared Runtime"));
    const opsHelp = await runNode(path.join(ROOT, "scripts", "oos-state.js"), ["ops", "--offline"], { PORT: String(port), OOS_STATE_FILE: stateFile, OOS_WORKER_QUEUE_FILE: queueFile, OOS_BRAIN_DIR: path.join(temp, "brain") });
    assert(JSON.parse(opsHelp.stdout).operations.some((operation) => operation.type === "schedule.clearTime"));
    const attentionCli = await runNode(path.join(ROOT, "scripts", "oos-state.js"), ["attention"], { PORT: String(port), OOS_STATE_FILE: stateFile, OOS_WORKER_QUEUE_FILE: queueFile, OOS_BRAIN_DIR: path.join(temp, "brain") });
    assert(Array.isArray(JSON.parse(attentionCli.stdout).attention.items));
    const unsupportedBefore = (await request(base, "/api/state-meta")).body;
    const unsupported = await request(base, "/api/state-ops", { method: "POST", body: JSON.stringify({ expectedVersion: unsupportedBefore.version, clientMutationId: "binding-unsupported-operation", source: "agent", ops: [{ type: "not.a.real.operation" }] }) });
    assert.equal(unsupported.status, 400);
    assert.equal(unsupported.body.code, "unsupported_operation");
    assert.equal((await request(base, "/api/state-meta")).body.version, unsupportedBefore.version);
    const scheduleBefore = (await request(base, "/api/state-meta")).body;
    const scheduleMutation = await request(base, "/api/state-ops", { method: "POST", body: JSON.stringify({ expectedVersion: scheduleBefore.version, clientMutationId: "binding-calendar-create", source: "hud", summary: "Create binding calendar block", ops: [{ type: "schedule.create", block: { id: "binding-calendar-block", title: "Calendar binding test", goal: primaryTrackId, kind: "focus", startAt: "2026-07-18T15:00:00", endAt: "2026-07-18T16:00:00", status: "planned", source: "hud", locked: false } }] }) });
    assert.equal(scheduleMutation.status, 200);
    assert.equal(scheduleMutation.body.version, scheduleBefore.version + 1, "one calendar mutation increments one version");
    const scheduleMeta = (await request(base, "/api/state-meta")).body;
    assert(scheduleMeta.scheduleChanges.some((change) => change.targets.includes("binding-calendar-block") && change.operations.includes("schedule.create")), "Agent can discover a HUD calendar mutation from receipt-derived meta");
    const taskCreatePayload = {
      expectedVersion: scheduleMeta.version,
      clientMutationId: "binding-task-create",
      source: "agent",
      summary: "Create canonical follow-up task",
      ops: [{ type: "task.create", task: { id: "binding-follow-up", title: "Prepare the follow-up", goal: primaryTrackId, status: "open", priority: "high", estimatedMinutes: 45 } }]
    };
    const taskCreate = await request(base, "/api/state-ops", { method: "POST", body: JSON.stringify(taskCreatePayload) });
    assert.equal(taskCreate.status, 200);
    assert.equal(taskCreate.body.version, scheduleMeta.version + 1, "task and its default schedule commit in one version");
    const createdTask = taskCreate.body.state.tasks.find((item) => item.id === "binding-follow-up");
    const createdBlock = taskCreate.body.state.scheduleBlocks.find((item) => item.taskId === "binding-follow-up" && item.status === "planned");
    assert.equal(createdTask.status, "open");
    assert(createdBlock, "task.create must use the shared Worker scheduling policy");
    const idempotentCreate = await request(base, "/api/state-ops", { method: "POST", body: JSON.stringify(taskCreatePayload) });
    assert.equal(idempotentCreate.status, 200);
    assert.equal(idempotentCreate.body.version, taskCreate.body.version, "retrying a clientMutationId must not create another version");
    const reusedId = await request(base, "/api/state-ops", { method: "POST", body: JSON.stringify({ ...taskCreatePayload, ops: [{ type: "activity.add", text: "Different mutation", relatedGoal: "system" }] }) });
    assert.equal(reusedId.status, 409);
    assert.equal(reusedId.body.code, "client_mutation_id_reused");

    const execution = await request(base, "/api/state-ops", { method: "POST", body: JSON.stringify({ expectedVersion: taskCreate.body.version, clientMutationId: "binding-execution-complete", source: "hud", summary: "Complete one execution", ops: [{ type: "schedule.complete", targetId: createdBlock.id }] }) });
    assert.equal(execution.status, 200);
    assert.equal(execution.body.state.tasks.find((item) => item.id === "binding-follow-up").status, "open", "schedule.complete must leave the canonical task active");
    assert(execution.body.state.logs.executions.some((item) => item.blockId === createdBlock.id));
    const taskComplete = await request(base, "/api/state-ops", { method: "POST", body: JSON.stringify({ expectedVersion: execution.body.version, clientMutationId: "binding-task-complete", source: "hud", summary: "Complete the whole task", ops: [{ type: "task.complete", targetId: "binding-follow-up" }] }) });
    assert.equal(taskComplete.status, 200);
    assert.equal(taskComplete.body.state.tasks.find((item) => item.id === "binding-follow-up").status, "done");
    const reopened = await request(base, "/api/state-ops", { method: "POST", body: JSON.stringify({ expectedVersion: taskComplete.body.version, clientMutationId: "binding-task-reopen", source: "agent", summary: "Reopen the whole task", ops: [{ type: "task.reopen", targetId: "binding-follow-up" }] }) });
    assert.equal(reopened.status, 200);
    assert.equal(reopened.body.state.tasks.find((item) => item.id === "binding-follow-up").status, "open");
    const freshBlock = reopened.body.state.scheduleBlocks.find((item) => item.taskId === "binding-follow-up" && item.status === "planned");
    assert(freshBlock, "task.reopen must create a fresh execution block");
    assert.notEqual(freshBlock.id, createdBlock.id, "task.reopen must not collide with or resurrect the completed block");
    const changes = await request(base, `/api/changes?sinceVersion=${scheduleMeta.version}`);
    assert.equal(changes.status, 200);
    assert(changes.body.changes.some((item) => item.operation === "schedule.complete" && /remains active/.test(item.humanMeaning)));
    assert(changes.body.changes.some((item) => item.operation === "task.complete" && item.changedEntities.some((entity) => entity.type === "task" && entity.id === "binding-follow-up")));
    const synchronizedMeta = (await request(base, "/api/state-meta")).body;
    assert.equal(synchronizedMeta.currentTruthVersion, synchronizedMeta.version);
    const staleHud = await request(base, "/api/state-ops", { method: "POST", body: JSON.stringify({ expectedVersion: meta.version, clientMutationId: "binding-stale-hud", source: "hud", ops: [{ type: "activity.add", text: "Must conflict", relatedGoal: "system" }] }) });
    assert.equal(staleHud.status, 409);
    assert.equal(staleHud.body.code, "state_conflict");

    const beforeCapture = (await request(base, "/api/state-meta")).body;
    const capture = await request(base, "/api/capture", { method: "POST", body: JSON.stringify({ expectedVersion: beforeCapture.version, clientMutationId: "binding-hud-capture", source: "hud", text: "A real capture for Agent review" }) });
    assert.equal(capture.status, 200);
    assert.equal(capture.body.worker.stats.pending, initialPending + 1, "capture adds exactly one pending review without erasing real Worker history");
    const queue = (await request(base, "/api/worker")).body;
    const capturedItem = queue.items.find((item) => item.id === capture.body.worker.agentReview.id);
    assert.equal(capturedItem?.type, "capture.review");
    const resolve = await request(base, `/api/worker/${encodeURIComponent(capturedItem.id)}/resolve`, { method: "POST", body: JSON.stringify({ note: "Reviewed during binding test", receiptId: capture.body.receipt.id }) });
    assert.equal(resolve.status, 200);
    assert.equal(resolve.body.stats.pending, initialPending, "resolving the test capture preserves pre-existing pending items");

    process.stdout.write("OOS Runtime binding tests passed.\n");
  } finally {
    eventController?.abort();
    if (impostor) await new Promise((resolve) => impostor.close(resolve));
    if (server && !server.killed) server.kill();
    await fs.rm(temp, { recursive: true, force: true });
  }
}

main().catch((error) => { console.error(error.stack || error.message); process.exitCode = 1; });
