"use strict";

const http = require("http");
const fs = require("fs/promises");
const fsSync = require("fs");
const path = require("path");
const crypto = require("crypto");
const { stateMeta: coreStateMeta } = require("./lib/oos-state");
const { createUnifiedRuntime } = require("./lib/unified-runtime");
const { workspaceInstanceId } = require("./lib/oos-store");
const { conversationAttentionSummary } = require("./lib/task-lifecycle");

const ROOT = __dirname;
const PUBLIC = path.join(ROOT, "public");
const DATA = process.env.OOS_DATA_DIR ? path.resolve(process.env.OOS_DATA_DIR) : path.join(ROOT, "data");
const BRAIN = process.env.OOS_BRAIN_DIR ? path.resolve(process.env.OOS_BRAIN_DIR) : path.join(ROOT, "brain");
const STATE_FILE = process.env.OOS_STATE_FILE ? path.resolve(process.env.OOS_STATE_FILE) : path.join(DATA, "state.json");
const QUEUE_FILE = process.env.OOS_WORKER_QUEUE_FILE ? path.resolve(process.env.OOS_WORKER_QUEUE_FILE) : path.join(DATA, "worker-queue.json");
const CURRENT_TRUTH = path.join(BRAIN, "Current", "current-truth.md");
const CURSOR_FILE = path.join(DATA, ".runtime-cache", "change-cursors.json");
const HOST = process.env.OOS_HOST || "127.0.0.1";
const PORT = Number(process.env.PORT || 4174);
const INSTANCE_ID = workspaceInstanceId(ROOT);
const RUNTIME_VERSION = "oos-unified-v5.1";
const runtimeHash = crypto.createHash("sha256");
for (const file of ["server.js", "lib/unified-runtime.js", "lib/oos-state.js", "lib/oos-context-kernel.js", "lib/task-lifecycle.js", "lib/oos-derived.js", "lib/text-integrity.js", "public/app.js", "public/styles.css", "public/calendar-ui.js", "public/calendar.css"]) {
  runtimeHash.update(fsSync.readFileSync(path.join(ROOT, file))).update("\n");
}
const RUNTIME_BUILD = runtimeHash.digest("hex").slice(0, 16);
const MIME = { ".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".json": "application/json; charset=utf-8", ".svg": "image/svg+xml; charset=utf-8", ".png": "image/png", ".webp": "image/webp", ".jpg": "image/jpeg", ".jpeg": "image/jpeg" };

const runtime = createUnifiedRuntime({ root: ROOT, stateFile: STATE_FILE, queueFile: QUEUE_FILE, currentTruthFile: CURRENT_TRUTH, cursorFile: CURSOR_FILE });

function respond(res, status, body, contentType = "application/json; charset=utf-8") {
  if (res.writableEnded) return;
  const payload = contentType.startsWith("application/json") ? JSON.stringify(body) : body;
  res.writeHead(status, { "Content-Type": contentType, "Cache-Control": "no-store" });
  res.end(payload);
}

async function bodyJson(req) {
  const chunks = [];
  let bytes = 0;
  for await (const chunk of req) {
    bytes += chunk.length;
    if (bytes > 1024 * 1024) throw Object.assign(new Error("request body too large"), { status: 413 });
    chunks.push(chunk);
  }
  return chunks.length ? JSON.parse(Buffer.concat(chunks).toString("utf8")) : {};
}

function requireMutationEnvelope(input) {
  if (!Number.isInteger(Number(input.expectedVersion))) throw Object.assign(new Error("expectedVersion is required"), { status: 428, code: "expected_version_required" });
  if (!String(input.clientMutationId || "").trim()) throw Object.assign(new Error("clientMutationId is required"), { status: 428, code: "client_mutation_id_required" });
  return input;
}

function scheduleChanges(state) {
  return (state.receipts || [])
    .filter((receipt) => String(receipt.operation || "").startsWith("schedule."))
    .slice(0, 20)
    .map((receipt) => ({
      version: receipt.versionAfter,
      operations: [receipt.operation],
      targets: (receipt.changedEntities || []).filter((item) => item.type === "scheduleBlock").map((item) => item.id),
      source: receipt.source,
      humanMeaning: receipt.humanMeaning
    }));
}

async function runtimeMeta(inputState = null) {
  const state = inputState || await runtime.stateWithMeta();
  const worker = state.__workerMeta || runtime.queueStats(await runtime.readQueue());
  const base = coreStateMeta(state, {
    sourceStateVersion: Number(state.__currentTruthVersion ?? -1),
    fresh: Number(state.__currentTruthVersion) === Number(state.meta?.version)
  });
  const committedVersions = (state.receipts || []).map((item) => Number(item.versionAfter)).filter(Number.isFinite);
  return {
    ...base,
    version: Number(state.meta?.version || 0),
    runtimeVersion: RUNTIME_VERSION,
    runtimeBuild: RUNTIME_BUILD,
    currentTruthVersion: Number.isFinite(Number(state.__currentTruthVersion)) ? Number(state.__currentTruthVersion) : null,
    latestReceiptVersion: committedVersions.length ? Math.max(...committedVersions) : 0,
    attentionSummary: state.__derived?.attention || { status: "clear", total: 0, items: [] },
    contextSummary: state.__derived?.context || base.contextSummary,
    maintenanceQueue: { ...base.maintenanceQueue, ...worker },
    scheduleChanges: scheduleChanges(state),
    changeToken: `v:${Number(state.meta?.version || 0)}:q:${Number(worker.pending || 0)}:${Number(worker.needsReview || 0)}`,
    runtime: { id: RUNTIME_VERSION, instanceId: INSTANCE_ID, stateTransport: "state-ops", liveSync: "sse+polling", agentCli: "scripts/oos-state.js" }
  };
}

async function submitMutation(input) {
  requireMutationEnvelope(input);
  const result = await runtime.submit({ ...input, clientMutationId: String(input.clientMutationId) });
  if (result.code === "state_conflict" || result.status === "conflict") throw Object.assign(new Error("State changed after this operation was prepared."), { status: 409, code: "state_conflict", result });
  if (result.status === "needs_review") throw Object.assign(new Error("State operations require review."), { status: 422, code: result.reviewReason || "state_ops_rejected", result });
  if (result.status !== "done") throw Object.assign(new Error("State operations were not committed."), { status: 422, code: result.status || "state_ops_rejected", result });
  const receipt = result.state?.receipts?.find((item) => item.id === result.receiptId) || null;
  return { ...result, receipt };
}

async function serveStatic(req, res) {
  const pathname = decodeURIComponent(new URL(req.url, `http://${req.headers.host || "localhost"}`).pathname);
  const relative = pathname === "/" ? "index.html" : pathname.replace(/^\/+/, "");
  const file = path.resolve(PUBLIC, relative);
  const publicRoot = path.resolve(PUBLIC);
  if (file !== path.join(publicRoot, "index.html") && !file.startsWith(`${publicRoot}${path.sep}`)) return respond(res, 403, "Forbidden", "text/plain; charset=utf-8");
  try { return respond(res, 200, await fs.readFile(file), MIME[path.extname(file).toLowerCase()] || "application/octet-stream"); }
  catch (error) { return respond(res, error.code === "ENOENT" ? 404 : 500, error.code === "ENOENT" ? "Not found" : "Server error", "text/plain; charset=utf-8"); }
}

const server = http.createServer(async (req, res) => {
  try {
    const requestUrl = new URL(req.url, `http://${req.headers.host || "localhost"}`);
    const pathname = requestUrl.pathname;
    if (req.method === "GET" && pathname === "/api/health") {
      const meta = await runtimeMeta();
      return respond(res, 200, { ok: true, stateOk: meta.integrity?.ok !== false, port: PORT, runtimeSignature: RUNTIME_VERSION, workerContinuous: true, ...meta });
    }
    if (req.method === "GET" && pathname === "/api/state") return respond(res, 200, await runtime.stateWithMeta());
    if (req.method === "GET" && pathname === "/api/state-meta") return respond(res, 200, await runtimeMeta());
    if (req.method === "GET" && pathname === "/api/conversation-attention") {
      const state = await runtime.stateWithMeta();
      return respond(res, 200, conversationAttentionSummary(state, {
        limit: requestUrl.searchParams.get("limit"),
        relatedGoal: requestUrl.searchParams.get("relatedGoal")
      }));
    }
    if (req.method === "GET" && pathname === "/api/changes") {
      const consumer = requestUrl.searchParams.get("consumer");
      return respond(res, 200, consumer ? await runtime.changesForConsumer(consumer) : await runtime.changesSince(requestUrl.searchParams.get("sinceVersion")));
    }
    if (req.method === "POST" && pathname === "/api/changes/ack") {
      const input = await bodyJson(req);
      return respond(res, 200, await runtime.acknowledgeChanges(input.consumer, input.version));
    }
    if (req.method === "GET" && ["/api/events", "/api/state-stream"].includes(pathname)) {
      res.writeHead(200, { "Content-Type": "text/event-stream; charset=utf-8", "Cache-Control": "no-cache, no-transform", Connection: "keep-alive" });
      res.write(`event: ready\ndata: ${JSON.stringify({ runtime: RUNTIME_VERSION })}\n\n`);
      const unsubscribe = runtime.subscribe((event) => {
        const names = event.type === "state" ? ["state", "state.changed"] : event.type === "worker" ? ["worker", "worker.changed"] : [event.type];
        for (const name of names) res.write(`event: ${name}\ndata: ${JSON.stringify(event.data)}\n\n`);
      });
      const heartbeat = setInterval(() => res.write(`: heartbeat ${Date.now()}\n\n`), 15000);
      req.on("close", () => { clearInterval(heartbeat); unsubscribe(); });
      return;
    }
    if (req.method === "POST" && pathname === "/api/state-ops") {
      const input = requireMutationEnvelope(await bodyJson(req));
      const result = await submitMutation(input);
      return respond(res, 200, { ...result, appliedOps: result.result?.appliedOps || [], skippedOps: result.result?.skippedOps || [], summary: `Applied ${(result.result?.appliedOps || []).length} state operation(s).` });
    }
    if (req.method === "POST" && pathname === "/api/schedule-blocks") {
      const input = requireMutationEnvelope(await bodyJson(req));
      const { expectedVersion, clientMutationId, source, riskLevel, confirmedMajor, ...block } = input;
      const result = await submitMutation({ expectedVersion, clientMutationId, source: source || "hud", riskLevel: riskLevel || "low", confirmedMajor, summary: `Scheduled: ${block.title || "time block"}`, relatedGoal: block.goal || "scheduling", ops: [{ type: "schedule.create", block }] });
      return respond(res, 201, result);
    }
    if (req.method === "PATCH" && pathname.startsWith("/api/schedule-blocks/")) {
      const input = requireMutationEnvelope(await bodyJson(req));
      const id = decodeURIComponent(pathname.split("/").pop());
      const { expectedVersion, clientMutationId, source, riskLevel, confirmedMajor, ...patch } = input;
      const result = await submitMutation({ expectedVersion, clientMutationId, source: source || "hud", riskLevel: riskLevel || "low", confirmedMajor, summary: `Updated schedule block ${id}`, relatedGoal: patch.goal || "scheduling", ops: [{ type: "schedule.update", targetId: id, patch }] });
      return respond(res, 200, result);
    }
    if (req.method === "POST" && pathname === "/api/capture") {
      const input = requireMutationEnvelope(await bodyJson(req));
      const text = String(input.text || "").trim();
      if (!text) return respond(res, 400, { code: "invalid_capture", message: "text is required" });
      const kind = ["inspiration", "thought", "progress", "note"].includes(String(input.kind || "")) ? String(input.kind) : "note";
      const relatedGoal = input.relatedGoal || "inbox";
      const note = {
        id: `note-${String(input.clientMutationId).replace(/[^a-zA-Z0-9_-]/g, "-")}`,
        title: String(input.title || text).replace(/\s+/g, " ").slice(0, 48),
        body: text,
        summary: text,
        tags: [kind, "quick-capture"],
        relatedGoals: relatedGoal === "inbox" ? [] : [relatedGoal]
      };
      const ops = [{ type: "note.add", note }];
      if (kind === "progress") ops.push({ type: "activity.add", text, relatedGoal });
      const result = await submitMutation({ expectedVersion: input.expectedVersion, clientMutationId: input.clientMutationId, source: input.source || "hud", riskLevel: "low", summary: text, relatedGoal, ops });
      const review = await runtime.enqueueAgentReview({
        clientMutationId: input.clientMutationId,
        source: input.source || "hud",
        sourceText: text,
        relatedGoal,
        receiptId: result.receiptId
      });
      return respond(res, 200, {
        ...result,
        worker: {
          committed: result.receipt,
          agentReview: review.result,
          stats: review.stats
        }
      });
    }
    if (req.method === "GET" && pathname === "/api/worker") {
      const queue = await runtime.readQueue();
      return respond(res, 200, { items: queue.items, stats: runtime.queueStats(queue) });
    }
    if (req.method === "POST" && /^\/api\/worker\/[^/]+\/resolve$/.test(pathname)) {
      const id = decodeURIComponent(pathname.split("/")[3]);
      const resolution = await runtime.resolveAgentReview(id, await bodyJson(req));
      return respond(res, 200, { item: resolution.result, stats: resolution.stats });
    }
    if (req.method === "GET") return serveStatic(req, res);
    return respond(res, 405, { code: "method_not_allowed" });
  } catch (error) {
    const result = error.result || {};
    const meta = [409, 428].includes(error.status) ? await runtimeMeta().catch(() => null) : null;
    return respond(res, error.status || 500, { ...result, code: error.code || result.code || "server_error", message: error.message, version: result.state?.meta?.version, stateMeta: meta });
  }
});

async function start() {
  await runtime.reconcileStartup();
  await runtime.enqueueDailyLifecycle();
  await runtime.runOnce();
  runtime.start();
  server.listen(PORT, HOST, () => process.stdout.write(`OOS HUD running at http://${HOST}:${PORT}\n`));
}

start().catch((error) => { process.stderr.write(`${error.stack || error.message}\n`); process.exitCode = 1; });

server.on("close", () => runtime.stop());
module.exports = { server, runtime };
