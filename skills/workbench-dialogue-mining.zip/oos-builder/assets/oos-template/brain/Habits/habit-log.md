# Habit Log

## Format

- Date:
- Habit:
- Done:
- Notes:

## Rule

Track the smallest sustainable action first. OOS should make continuity visible.

