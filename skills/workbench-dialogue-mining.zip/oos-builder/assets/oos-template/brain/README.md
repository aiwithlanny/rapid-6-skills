# OOS External Brain

`data/state.json` is the only mutable operational truth. Tasks, schedule status,
memories, decisions and reminders must be changed through State Ops. Markdown is
for source material, durable explanations and historical narrative; it must not
maintain a parallel task list.

- `Inbox`: raw material that still needs classification.
- `Goals`: durable goal briefs and milestone history, generated for this user.
- `Projects`: decisions and delivery history, never current task status.
- `Habits`: narrative observations; numeric facts belong in canonical metrics.
- `Wiki`: methods and explanations; personal facts belong in canonical memories.
- `Reviews`: reflection generated from receipts, executions and real logs.

