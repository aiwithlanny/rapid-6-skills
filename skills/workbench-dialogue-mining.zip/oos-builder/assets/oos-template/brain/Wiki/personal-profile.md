# Personal Context Notes

Canonical personal facts, preferences, constraints, patterns and principles live
in `state.context.memories` and are changed only through `memory.*` State Ops.
This file may explain a user-approved method in longer prose, but it must not
become a second personal profile.

- Never invent a personal fact.
- Cite the canonical memory or decision when a note depends on it.
- Use `memory.correct` or `memory.forget` when the user changes or removes context.

