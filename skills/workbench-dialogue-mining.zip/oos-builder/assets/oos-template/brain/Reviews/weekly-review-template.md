# Weekly Review Template

Generate this reflection from semantic receipts, completed execution blocks and
real logs. Do not create a second task or reminder list here.

## Evidence of Movement

- 

## Repeated Friction

- 

## Decisions to Revisit

- 

## Suggested Focus

- Any accepted action must be created in canonical `state.tasks`.

