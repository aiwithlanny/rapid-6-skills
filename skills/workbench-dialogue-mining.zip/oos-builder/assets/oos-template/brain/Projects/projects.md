# Projects

Use this folder for durable project decisions, briefs and milestone history.
Current tasks, deadlines, execution times and completion status stay in
`data/state.json` and are accessed through State Ops.

