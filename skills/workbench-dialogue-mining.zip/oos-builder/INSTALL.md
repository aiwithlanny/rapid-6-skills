# OOS Builder — Installation

OOS Builder creates a private, local-first personal operating system with a browser HUD, Current Truth, Tracks, planning, and deterministic state operations.

## Requirements

- Node.js 18 or newer
- Codex, Claude Code, or another Agent Skills-compatible host

## Install in Codex

1. Unzip the release.
2. Copy the entire `oos-builder` folder into your Codex skills directory:
   - macOS / Linux: `~/.codex/skills/oos-builder/`
   - Windows: `%USERPROFILE%\.codex\skills\oos-builder\`
3. Confirm that this file exists at the destination: `oos-builder/SKILL.md`.
4. Restart Codex or open a new task.
5. Start with: `Use $oos-builder to build my personal OOS.`

## Install in Claude Code

For one project, copy the entire `oos-builder` folder to:

```text
<your-project>/.claude/skills/oos-builder/
```

Then start a new Claude Code session and ask it to use `oos-builder`.

## Important privacy note

The included Runtime contains public-safe sample state only. Your generated OOS stores its working state locally by default. Review privacy, hosting, and data boundaries before sharing or deploying an OOS publicly.

## First prompt

```text
Use $oos-builder to build a private personal OOS. Start with the short intake interview, propose 1–3 Tracks, and wait for my confirmation before initialization.
```
